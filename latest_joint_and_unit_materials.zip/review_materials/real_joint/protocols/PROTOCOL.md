# Exact real-data joint old-record support protocol

This protocol is fixed before computing or aggregating new joint-support outcomes. This is an experimental follow-up using existing frozen data, not a prospective preregistration of the original study.

## Population and specification

Use every existing variant and restoration pair in the frozen BPI2013 (1,511 cases; 8,735 positions) and Traffic (512 cases; 1,806 positions) plans. Use all five existing reference nets: BPI IMf .1/.2/.3 and Traffic IM0/IMf .2. This gives 9,159 reference/word inputs and 29,817 reference/restoration comparisons. Analyze both prefix and completed acceptance at unit LOG/MODEL cost one and SYNC/TAU cost zero. Preserve original net arcs, words, record IDs, and case/order plans. No positive-dependent cohort selection.

## Exact representation

Represent the complete family J of LOG-position sets of all optimal accepted alignments as a canonical zero-suppressed decision diagram (ZDD). Node 0 is the empty family, node 1 is the family containing the empty set, and node [v,lo,hi] branches on LOG bit v. Zero-suppress hi=0. Collapse static TAU strongly connected components, which are mutually reachable with zero cost and consume no record. Remaining TAU edges form a DAG. Compute exact reverse distances and process suffix families in descending record layer, then increasing reverse distance and reverse TAU topological order. Union every optimal LOG/SYNC/MODEL/TAU successor. At the final record layer every reachable shortest completion has LOG set empty, including positive-cost visible completion. Validate every exact word cost and P/M projection against the previously independently checked unit-cost completion results.

For each restoration, existentially eliminate the recovered record's LOG bit from the after-family and shift subsequent positions to the before-word coordinate system. Compare full before and projected-after J exactly. Aggregate equality, proper contraction, proper expansion, overlap-incomparable, and disjoint categories. Record cardinalities and intersection cardinality. Record changes that preserve full P/M roles and changes that also preserve cost. An old saved LOG-consumption pattern is admissible after restoration exactly when it belongs to projected-after J. These outputs describe old-record consumption patterns, not whole alignment routes or operational error ground truth.

## Canonical saved-pattern diagnostic

Define a NEW deterministic diagnostic selection: lexicographically smallest LOG bit vector, reading old-word positions left to right and preferring SYNC (zero) to LOG (one). This selection is not attributed to any existing implementation. Record whether this before-pattern remains a member of projected-after J and whether the newly selected projected-after bit vector is identical. Separate P/M changes, J changes, and cost equality in every aggregation.

## Structural checks and witnesses

Record delta cost = after minus before and test the additive-unit insertion implications: delta lies in {-1,0,+1}; delta +1 implies before J is a subset of projected after J; delta -1 implies projected after J is a subset of before J; delta 0 implies the recovered record is never LOG in an after optimum. Save a distinguishing exact old-position mask and its before/after membership for every changed pair. This is an exact consistency check and useful mechanistic classification, not a new performance metric.

## Resource and reporting policy

Per input: at most 100,000 quotient product states, at most 2,000,000 conservative edge bound, and 60 seconds for reverse distance/family calculation. Per model shared canonical manager: at most 2,000,000 ZDD nodes. A capped input is RESOURCE_BOUND or TIME_BOUND, never negative. Report planned/exact/censored denominators separately. Abort a model with MANAGER_BOUND and preserve completed rows plus all unprocessed planned IDs. No unrestricted enumeration of all masks is used in the producer. Independent checks may enumerate masks on separately fixed small inputs and validate distinguishing witnesses with constrained products using original arcs.

## Frozen materials and output

Freeze SHA256 bindings for this protocol, producer script, all five model documents, both plans, and the five existing exact word-result and pair-result files before outcome execution. Shared manager export per model contains nodes; per-word rows contain exact roots, cost, P/M and cardinality; per-pair rows contain both original variant IDs, old IDs/activity word, both acceptance comparisons, projected root, categories, and witnesses. Preserve any corrections and versioned failures explicitly. Original scientific inputs and manuscript remain unchanged.
