"""Exact complete optimal LOG-set families for every frozen real-log input."""
from pathlib import Path
from collections import deque, Counter
from functools import lru_cache
from datetime import datetime, timezone
from time import perf_counter
import hashlib,json,sys

OUT=Path(__file__).resolve().parent
STUDY=OUT.parent.parent
PREV=STUDY/'acceptance_strengthening_2026-10-18_v1'
EXT=STUDY/'experimental_extension_2026-10-10_v1'
INF=10**9
MODELS=json.loads((PREV/'frozen_inputs.json').read_text(encoding='utf-8'))['models']
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def rows(p):
    with p.open(encoding='utf-8') as f:return [json.loads(s) for s in f if s.strip()]
def save(p,x):
    with p.open('x',encoding='utf-8') as f:json.dump(x,f,ensure_ascii=False,indent=2)
def binding(p):
    b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def freeze():
    paths=[OUT/'PROTOCOL.md',Path(__file__)]
    paths += [Path(p) for p in MODELS.values()]
    paths += [EXT/f'plan_{c}.json' for c in ('bpi2013','traffic')]
    paths += [PREV/'completion_numerical'/f'{m}_{kind}.jsonl' for m in MODELS for kind in ('words','pairs')]
    save(OUT/'frozen_inputs.json',{'status':'FROZEN_BEFORE_JOINT_OUTCOME_EXECUTION','created_at_utc':datetime.now(timezone.utc).isoformat(),'files':[binding(p) for p in paths], 'models':MODELS})
def verify():
    for x in read(OUT/'frozen_inputs.json')['files']:assert binding(Path(x['path']))==x,x['path']

class ManagerBound(Exception):pass
class WordTimeBound(Exception):pass

class ZDD:
    def __init__(self,cap=2000000):
        self.nodes=[None,None];self.unique={};self.cap=cap
    def var(self,u):return INF if u<2 else self.nodes[u][0]
    def mk(self,v,lo,hi):
        if hi==0:return lo
        assert self.var(lo)>v and self.var(hi)>v,(v,lo,hi)
        key=(v,lo,hi)
        if key not in self.unique:
            if len(self.nodes)>=self.cap:raise ManagerBound()
            self.unique[key]=len(self.nodes);self.nodes.append(key)
        return self.unique[key]
    @lru_cache(maxsize=250000)
    def union(self,a,b):
        if a==b or b==0:return a
        if a==0:return b
        if a>b:return self.union(b,a)
        v=min(self.var(a),self.var(b));assert v<INF
        a0,a1=self.nodes[a][1:] if self.var(a)==v else (a,0)
        b0,b1=self.nodes[b][1:] if self.var(b)==v else (b,0)
        return self.mk(v,self.union(a0,b0),self.union(a1,b1))
    @lru_cache(maxsize=250000)
    def intersection(self,a,b):
        if a==b:return a
        if a==0 or b==0:return 0
        if a>b:return self.intersection(b,a)
        v=min(self.var(a),self.var(b));assert v<INF
        a0,a1=self.nodes[a][1:] if self.var(a)==v else (a,0)
        b0,b1=self.nodes[b][1:] if self.var(b)==v else (b,0)
        return self.mk(v,self.intersection(a0,b0),self.intersection(a1,b1))
    @lru_cache(maxsize=250000)
    def difference(self,a,b):
        if a==0 or a==b:return 0
        if b==0:return a
        v=min(self.var(a),self.var(b));assert v<INF
        a0,a1=self.nodes[a][1:] if self.var(a)==v else (a,0)
        b0,b1=self.nodes[b][1:] if self.var(b)==v else (b,0)
        return self.mk(v,self.difference(a0,b0),self.difference(a1,b1))
    @lru_cache(maxsize=250000)
    def project_delete(self,u,p):
        if u<2:return u
        v,lo,hi=self.nodes[u]
        lo=self.project_delete(lo,p);hi=self.project_delete(hi,p)
        return self.union(lo,hi) if v==p else self.mk(v-int(v>p),lo,hi)
    @lru_cache(maxsize=250000)
    def count(self,u):
        if u<2:return u
        v,lo,hi=self.nodes[u];return self.count(lo)+self.count(hi)
    @lru_cache(maxsize=250000)
    def support(self,u):
        if u<2:return (0,0)
        v,lo,hi=self.nodes[u];ph,mh=self.support(hi)
        if lo==0:return (ph|(1<<v),mh|(1<<v))
        pl,ml=self.support(lo);return (pl|ph|(1<<v),ml&mh)
    def selected(self,u):
        assert u!=0;mask=0
        while u>=2:
            v,lo,hi=self.nodes[u]
            if lo:u=lo
            else:mask|=1<<v;u=hi
        assert u==1;return mask
    def contains(self,u,mask):
        while u>=2:
            v,lo,hi=self.nodes[u]
            if mask&((1<<v)-1):return False
            if mask&(1<<v):mask^=1<<v;u=hi
            else:u=lo
        return u==1 and mask==0
    def clear_caches(self):
        for f in (self.union,self.intersection,self.difference,self.project_delete,self.count,self.support):f.cache_clear()

def positions(mask):return [i for i in range(mask.bit_length()) if mask&(1<<i)]

def quotient(doc):
    graph=doc['graph'];net=doc['net_doc'];n=len(graph['markings'])
    tau=[[] for _ in range(n)];back=[[] for _ in range(n)]
    for u,ee in enumerate(graph['edges']):
        for ti,v in ee:
            if net['transitions'][ti]['label'] is None:tau[u].append(v);back[v].append(u)
    # Iterative Kosaraju avoids recursion limits and uses original TAU arcs only.
    seen=set();finish=[]
    for s in range(n):
        if s in seen:continue
        stack=[(s,0)];seen.add(s)
        while stack:
            u,j=stack[-1]
            if j==len(tau[u]):finish.append(u);stack.pop();continue
            v=tau[u][j];stack[-1]=(u,j+1)
            if v not in seen:seen.add(v);stack.append((v,0))
    comp=[-1]*n;cc=0
    for s in reversed(finish):
        if comp[s]>=0:continue
        comp[s]=cc;stack=[s]
        while stack:
            u=stack.pop()
            for v in back[u]:
                if comp[v]<0:comp[v]=cc;stack.append(v)
        cc+=1
    outsets=[set() for _ in range(cc)]
    for u,ee in enumerate(graph['edges']):
        for ti,v in ee:
            label=net['transitions'][ti]['label'];a,b=comp[u],comp[v]
            if label is None and a==b:continue
            outsets[a].add((b,int(label is not None),label))
    out=[sorted(x,key=lambda e:(e[0],e[1],str(e[2]))) for x in outsets];rev=[[] for _ in out]
    dag=[[] for _ in out];degree=[0]*cc
    for u,ee in enumerate(out):
        for v,w,l in ee:
            rev[v].append((u,w,l))
            if l is None:dag[u].append(v);degree[v]+=1
    todo=deque(i for i,x in enumerate(degree) if x==0);rank={}
    while todo:
        u=todo.popleft();rank[u]=len(rank)
        for v in dag[u]:
            degree[v]-=1
            if degree[v]==0:todo.append(v)
    assert len(rank)==cc
    final=next(i for i,x in enumerate(graph['markings']) if x==doc['final'])
    return out,rev,comp[0],comp[final],rank,{'original_markings':n,'tau_components':cc,'original_edges':sum(map(len,graph['edges'])),'quotient_edges':sum(map(len,out)),'marking_to_component':comp}

def reverse_distances(word,rev,seeds):
    m=len(rev);n=len(word);d=[INF]*((n+1)*m);q=deque()
    for u in seeds:d[u]=0;q.append(u)
    while q:
        u=q.popleft();i,c=divmod(u,m);base=i*m;du=d[u]
        for v,w,label in rev[c]:
            z=base+v;nd=du+w
            if nd<d[z]:
                d[z]=nd
                if w:q.append(z)
                else:q.appendleft(z)
            if i>0 and label is not None and label==word[i-1]:
                z=(i-1)*m+v
                if du<d[z]:d[z]=du;q.appendleft(z)
        if i>0:
            z=(i-1)*m+c;nd=du+1
            if nd<d[z]:d[z]=nd;q.append(z)
    return d

def family(word,out,dr,initial,rank,zdd,deadline):
    m=len(out);n=len(word);following=[1 if dr[n*m+c]<INF else 0 for c in range(m)]
    for i in range(n-1,-1,-1):
        if perf_counter()>deadline:raise WordTimeBound()
        base=i*m;nextbase=(i+1)*m;current=[0]*m
        for c in sorted(range(m),key=lambda c:(dr[base+c],-rank[c])):
            if dr[base+c]>=INF:continue
            u=0;du=dr[base+c]
            if du==1+dr[nextbase+c]:u=zdd.mk(i,0,following[c])
            for target,w,label in out[c]:
                if du==w+dr[base+target]:u=zdd.union(u,current[target])
                if label is not None and label==word[i] and du==dr[nextbase+target]:u=zdd.union(u,following[target])
            assert u!=0,(i,c,du)
            current[c]=u
        following=current
    root=following[initial];p,ma=zdd.support(root)
    return {'cost':dr[initial],'root':root,'possible_positions':positions(p),'mandatory_positions':positions(ma),'family_count':zdd.count(root)}

def analyze(word,tables,zdd):
    out,rev,initial,final,rank,structure=tables;m=len(out);n=len(word);start=perf_counter()
    states=(n+1)*m;edges=(2*n+1)*sum(map(len,out))+n*m
    if states>100000 or edges>2000000:return {'status':'RESOURCE_BOUND','states':states,'edge_bound':edges}
    deadline=start+60
    try:
        drp=reverse_distances(word,rev,range(n*m,(n+1)*m))
        drc=reverse_distances(word,rev,[n*m+final])
        if perf_counter()>deadline:raise WordTimeBound()
        prefix=family(word,out,drp,initial,rank,zdd,deadline)
        completed=family(word,out,drc,initial,rank,zdd,deadline)
        return {'status':'EXACT','prefix':prefix,'completed':completed,'states':states,'edge_bound':edges,'seconds':perf_counter()-start}
    except WordTimeBound:return {'status':'TIME_BOUND','states':states,'edge_bound':edges,'seconds':perf_counter()-start}

def compare(a,b,p,zdd):
    x=a['root'];y=zdd.project_delete(b['root'],p);meet=zdd.intersection(x,y)
    same=x==y
    category='equal' if same else 'proper_contraction' if meet==y else 'proper_expansion' if meet==x else 'disjoint' if meet==0 else 'overlap_incomparable'
    px,mx=zdd.support(x);py,my=zdd.support(y)
    roles_changed=(px,mx)!=(py,my);delta=b['cost']-a['cost'];assert delta in (-1,0,1)
    if delta==1:assert meet==x
    if delta==-1:assert meet==y
    if delta==0:assert p not in b['possible_positions']
    selected=zdd.selected(x);selected_after=zdd.selected(y)
    result={'before_root':x,'after_root':b['root'],'projected_after_root':y,'before_cost':a['cost'],'after_cost':b['cost'],'delta_cost':delta,'same_cost':delta==0,'category':category,'joint_changed':not same,'old_roles_changed':roles_changed,'marginal_stable_joint_change':not same and not roles_changed,'before_family_count':zdd.count(x),'after_projected_family_count':zdd.count(y),'intersection_count':zdd.count(meet),'before_subset_after':meet==x,'after_subset_before':meet==y,'canonical_before_mask':selected,'canonical_after_mask':selected_after,'canonical_unchanged':selected==selected_after,'canonical_before_remains_admissible':zdd.contains(y,selected),'recovered_record_possible_log':p in b['possible_positions'],'recovered_record_mandatory_log':p in b['mandatory_positions']}
    if not same:
        first=zdd.difference(x,y)
        if first==0:first=zdd.difference(y,x)
        witness=zdd.selected(first)
        result['distinguishing_mask']=witness;result['distinguishing_membership_before']=zdd.contains(x,witness);result['distinguishing_membership_after']=zdd.contains(y,witness)
        assert result['distinguishing_membership_before']!=result['distinguishing_membership_after']
    return result

def run(model):
    verify();start=perf_counter();cohort='bpi2013' if model.startswith('bpi') else 'traffic';plan=read(EXT/f'plan_{cohort}.json')
    expected={r['variant_id']:r['answer'] for r in rows(PREV/'completion_numerical'/f'{model}_words.jsonl')}
    oldpairs={r['pair_id']:r for r in rows(PREV/'completion_numerical'/f'{model}_pairs.jsonl')}
    tables=quotient(read(Path(MODELS[model])));zdd=ZDD();answers={};statuses=Counter()
    with (OUT/f'{model}_words.jsonl').open('x',encoding='utf-8') as stream:
        for variant in plan['variants']:
            vid=variant['variant_id'];answer=analyze(variant['word'],tables,zdd);answers[vid]=answer;statuses[answer['status']]+=1
            if answer['status']=='EXACT':
                for acceptance in ('prefix','completed'):
                    for f in ('cost','possible_positions','mandatory_positions'):assert answer[acceptance][f]==expected[vid][acceptance][f],(model,vid,acceptance,f)
            stream.write(json.dumps({'variant_id':vid,'word':variant['word'],'answer':answer},ensure_ascii=False,separators=(',',':'))+'\n')
            if (vid+1)%100==0 or vid+1==len(plan['variants']):
                stream.flush();print(json.dumps({'model':model,'words':vid+1,'total':len(plan['variants']),'status':dict(statuses),'nodes':len(zdd.nodes),'seconds':round(perf_counter()-start,2)}),flush=True);zdd.clear_caches()
    cases={c['id']:c for c in plan['cases']};counts={k:Counter() for k in ('prefix','completed')};casecounts={k:{} for k in counts};exact=0;censored=[]
    with (OUT/f'{model}_pairs.jsonl').open('x',encoding='utf-8') as stream:
        for pair in plan['pairs']:
            cid=pair['case'];events=cases[cid]['events'];p=pair['position'];before=answers[pair['before_variant']];after=answers[pair['after_variant']]
            rec={**pair,'model':model,'old_ids':[e['id'] for i,e in enumerate(events) if i!=p],'old_word':[e['concept']+'|'+e['lifecycle'] if model.startswith('bpi') else e['concept'] for i,e in enumerate(events) if i!=p]}
            # Use frozen variant activity strings, which include the exact original labeling convention.
            rec['old_word']=plan['variants'][pair['before_variant']]['word']
            if before['status']!='EXACT' or after['status']!='EXACT':rec['status']='CENSORED_PAIR';censored.append(pair['pair_id'])
            else:
                rec['status']='EXACT_PAIR';exact+=1
                for acceptance in counts:
                    d=compare(before[acceptance],after[acceptance],p,zdd);rec[acceptance]=d;c=counts[acceptance]
                    assert d['old_roles_changed']==oldpairs[pair['pair_id']][acceptance]['old_roles_changed']
                    predicates={'joint_changes':d['joint_changed'],'old_role_changes':d['old_roles_changed'],'marginal_stable_joint_changes':d['marginal_stable_joint_change'],'same_cost_pairs':d['same_cost'],'same_cost_joint_changes':d['same_cost'] and d['joint_changed'],'same_cost_role_changes':d['same_cost'] and d['old_roles_changed'],'same_cost_marginal_stable_joint_changes':d['same_cost'] and d['marginal_stable_joint_change'],'canonical_before_inadmissible':not d['canonical_before_remains_admissible'],'canonical_unchanged_joint_changed':d['canonical_unchanged'] and d['joint_changed'],'canonical_unchanged_roles_changed':d['canonical_unchanged'] and d['old_roles_changed'],'canonical_unchanged_same_cost_joint_changed':d['canonical_unchanged'] and d['same_cost'] and d['joint_changed'],'canonical_unchanged_same_cost_roles_changed':d['canonical_unchanged'] and d['same_cost'] and d['old_roles_changed']}
                    c['category_'+d['category']]+=1;c['delta_'+str(d['delta_cost'])]+=1
                    for key,predicate in predicates.items():
                        if predicate:c[key]+=1;casecounts[acceptance].setdefault(key,set()).add(cid)
            stream.write(json.dumps(rec,ensure_ascii=False,separators=(',',':'))+'\n')
    save(OUT/f'{model}_zdd.json',{'status':'EXACT_CANONICAL_ZDD_NODES','node_schema':'0=empty family;1={empty set};>=2:[position,lo,hi]','nodes':zdd.nodes,'structure':tables[-1]})
    summary={'status':'EXACT_JOINT_FULL_PLANNED_COHORT' if not censored else 'JOINT_FULL_PLAN_WITH_CENSORING','model':model,'planned_cases':len(plan['cases']),'planned_words':len(plan['variants']),'planned_pairs':len(plan['pairs']),'word_statuses':dict(statuses),'exact_pairs':exact,'censored_pair_ids':censored,'counts':{k:dict(v) for k,v in counts.items()},'case_counts':{a:{k:len(v) for k,v in d.items()} for a,d in casecounts.items()},'zdd_nodes':len(zdd.nodes),'cost_and_marginals_match_existing_exact_all_words':True,'unit_insertion_support_implications_pass_all_pairs':True,'elapsed_seconds':perf_counter()-start,'outputs':[binding(OUT/f'{model}_{s}') for s in ('words.jsonl','pairs.jsonl','zdd.json')]}
    save(OUT/f'{model}_summary.json',summary);verify();print(json.dumps(summary,ensure_ascii=False),flush=True)

def selftest():
    z=ZDD();a=z.mk(0,1,z.mk(2,0,1));b=z.mk(1,0,1);u=z.union(a,b)
    def masks(r,n=4):return {m for m in range(1<<n) if z.contains(r,m)}
    assert masks(a)=={0,5};assert masks(b)=={2};assert masks(u)=={0,2,5};assert masks(z.intersection(a,u))=={0,5}
    assert masks(z.difference(u,a))=={2};assert masks(z.project_delete(u,1))=={0,3}
    assert z.count(u)==3 and z.support(u)==(7,0) and z.selected(u)==0
    print('SELFTEST_PASS')

if __name__=='__main__':
    if sys.argv[1]=='freeze':freeze()
    elif sys.argv[1]=='selftest':selftest()
    else:run(sys.argv[1])
