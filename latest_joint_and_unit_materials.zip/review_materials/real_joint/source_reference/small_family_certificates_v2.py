"""Original-integer-arc certificates for every new marginal-stable J case.

Post-hoc exhaustive explanation of all detected marginal-stable J changes,
not a newly selected incidence denominator. Freeze script/inputs before run.
"""
from pathlib import Path
from collections import deque
import heapq,json,hashlib,sys
from datetime import datetime,timezone
HERE=Path(__file__).resolve().parent
STUDY=HERE.parent.parent
EXT=STUDY/'experimental_extension_2026-10-10_v1'
PREV=STUDY/'acceptance_strengthening_2026-10-18_v1'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def rows(p):return [json.loads(s) for s in p.read_text(encoding='utf-8').splitlines() if s]
def binding(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def save(p,x):
 with p.open('x',encoding='utf-8') as f:json.dump(x,f,ensure_ascii=False,indent=2)
MODELS=read(PREV/'frozen_inputs.json')['models']

def graph_original(doc):
 nd=doc['net_doc'];initial=tuple(nd['initial']);states=[initial];index={initial:0};out=[]
 for marking in states:
  ee=[]
  for ti,t in enumerate(nd['transitions']):
   if all(m>=p for m,p in zip(marking,t['pre'])):
    target=tuple(m-p+q for m,p,q in zip(marking,t['pre'],t['post']))
    if target not in index:index[target]=len(states);states.append(target)
    ee.append((ti,index[target]))
  out.append(ee)
 assert len(states)==len(doc['graph']['markings'])
 return states,out,states.index(tuple(doc['final']))

def solve(doc,graph,word,ids,required_oldmask,recovered=None):
 states,out,final=graph;n=len(word);m=len(states);trans=doc['net_doc']['transitions']
 fixed={i:int(bool(required_oldmask&(1<<(i if recovered is None or i<recovered else i-1)))) for i in range(n) if i!=recovered}
 start=(0,0);dist={start:0};prev={};q=[(0,start)];goal=None
 while q:
  cost,u=heapq.heappop(q)
  if cost!=dist[u]:continue
  i,c=u
  if i==n and c==final:goal=u;break
  candidates=[]
  for ti,target in out[c]:
   t=trans[ti];label=t['label'];w=int(label is not None)
   candidates.append(((i,target),w,{'kind':'MODEL' if w else 'TAU','transition':t['id'],'event_id':None,'cost':w}))
   if i<n and fixed.get(i,0)==0 and label is not None and label==word[i]:candidates.append(((i+1,target),0,{'kind':'SYNC','transition':t['id'],'event_id':ids[i],'cost':0}))
  if i<n and fixed.get(i,1)==1:candidates.append(((i+1,c),1,{'kind':'LOG','transition':None,'event_id':ids[i],'cost':1}))
  for v,w,move in candidates:
   nd=cost+w
   if nd<dist.get(v,10**9):dist[v]=nd;prev[v]=(u,move);heapq.heappush(q,(nd,v))
 if goal is None:return {'status':'UNREACHABLE'}
 moves=[];u=goal
 while u!=start:u0,move=prev[u];moves.append(move);u=u0
 moves.reverse();marking=list(doc['net_doc']['initial']);used=[];total=0;byid={t['id']:t for t in trans}
 for move in moves:
  total+=move['cost']
  if move['event_id'] is not None:used.append(move['event_id'])
  if move['transition'] is not None:
   t=byid[move['transition']];assert all(a>=b for a,b in zip(marking,t['pre']))
   marking=[a-b+c for a,b,c in zip(marking,t['pre'],t['post'])]
 assert marking==doc['final'] and used==ids and total==dist[goal]
 actual=[ids.index(x['event_id']) for x in moves if x['kind']=='LOG']
 for i,value in fixed.items():assert int(i in actual)==value
 return {'status':'EXACT_ORIGINAL_ARC_CONSTRAINED_OPTIMUM','cost':dist[goal],'log_positions':actual,'moves':moves,'integer_arc_replay':'PASS','final_marking':marking}

def family(nodes,root):
 if root==0:return set()
 if root==1:return {0}
 v,lo,hi=nodes[root];return family(nodes,lo)|{m|(1<<v) for m in family(nodes,hi)}

def freeze():
 paths=[Path(__file__),HERE/'PROTOCOL.md',EXT/'plan_bpi2013.json']
 for model in ('bpi2013_IMf02','bpi2013_IMf03'):paths +=[Path(MODELS[model]),HERE/f'{model}_pairs.jsonl',HERE/f'{model}_words.jsonl',HERE/f'{model}_zdd.json']
 save(HERE/'small_family_frozen_v2.json',{'status':'FROZEN_BEFORE_CORRECTED_CERTIFICATE_EXECUTION','created_at_utc':datetime.now(timezone.utc).isoformat(),'correction':'v1 correctly checked every constrained membership, then failed a mistaken post-analysis expectation that .2/.3 have identical exact families. v2 reports cross-reference equality rather than assuming it; scientific inputs/solver unchanged.','selection':'All completed marginal-stable J changes detected in .2/.3; exact all four common-old masks, both before/after; fixed original arcs replay. This is descriptive certificate follow-up, not incidence discovery.','files':[binding(p) for p in paths]})

def run():
 for item in read(HERE/'small_family_frozen_v2.json')['files']:assert binding(Path(item['path']))==item
 plan=read(EXT/'plan_bpi2013.json');cases={c['id']:c for c in plan['cases']};records=[]
 for model in ('bpi2013_IMf02','bpi2013_IMf03'):
  doc=read(Path(MODELS[model]));g=graph_original(doc);nodes=read(HERE/f'{model}_zdd.json')['nodes']
  detected=[p for p in rows(HERE/f'{model}_pairs.jsonl') if p['completed']['marginal_stable_joint_change']]
  for p in detected:
   d=p['completed'];pos=p['position'];events=cases[p['case']]['events'];newids=[e['id'] for e in events]
   beforeword=plan['variants'][p['before_variant']]['word'];afterword=plan['variants'][p['after_variant']]['word'];beforefamily=family(nodes,d['before_root']);afterfamily=family(nodes,d['projected_after_root'])
   assert len(beforeword)==2
   certificates=[]
   for mask in range(4):
    b=solve(doc,g,beforeword,p['old_ids'],mask);a=solve(doc,g,afterword,newids,mask,pos)
    assert (b['cost']==d['before_cost'])==(mask in beforefamily)
    assert (a['cost']==d['after_cost'])==(mask in afterfamily)
    certificates.append({'old_mask':mask,'log_old_ids':[p['old_ids'][i] for i in range(2) if mask&(1<<i)],'before':b,'after':a})
   records.append({'model':model,'pair_id':p['pair_id'],'case':p['case'],'position':pos,'before_word':beforeword,'after_word':afterword,'old_ids':p['old_ids'],'before_cost':d['before_cost'],'after_cost':d['after_cost'],'before_family_masks':sorted(beforefamily),'after_projected_family_masks':sorted(afterfamily),'all_four_old_masks_original_arc_certificates':certificates})
 cross_reference_equality=[{'pair_id':records[j]['pair_id'],'before_family_equal':records[j]['before_family_masks']==records[j+2]['before_family_masks'],'after_projected_family_equal':records[j]['after_projected_family_masks']==records[j+2]['after_projected_family_masks']} for j in (0,1)]
 save(HERE/'small_family_certificates_v2.json',{'status':'PASS_ALL_FOUR_CASE_MODEL_COMPARISONS_ALL_FOUR_OLD_MASKS','original_arc_constrained_solves':32,'cross_reference_family_equality':cross_reference_equality,'records':records})
 print(json.dumps([{k:v for k,v in r.items() if k!='all_four_old_masks_original_arc_certificates'} for r in records],ensure_ascii=False,indent=2))

if __name__=='__main__':freeze() if sys.argv[1]=='freeze' else run()
