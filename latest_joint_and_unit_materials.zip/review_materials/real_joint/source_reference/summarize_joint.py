"""Reproduce protocol-defined full-cohort J comparison tables; no solving."""
from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
import csv,json,hashlib
HERE=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def rows(p):
 with p.open(encoding='utf-8') as f:return [json.loads(s) for s in f if s.strip()]
def binding(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def save(p,x):
 with p.open('x',encoding='utf-8') as f:json.dump(x,f,ensure_ascii=False,indent=2)
models=list(read(HERE/'frozen_inputs.json')['models'])
summaries=[];table=[];joint_only=[];allcases={};law=Counter();resource=Counter()
for model in models:
 s=read(HERE/f'{model}_summary.json');assert s['exact_pairs']==s['planned_pairs'] and not s['censored_pair_ids'];summaries.append(s)
 pairs=rows(HERE/f'{model}_pairs.jsonl');words=rows(HERE/f'{model}_words.jsonl');resource['exact_words']+=len(words);resource['planned_pairs']+=len(pairs)
 for acceptance in ('prefix','completed'):
  c=s['counts'][acceptance]
  table.append({'model':model,'acceptance':acceptance,'planned_pairs':s['planned_pairs'],'equal_cost_pairs':c.get('same_cost_pairs',0),'joint_changes':c.get('joint_changes',0),'role_changes':c.get('old_role_changes',0),'marginal_stable_joint_changes':c.get('marginal_stable_joint_changes',0),'same_cost_joint_changes':c.get('same_cost_joint_changes',0),'same_cost_canonical_oldview_unchanged':c.get('canonical_unchanged_same_cost_joint_changed',0),'equal_families':c.get('category_equal',0),'proper_contraction':c.get('category_proper_contraction',0),'proper_expansion':c.get('category_proper_expansion',0),'overlap_incomparable':c.get('category_overlap_incomparable',0),'disjoint':c.get('category_disjoint',0),'maximum_word_family_count':max(w['answer'][acceptance]['family_count'] for w in words)})
  for p in pairs:
   d=p[acceptance];law[f'delta_{d["delta_cost"]}']+=1
   if d['marginal_stable_joint_change']:joint_only.append({'model':model,'acceptance':acceptance,**{k:p[k] for k in ('pair_id','case','position','old_ids','old_word')},'comparison':d})
   if d['delta_cost']==1:assert d['before_subset_after']
   if d['delta_cost']==-1:assert d['after_subset_before']
   if d['delta_cost']==0:assert not d['recovered_record_possible_log']
 with (HERE/f'{model}_same_cost_category_table.csv').open('x',newline='',encoding='utf-8') as f:
  fields=('acceptance','same_cost','category','count');writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
  for acceptance in ('prefix','completed'):
   cc=Counter((p[acceptance]['same_cost'],p[acceptance]['category']) for p in pairs)
   for (equal,category),count in sorted(cc.items()):writer.writerow({'acceptance':acceptance,'same_cost':equal,'category':category,'count':count})
with (HERE/'full_cohort_joint_table.csv').open('x',newline='',encoding='utf-8') as f:
 writer=csv.DictWriter(f,fieldnames=list(table[0]));writer.writeheader();writer.writerows(table)
totals={a:{field:sum(r[field] for r in table if r['acceptance']==a) for field in ('planned_pairs','equal_cost_pairs','joint_changes','role_changes','marginal_stable_joint_changes','same_cost_joint_changes','same_cost_canonical_oldview_unchanged','equal_families','proper_contraction','proper_expansion','overlap_incomparable','disjoint')} for a in ('prefix','completed')}
save(HERE/'summary_all_models.json',{'status':'FULL_FROZEN_PLAN_EXACT_BOTH_ACCEPTANCE','created_at_utc':datetime.now(timezone.utc).isoformat(),'model_count':5,'planned_word_inputs':resource['exact_words'],'planned_reference_restoration_pairs':resource['planned_pairs'],'acceptance_comparisons':resource['planned_pairs']*2,'censored_inputs':0,'totals':totals,'table':table,'joint_only_cases':joint_only,'unit_insertion_law_strata':dict(law),'scientific_output_bindings':[binding(HERE/f'{m}_{s}') for m in models for s in ('words.jsonl','pairs.jsonl','zdd.json','summary.json')]})
print(json.dumps({'totals':totals,'table':table},ensure_ascii=False,indent=2))
