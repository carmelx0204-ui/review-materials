from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import json,sys
from real_joint_exact import ZDD,binding,read,rows,save
HERE=Path(__file__).resolve().parent
MODELS=('bpi2013_IMf02','bpi2013_IMf03')
def freeze():
 paths=[Path(__file__),HERE/'real_joint_exact.py',HERE/'CROSS_REFERENCE_PROTOCOL.md']+[HERE/f'{m}_{s}.json' for m in MODELS for s in ('zdd',)]+[HERE/f'{m}_words.jsonl' for m in MODELS]
 save(HERE/'cross_reference_frozen.json',{'status':'FROZEN_BEFORE_CROSS_REFERENCE_J_AGGREGATION','created_at_utc':datetime.now(timezone.utc).isoformat(),'files':[binding(p) for p in paths]})
def run():
 for x in read(HERE/'cross_reference_frozen.json')['files']:assert binding(Path(x['path']))==x
 shared=ZDD();mapping={};words={}
 for model in MODELS:
  nodes=read(HERE/f'{model}_zdd.json')['nodes'];converted=[0,1]
  for u,node in enumerate(nodes[2:],2):
   v,lo,hi=node;assert lo<u and hi<u
   converted.append(shared.mk(v,converted[lo],converted[hi]))
  mapping[model]=converted;words[model]={w['variant_id']:w for w in rows(HERE/f'{model}_words.jsonl')}
 a,b=MODELS;assert words[a].keys()==words[b].keys();counts={};different=[]
 for acc in ('prefix','completed'):
  c=Counter()
  for vid,wa in words[a].items():
   wb=words[b][vid];assert wa['word']==wb['word'];x=wa['answer'][acc];y=wb['answer'][acc]
   rx=mapping[a][x['root']];ry=mapping[b][y['root']];cost=x['cost']!=y['cost'];roles=any(x[k]!=y[k] for k in ('possible_positions','mandatory_positions'));joint=rx!=ry
   c['planned_words']+=1;c[f'cost{int(cost)}_roles{int(roles)}_joint{int(joint)}']+=1
   if cost:c['cost_different']+=1
   if roles:c['roles_different']+=1
   if joint:c['joint_different']+=1
   if cost or roles:c['cost_or_roles_different']+=1
   if joint or cost or roles:c['any_cost_roles_or_joint_different']+=1
   if joint:
    meet=shared.intersection(rx,ry);category='proper_subset_IMf02' if meet==rx else 'proper_subset_IMf03' if meet==ry else 'disjoint' if meet==0 else 'overlap_incomparable';c[category]+=1
    different.append({'variant_id':vid,'word':wa['word'],'acceptance':acc,'IMf02_cost':x['cost'],'IMf03_cost':y['cost'],'roles_different':roles,'IMf02_family_count':shared.count(rx),'IMf03_family_count':shared.count(ry),'intersection_count':shared.count(meet),'family_category':category})
  counts[acc]=dict(c)
 save(HERE/'cross_reference_exact.json',{'status':'EXACT_SHARED_CANONICAL_MANAGER_COMPARISON','counts':counts,'joint_different_words':different})
 print(json.dumps(counts,ensure_ascii=False,indent=2))
if __name__=='__main__':freeze() if sys.argv[1]=='freeze' else run()
