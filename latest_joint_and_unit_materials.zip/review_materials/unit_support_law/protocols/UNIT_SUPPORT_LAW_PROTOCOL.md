# Additive restoration support law: verification plan

Written before new law aggregation. Existing experiments already exposed
bidirectional role changes and equal-cost revisions. This audit derives a
logical consequence of the additive alignment objective and checks it on the
complete frozen unit-cost workload. No fresh result selection is used.

## Fixed domain

The net, acceptance rule, and old occurrence order are fixed. One recovered
event is inserted at its original position, preserving old IDs. LOG and visible
MODEL moves cost one, SYNC and silent MODEL moves cost zero. Both PREFIX and
COMPLETED acceptance have the same accepting markings in the two versions.

Let d-/d+ denote optimum costs and J-/J+ the projected families of optimal
LOG-ID sets on common old IDs. Let delta=d+ minus d-.

## Proposed law and proof transformations

1. Inserting the recovered event as a LOG into any pre-alignment preserves its
   model execution and old LOG set, adding exactly one to its cost. Hence
   d+ <= d- + 1. If equality holds, each such extension is post-optimal,
   establishing J- subseteq J+.
2. A post-alignment consumes recovery by LOG or SYNC. Deleting a LOG gives a
   pre-alignment at cost d+-1; deleting a SYNC and relabelling that same model
   transition as MODEL gives a pre-alignment at cost d++1. Hence d- <= d++1.
   If d+=d--1, recovery cannot be a LOG in any post-optimum, and converting SYNC
   to MODEL establishes J+ subseteq J-.
3. If delta is zero, a post-optimal recovered LOG could be deleted to give a
   pre-alignment cheaper than d-, a contradiction. Thus recovery is SYNC in
   every post-optimum. This assertion also holds for delta=-1.

Consequently delta lies in {-1,0,1}. Delta=+1 permits only expansion of possible
old LOG membership and contraction of mandatory old LOG membership. Delta=-1
permits only contraction of possible and expansion of mandatory membership.
At delta=0 there is no inclusion law supplied by these transformations.

The same argument has additive LOG penalty lambda>0 and visible MODEL penalty
mu>0 bounds [-mu,lambda]; the unit experiment is the fully tested domain.
Gap-dependent penalties have different insertion/removal effects and are
analyzed separately in the manuscript.

## Complete verification

All five frozen references and both acceptance rules; all 29,817 comparisons
per acceptance. Read actual costs and old-ID role sets, not saved change flags.
Check delta support, P/M inclusion consequences, and recovered LOG membership.
Count exact statuses and every negative, equality, strict inclusion, and
incomparability result. Preserve distinct cases and all pair IDs.
Verify full J inclusion independently using the new exact ZDD family outputs;
compare every cost and P/M answer with the previous native outputs. Save all
violations (expected zero if the stated domain and implementation agree).

## Operational interpretation

At delta=+1 every stored pre-optimal old-record LOG pattern remains admissible,
while its uniqueness or mandatory assertions may change. At delta=-1 every
post-optimal old pattern was previously admissible, while a stored pre-pattern
may have been eliminated. At delta=0 the score supplies no set inclusion
certificate; classify equality, strict inclusion, and incomparable families.
These are exact facts about optimal explanations, not business correctness,
user outcomes, or a measured performance improvement.
