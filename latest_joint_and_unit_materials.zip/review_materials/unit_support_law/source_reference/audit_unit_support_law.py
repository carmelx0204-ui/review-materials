"""Verify additive restoration implications from original complete P/M outputs.

No optimizer is called. Run freeze before run. Files are exclusive creations.
Full-J verification is an independent experiment in ../real_joint.
"""
from __future__ import annotations
import argparse
from collections import Counter, defaultdict
import csv
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
STUDY = HERE.parents[1]
EXT = STUDY / "experimental_extension_2026-10-10_v1"
COMPLETION = STUDY / "acceptance_strengthening_2026-10-18_v1/completion_numerical"
MODELS = ("bpi2013_IMf01", "bpi2013_IMf02", "bpi2013_IMf03", "traffic_IM0", "traffic_IMf02")

def rows(p):
    with p.open(encoding="utf-8") as stream:
        for line in stream:
            yield json.loads(line)

def bind(p):
    b = p.read_bytes()
    return {"path": str(p.resolve()), "bytes": len(b), "sha256": hashlib.sha256(b).hexdigest()}

def save(p, x):
    with p.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(x, stream, ensure_ascii=False, indent=2)
        stream.write("\n")

def inputs():
    return [Path(__file__), HERE / "UNIT_SUPPORT_LAW_PROTOCOL.md", HERE / "PROTOCOL.md"] + [
        base / f"{model}_pairs.jsonl" for model in MODELS for base in (EXT, COMPLETION)]

def freeze():
    save(HERE / "law_frozen_inputs.json", {"status": "FROZEN_BEFORE_LAW_AGGREGATION",
        "utc": datetime.now(timezone.utc).isoformat(), "files": [bind(p) for p in inputs()],
        "planned_per_acceptance": 29817, "acceptance": ["prefix", "completed"]})

def verify():
    doc = json.loads((HERE / "law_frozen_inputs.json").read_text(encoding="utf-8"))
    for item in doc["files"]:
        assert bind(Path(item["path"])) == item, item["path"]

def run():
    verify()
    aggregates = []
    violations = []
    representatives = {}
    with (HERE / "unit_law_all_pair_checks.jsonl").open("x", encoding="utf-8", newline="\n") as out:
        for model in MODELS:
            original = {r["pair_id"]: r for r in rows(EXT / f"{model}_pairs.jsonl")}
            grouped = defaultdict(Counter)
            cases = defaultdict(lambda: defaultdict(set))
            for record in rows(COMPLETION / f"{model}_pairs.jsonl"):
                pair_id, cid = record["pair_id"], record["case"]
                assert record["status"] == "EXACT_PAIR"
                for side in ("before", "after"):
                    for key in ("cost", "possible_log_ids", "mandatory_log_ids"):
                        assert original[pair_id][side][key] == record["prefix"][side][key]
                old = set(record["old_ids"])
                recovered = record["delayed_record_id"]
                assert recovered not in old
                for acceptance in ("prefix", "completed"):
                    b, a = record[acceptance]["before"], record[acceptance]["after"]
                    p0, m0 = set(b["possible_log_ids"]), set(b["mandatory_log_ids"])
                    p1, m1 = set(a["possible_log_ids"]) & old, set(a["mandatory_log_ids"]) & old
                    assert m0 <= p0 <= old and m1 <= p1 <= old
                    delta = a["cost"] - b["cost"]
                    flags = {
                        "old_roles_changed": p0 != p1 or m0 != m1,
                        "possible_gained": bool(p1 - p0),
                        "possible_withdrawn": bool(p0 - p1),
                        "mandatory_gained": bool(m1 - m0),
                        "mandatory_withdrawn": bool(m0 - m1),
                        "recovery_possible_log": recovered in set(a["possible_log_ids"]),
                        "recovery_mandatory_log": recovered in set(a["mandatory_log_ids"]),
                        "marginal_support_expands": p0 <= p1 and m1 <= m0,
                        "marginal_support_contracts": p1 <= p0 and m0 <= m1,
                    }
                    flags["marginal_support_incomparable"] = not flags["marginal_support_expands"] and not flags["marginal_support_contracts"]
                    errors = []
                    if delta not in (-1, 0, 1): errors.append("UNIT_LIPSCHITZ")
                    if delta == 1 and not flags["marginal_support_expands"]: errors.append("PLUS_ONE_EXPANSION")
                    if delta == -1 and not flags["marginal_support_contracts"]: errors.append("MINUS_ONE_CONTRACTION")
                    if delta <= 0 and flags["recovery_possible_log"]: errors.append("NONPOSITIVE_RECOVERY_MUST_SYNC")
                    if delta == 1 and not flags["recovery_possible_log"]: errors.append("PLUS_ONE_RECOVERY_MUST_POSSIBLE_LOG")
                    if flags["marginal_support_incomparable"] and delta != 0: errors.append("INCOMPARABLE_REQUIRES_ZERO_DELTA")
                    answer = {"model": model, "acceptance": acceptance, "pair_id": pair_id, "case": cid,
                        "position": record["position"], "before_cost": b["cost"], "after_cost": a["cost"],
                        "delta": delta, **flags, "violations": errors}
                    out.write(json.dumps(answer, ensure_ascii=False, separators=(",", ":")) + "\n")
                    if errors: violations.append(answer)
                    for group in ("all", f"delta_{delta:+d}"):
                        key = (acceptance, group)
                        grouped[key]["pairs"] += 1
                        cases[key]["cases"].add(cid)
                        for flag, truth in flags.items():
                            grouped[key][flag] += int(truth)
                            if truth: cases[key][flag + "_cases"].add(cid)
                    categories = [f"delta_{delta:+d}_changed" if flags["old_roles_changed"] else f"delta_{delta:+d}_stable"]
                    if flags["marginal_support_incomparable"]: categories.append("marginal_incomparable")
                    for category in categories:
                        key = f"{model}/{acceptance}/{category}"
                        if key not in representatives:
                            representatives[key] = {**answer, "old_ids": sorted(old), "recovered_id": recovered,
                                "before": b, "after": a}
            for (acceptance, group), count in grouped.items():
                aggregates.append({"model": model, "acceptance": acceptance, "group": group,
                    **dict(count), **{k: len(v) for k, v in cases[(acceptance, group)].items()}})
    save(HERE / "unit_law_summary.json", {"status": "PASS" if not violations else "FAIL",
        "scope": "ALL_29817_PAIRS_PER_ACCEPTANCE_NATIVE_P_M", "aggregates": aggregates,
        "violations": violations, "joint_support_check": "SEPARATE_EXACT_J_AUDIT",
        "outputs": [bind(HERE / "unit_law_all_pair_checks.jsonl")]})
    save(HERE / "unit_law_representatives.json", representatives)
    fields = sorted(set().union(*(r.keys() for r in aggregates)))
    with (HERE / "unit_law_summary.csv").open("x", encoding="utf-8", newline="") as out:
        writer = csv.DictWriter(out, fields)
        writer.writeheader(); writer.writerows(aggregates)
    verify()
    print(json.dumps({"status": "PASS" if not violations else "FAIL", "violations": len(violations),
        "strata": len(aggregates), "total_comparisons": sum(r["pairs"] for r in aggregates if r["group"] == "all")}))

if __name__ == "__main__":
    parser = argparse.ArgumentParser(); parser.add_argument("mode", choices=["freeze", "run"])
    args = parser.parse_args(); freeze() if args.mode == "freeze" else run()
