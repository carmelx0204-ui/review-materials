"""Independent family-inclusion checks from serialized nodes, not producer APIs.

The checker reconstructs set-family inclusion by matching the earliest variable.
It cross-checks P/M with the prior independent numeric solver for all pairs.
It does not certify the source optimizer's completeness by itself.
"""
from __future__ import annotations
from collections import Counter, defaultdict
from datetime import datetime, timezone
from functools import cache
import hashlib
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
SOURCE=HERE.parent/"real_joint"
OLD=HERE.parents[1]/"acceptance_strengthening_2026-10-18_v1/completion_numerical"
MODELS=("bpi2013_IMf01","bpi2013_IMf02","bpi2013_IMf03","traffic_IM0","traffic_IMf02")

def bind(p):
    data=p.read_bytes();return {"path":str(p.resolve()),"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest()}
def save(p,x):
    with p.open("x",encoding="utf-8",newline="\n") as f:json.dump(x,f,ensure_ascii=False,indent=2);f.write("\n")
def rows(p):
    with p.open(encoding="utf-8") as f:
        for line in f:yield json.loads(line)
def inputs():
    return [Path(__file__),HERE/"UNIT_SUPPORT_LAW_PROTOCOL.md"]+[p for m in MODELS for p in (
        SOURCE/f"{m}_zdd.json",SOURCE/f"{m}_pairs.jsonl",SOURCE/f"{m}_summary.json",OLD/f"{m}_pairs.jsonl")]
def freeze():
    save(HERE/"joint_law_independent_frozen_v2.json",{"status":"FROZEN_BEFORE_INDEPENDENT_FAMILY_INCLUSION_CHECKS",
        "utc":datetime.now(timezone.utc).isoformat(),"files":[bind(p) for p in inputs()]})
def verify():
    for item in json.loads((HERE/"joint_law_independent_frozen_v2.json").read_text(encoding="utf-8"))["files"]:assert bind(Path(item["path"]))==item
def run():
    verify();aggregate=[];checks=[];violations=[]
    with (HERE/"joint_law_independent_pair_checks_v2.jsonl").open("x",encoding="utf-8",newline="\n") as out:
        for model in MODELS:
            nodes=json.loads((SOURCE/f"{model}_zdd.json").read_text(encoding="utf-8"))["nodes"]
            for i,node in enumerate(nodes):
                if i<2:assert node is None;continue
                v,lo,hi=node;assert v>=0 and 0<=lo<i and 0<hi<i
                for child in (lo,hi):
                    if child>1:assert nodes[child][0]>v
            @cache
            def inc(a,b):
                if a==0 or a==b:return True
                if b==0:return False
                av=nodes[a][0] if a>1 else 10**9;bv=nodes[b][0] if b>1 else 10**9
                if av==10**9 and bv==10**9:return a==b
                v=min(av,bv)
                al,ah=(nodes[a][1],nodes[a][2]) if av==v else (a,0)
                bl,bh=(nodes[b][1],nodes[b][2]) if bv==v else (b,0)
                return inc(al,bl) and inc(ah,bh)
            @cache
            def pm(root):
                if root<2:return 0,0
                v,lo,hi=nodes[root];p,m=pm(hi);p|=1<<v;m|=1<<v
                if lo:
                    pl,ml=pm(lo);return p|pl,m&ml
                return p,m
            @cache
            def cardinality(root):
                return 0 if root==0 else 1 if root==1 else cardinality(nodes[root][1])+cardinality(nodes[root][2])
            def membership(root,mask):
                while root>1:
                    v,lo,hi=nodes[root]
                    if mask&((1<<v)-1):return False
                    if mask&(1<<v):mask^=1<<v;root=hi
                    else:root=lo
                return root==1 and mask==0
            old={r["pair_id"]:r for r in rows(OLD/f"{model}_pairs.jsonl")}
            counts=defaultdict(Counter);cases=defaultdict(lambda:defaultdict(set));n=0
            for pair in rows(SOURCE/f"{model}_pairs.jsonl"):
                assert pair["status"]=="EXACT_PAIR";prior=old[pair["pair_id"]];assert prior["status"]=="EXACT_PAIR"
                ids=pair["old_ids"];assert ids==prior["old_ids"]
                for acceptance in ("prefix","completed"):
                    a=pair[acceptance];b=prior[acceptance];r0,r1=a["before_root"],a["projected_after_root"]
                    assert r0 and r1
                    p0,m0=pm(r0);p1,m1=pm(r1)
                    assert not ((p0|p1)>>len(ids))
                    def mapped(mask):return {rid for i,rid in enumerate(ids) if mask&(1<<i)}
                    common=set(ids)
                    assert mapped(p0)==set(b["before"]["possible_log_ids"])
                    assert mapped(m0)==set(b["before"]["mandatory_log_ids"])
                    assert mapped(p1)==set(b["after"]["possible_log_ids"])&common
                    assert mapped(m1)==set(b["after"]["mandatory_log_ids"])&common
                    assert a["before_cost"]==b["before"]["cost"] and a["after_cost"]==b["after"]["cost"]
                    fwd,rev=inc(r0,r1),inc(r1,r0)
                    assert fwd==a["before_subset_after"] and rev==a["after_subset_before"]
                    assert cardinality(r0)==a["before_family_count"] and cardinality(r1)==a["after_projected_family_count"]
                    delta=a["after_cost"]-a["before_cost"]
                    category="equal" if fwd and rev else "proper_expansion" if fwd else "proper_contraction" if rev else "incomparable"
                    assert category==a["category"] or (category=="incomparable" and a["category"] in ("disjoint","overlap_incomparable"))
                    errors=[]
                    if delta not in (-1,0,1):errors.append("LIPSCHITZ")
                    if delta==1 and not fwd:errors.append("PLUS_ONE_INCLUSION")
                    if delta==-1 and not rev:errors.append("MINUS_ONE_INCLUSION")
                    recovered_p=bool(pm(a["after_root"])[0]&(1<<pair["position"]))
                    assert recovered_p==a["recovered_record_possible_log"]
                    if (delta<=0 and recovered_p) or (delta==1 and not recovered_p):errors.append("RECOVERY_ROLE")
                    assert membership(r0,a["canonical_before_mask"])
                    assert membership(r1,a["canonical_before_mask"])==a["canonical_before_remains_admissible"]
                    if delta==1 and not membership(r1,a["canonical_before_mask"]):errors.append("SAVED_PATTERN_VALIDITY")
                    record={"model":model,"acceptance":acceptance,"pair_id":pair["pair_id"],"case":pair["case"],
                        "delta":delta,"category":category,"before_subset_after":fwd,"after_subset_before":rev,
                        "family_counts":[cardinality(r0),cardinality(r1)],"violations":errors}
                    out.write(json.dumps(record,separators=(",",":"))+"\n");n+=1
                    if errors:violations.append(record)
                    for group in ("all",f"delta_{delta:+d}"):
                        key=(acceptance,group);counts[key]["pairs"]+=1;counts[key][category]+=1;cases[key]["cases"].add(pair["case"]);cases[key][category+"_cases"].add(pair["case"])
            aggregate.extend({"model":model,"acceptance":a,"group":g,**dict(c),**{k:len(v) for k,v in cases[(a,g)].items()}} for (a,g),c in counts.items())
            checks.append({"model":model,"pair_queries":n,"nodes_checked":len(nodes),"inclusion_cache":str(inc.cache_info())})
    verify();save(HERE/"joint_law_independent_summary_v2.json",{"status":"PASS" if not violations else "FAIL",
        "checked_scope":"SERIALIZED_J_FAMILIES_AND_PRIOR_NATIVE_P_M_ALL_59634_QUERIES",
        "optimizer_completeness":"SEPARATE_RAW_PRODUCT_RECONSTRUCTION_REQUIRED",
        "aggregates":aggregate,"models":checks,"violations":violations,"outputs":[bind(HERE/"joint_law_independent_pair_checks_v2.jsonl")]})
    print(json.dumps({"status":"PASS" if not violations else "FAIL","queries":sum(x["pair_queries"] for x in checks),"violations":len(violations)}))
if __name__=="__main__":freeze() if sys.argv[1]=="freeze" else run()
