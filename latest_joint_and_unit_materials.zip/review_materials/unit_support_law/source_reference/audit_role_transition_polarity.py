"""Full old-record role transition counts, fixed sign/polarity test."""
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
OLD = HERE.parents[1] / "acceptance_strengthening_2026-10-18_v1/completion_numerical"
MODELS = ("bpi2013_IMf01", "bpi2013_IMf02", "bpi2013_IMf03", "traffic_IM0", "traffic_IMf02")

def bind(p):
    b=p.read_bytes();return {"path":str(p.resolve()),"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()}
def save(p,x):
    with p.open("x",encoding="utf-8") as f:json.dump(x,f,ensure_ascii=False,indent=2);f.write("\n")
def input_paths():
    return [Path(__file__),HERE/"UNIT_SUPPORT_LAW_PROTOCOL.md"]+[OLD/f"{m}_pairs.jsonl" for m in MODELS]
def freeze():
    save(HERE/"polarity_frozen_inputs.json",{"utc":datetime.now(timezone.utc).isoformat(),
        "status":"FROZEN_BEFORE_TRANSITION_AGGREGATION","files":[bind(p) for p in input_paths()],
        "query":"Count S/A/L old-record transitions by costdelta; +1 onlyS->A/L->A, -1 onlyA->S/A->L, anyforcedS<->L requiresdelta0. Countallpairsandcases; preserveallnegativecomparisons."})
def verify():
    for item in json.loads((HERE/"polarity_frozen_inputs.json").read_text(encoding="utf-8"))["files"]:assert bind(Path(item["path"]))==item
def run():
    verify();summaries=[];examples={};violations=[]
    for model in MODELS:
        grouped=defaultdict(Counter);cases=defaultdict(lambda:defaultdict(set))
        with (OLD/f"{model}_pairs.jsonl").open(encoding="utf-8") as f:
            for line in f:
                r=json.loads(line);assert r["status"]=="EXACT_PAIR"
                for acceptance in ("prefix","completed"):
                    ans=r[acceptance];b,a=ans["before"],ans["after"];delta=a["cost"]-b["cost"]
                    key=(acceptance,delta);count=grouped[key];count["pairs"]+=1;cases[key]["cases"].add(r["case"])
                    p0,m0,p1,m1=(set(z[k]) for z,k in [(b,"possible_log_ids"),(b,"mandatory_log_ids"),(a,"possible_log_ids"),(a,"mandatory_log_ids")])
                    per=Counter()
                    for rid in r["old_ids"]:
                        x="L" if rid in m0 else "A" if rid in p0 else "S"
                        y="L" if rid in m1 else "A" if rid in p1 else "S"
                        trans=f"{x}->{y}";count[trans]+=1;per[trans]+=1
                        if x!=y and ((delta==1 and trans not in ("S->A","L->A")) or (delta==-1 and trans not in ("A->S","A->L"))):violations.append([model,acceptance,r["pair_id"],rid,delta,trans])
                    if per["S->L"] or per["L->S"]:
                        count["forced_flip_pairs"]+=1;cases[key]["forced_flip_cases"].add(r["case"])
                        exkey=f"{model}/{acceptance}/forced_flip"
                        if exkey not in examples:examples[exkey]={"pair":r,"delta":delta,"transitions":dict(per)}
                    for trans in per:
                        if trans[0]!=trans[-1]:cases[key][trans+"_cases"].add(r["case"])
        for (a,d),counts in grouped.items():summaries.append({"model":model,"acceptance":a,"delta":d,"counts":dict(counts),"cases":{k:len(v) for k,v in cases[(a,d)].items()}})
    verify();save(HERE/"polarity_summary.json",{"status":"PASS" if not violations else "FAIL","summaries":summaries,"violations":violations})
    save(HERE/"polarity_representatives.json",examples)
    print(json.dumps({"status":"PASS" if not violations else "FAIL","violations":len(violations),"strata":len(summaries)}))
if __name__=="__main__":freeze() if sys.argv[1]=="freeze" else run()
