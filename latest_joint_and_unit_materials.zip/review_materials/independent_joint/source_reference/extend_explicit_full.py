"""Frozen outcome-independent complement to the short-word explicit oracle."""
import independent_joint_explicit as core
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from time import perf_counter
import json
import sys

HERE=Path(__file__).resolve().parent
def freeze():
    core.verify()
    core.save(HERE/'explicit_full_extension_frozen.json',{
        'created_at_utc':datetime.now(timezone.utc).isoformat(),
        'files':[core.binding(Path(__file__)),core.binding(HERE/'EXPLICIT_FULL_EXTENSION_PROTOCOL.md'),
                 core.binding(HERE/'independent_joint_frozen.json')],
        'all_remaining_words':True,'minimum_word_length':10,'pair_guard':core.CAP})
def verify():
    core.verify()
    for item in core.read(HERE/'explicit_full_extension_frozen.json')['files']:
        assert core.binding(item['path'])==item,item['path']
def run(model):
    verify();start=perf_counter()
    doc=core.read(core.MODEL_PATHS[model]);edges,rev,final=core.original_graph(doc)
    cohort='bpi2013' if model.startswith('bpi') else 'traffic'
    plan=core.read(core.EXT/f'plan_{cohort}.json');counts=Counter();path=HERE/f'{model}_explicit_long.jsonl'
    with path.open('x',encoding='utf-8') as stream:
        for v in plan['variants']:
            if len(v['word'])<=9:continue
            row={'variant_id':v['variant_id'],'word':v['word']}
            for acceptance in ('prefix','completed'):
                answer=core.explicit_family(v['word'],edges,rev,final,acceptance)
                row[acceptance]=answer;counts[acceptance+'_'+answer['status']]+=1
            stream.write(json.dumps(row,ensure_ascii=False,separators=(',',':'))+'\n')
            if sum(counts.values())%200==0:
                stream.flush();print(json.dumps({'model':model,'counts':dict(counts),'seconds':round(perf_counter()-start,2)}),flush=True)
    verify();summary={'status':'INDEPENDENT_EXPLICIT_LONG_POPULATION_COMPLETED','model':model,
        'counts':dict(counts),'graph_original_integer_arcs_match_stored':True,
        'elapsed_seconds':perf_counter()-start,'output':core.binding(path)}
    core.save(HERE/f'{model}_explicit_long_summary.json',summary);print(json.dumps(summary),flush=True)
if __name__=='__main__':
    if sys.argv[1]=='freeze':freeze()
    else:run(sys.argv[1])
