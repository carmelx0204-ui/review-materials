"""Post-hoc direct original-arc witnesses for the two real joint-only updates."""
from heapq import heappop,heappush
from pathlib import Path
from datetime import datetime, timezone
import independent_joint_explicit as core
import json

HERE=Path(__file__).resolve().parent
def constrained(word,ids,edges,final,mask,wildcard=None):
    n=len(word);m=len(edges);target=n*m+final
    d={0:0};pred={};heap=[(0,0)]
    while heap:
        du,u=heappop(heap)
        if d[u]!=du:continue
        if u==target:break
        i,p=divmod(u,m)
        candidates=[]
        for q,w,label,ti in edges[p]:
            candidates.append((i*m+q,w,'TAU' if label is None else 'MODEL',ti,None))
            if i<n and label is not None and label==word[i] and (i==wildcard or not(mask>>i&1)):
                candidates.append(((i+1)*m+q,0,'SYNC',ti,ids[i]))
        if i<n and (i==wildcard or mask>>i&1):candidates.append(((i+1)*m+p,1,'LOG',None,ids[i]))
        for v,w,kind,ti,record in candidates:
            nd=du+w
            if nd<d.get(v,core.INF):
                d[v]=nd;pred[v]=(u,kind,ti,record);heappush(heap,(nd,v))
    assert target in d
    steps=[];u=target
    while u:
        previous,kind,ti,record=pred[u]
        steps.append({'kind':kind,'transition_index':ti,'record_id':record,
            'before_marking_index':previous%m,'after_marking_index':u%m})
        u=previous
    steps.reverse()
    assert sum(x['kind'] in ('MODEL','LOG') for x in steps)==d[target]
    return {'cost':d[target],'steps':steps}

def main():
    core.verify();model='bpi2013_IMf02';doc=core.read(core.MODEL_PATHS[model])
    edges,rev,final=core.original_graph(doc);trans=doc['net_doc']['transitions']
    # Recover local marking tuples through an independent BFS with the same enabled-arc order.
    markings=[tuple(doc['net_doc']['initial'])];index={markings[0]:0};cursor=0
    while cursor<len(markings):
        marking=markings[cursor]
        for t in trans:
            if all(a>=b for a,b in zip(marking,t['pre'])):
                q=tuple(a-b+c for a,b,c in zip(marking,t['pre'],t['post']))
                if q not in index:index[q]=len(markings);markings.append(q)
        cursor+=1
    plan=core.read(core.EXT/'plan_bpi2013.json');pairs={p['pair_id']:p for p in plan['pairs']};cases={c['id']:c for c in plan['cases']}
    checks=[]
    for pid in (5651,5652):
        pair=pairs[pid];p=pair['position'];events=cases[pair['case']]['events']
        ids=[e['id'] for e in events];oldids=[r for i,r in enumerate(ids) if i!=p]
        for oldmask in range(4):
            for side,vid,wordids,wildcard in [('before',pair['before_variant'],oldids,None),('after',pair['after_variant'],ids,p)]:
                word=plan['variants'][vid]['word']
                constraint=oldmask if side=='before' else (oldmask&((1<<p)-1))|((oldmask>>p)<<(p+1))
                answer=constrained(word,wordids,edges,final,constraint,wildcard)
                actual=[];logs=[]
                for step in answer['steps']:
                    before=markings[step['before_marking_index']];after=markings[step['after_marking_index']]
                    ti=step['transition_index']
                    if ti is None:assert before==after
                    else:
                        t=trans[ti];assert all(a>=b for a,b in zip(before,t['pre']))
                        assert after==tuple(a-b+c for a,b,c in zip(before,t['pre'],t['post']))
                        step.update(transition_id=t['id'],transition_label=t['label'])
                    if step['record_id'] is not None:
                        actual.append(step['record_id'])
                        if step['kind']=='LOG':logs.append(step['record_id'])
                assert actual==wordids
                gotmask=sum(1<<i for i,r in enumerate(oldids) if r in logs);assert gotmask==oldmask
                checks.append({'pair_id':pid,'side':side,'old_mask':oldmask,'old_ids':oldids,
                    'word':word,'all_record_ids':wordids,'actual_log_ids':logs,**answer})
    result={'status':'PASS_ALL_EIGHT_OLD_MASKS_IN_BOTH_VERSIONS_ORIGINAL_ARC_REPLAY',
        'created_at_utc':datetime.now(timezone.utc).isoformat(),'model':model,'completed_acceptance':True,
        'posthoc_representative_analysis':True,'constrained_solves':len(checks),'checks':checks,
        'script':core.binding(Path(__file__)),'model_binding':core.binding(core.MODEL_PATHS[model])}
    core.save(HERE/'real_joint_original_arc_witnesses.json',result)
    print(json.dumps({'status':result['status'],'solves':len(checks),
        'costs':[{'pair':r['pair_id'],'side':r['side'],'mask':r['old_mask'],'cost':r['cost'],
                 'visible_moves':[(s['kind'],s.get('transition_label'),s['record_id']) for s in r['steps'] if s['kind']!='TAU']} for r in checks]},ensure_ascii=False))
if __name__=='__main__':main()
