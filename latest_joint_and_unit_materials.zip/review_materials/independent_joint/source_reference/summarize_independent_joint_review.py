"""Bind all independent checks into one concise review receipt."""
from pathlib import Path
from datetime import datetime, timezone
import independent_joint_explicit as core
import json

HERE=Path(__file__).resolve().parent
def main():
    core.verify();receipts=[HERE/f'{model}_joint_independent_review.json' for model in core.MODEL_PATHS]
    data=[core.read(p) for p in receipts]
    assert all(r['status']=='PASS_FULL_POPULATION_EXPLICIT_FAMILY_CHECK' and r['zero_resource_guards'] for r in data)
    endpoints=sum(sum(r['endpoint_counts'].values()) for r in data)
    pairs=sum(sum(c['pairs'] for c in r['pair_counts'].values()) for r in data)
    assert endpoints==18318 and pairs==59634
    algebra=HERE/'zdd_algebra_independent_review.json';cross=HERE/'cross_reference_literal_review.json'
    witnesses=[HERE/'real_joint_original_arc_witnesses.json',HERE/'cross_reference_original_arc_witnesses.json']
    extra=[algebra,cross,*witnesses]
    result={'status':'PASS_INDEPENDENT_COMPLETE_REAL_JOINT_AUDIT',
        'created_at_utc':datetime.now(timezone.utc).isoformat(),'models':len(data),
        'structural_model_word_inputs':9159,'acceptance_endpoint_answers':endpoints,
        'model_restoration_positions':29817,'acceptance_pair_comparisons':pairs,
        'entire_endpoint_families_compared_as_literal_mask_sets':True,
        'all_graphs_rebuilt_from_original_integer_arcs':True,'zero_resource_guards':True,
        'all_pair_projection_comparison_and_support_nesting_verified':True,
        'zdd_binary_algebra_checks':core.read(algebra)['binary_operations_checked'],
        'cross_reference_full_word_comparison':core.read(cross)['results'],
        'original_arc_constrained_representative_solves':sum(core.read(p)['constrained_solves'] for p in witnesses),
        'selector_scope':'Fixed lexicographic selection of OLD-RECORD projected diagnostic patterns; no native selected-alignment claim. At equal costs restored record is forcedSYNC, so selection and projection commute.',
        'individual_reviews':[core.binding(p) for p in receipts+extra],
        'checker':core.binding(Path(__file__))}
    core.save(HERE/'independent_joint_review_complete.json',result)
    print(json.dumps({k:v for k,v in result.items() if k not in ('individual_reviews','cross_reference_full_word_comparison','checker')}))
if __name__=='__main__':main()
