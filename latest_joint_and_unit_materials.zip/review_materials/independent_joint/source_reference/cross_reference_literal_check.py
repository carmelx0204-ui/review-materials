"""Independent .2/.3 comparison from explicit masks, never symbolic node IDs."""
from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import independent_joint_explicit as core
import json

HERE=Path(__file__).resolve().parent
def rows(path):
    with Path(path).open(encoding='utf-8') as f:return [json.loads(s) for s in f if s.strip()]
def main():
    core.verify();inputpaths=[];data={}
    producerfreeze=HERE.parent/'real_joint'/'cross_reference_frozen.json';assert producerfreeze.exists()
    for model in ('bpi2013_IMf02','bpi2013_IMf03'):
        paths=[HERE/f'{model}_explicit_{part}.jsonl' for part in ('base','long')]
        inputpaths.extend(paths);data[model]={r['variant_id']:r for p in paths for r in rows(p)}
    assert set(data['bpi2013_IMf02'])==set(data['bpi2013_IMf03']) and len(data['bpi2013_IMf02'])==3011
    results={}
    for acceptance in ('prefix','completed'):
        counts=Counter();examples=[]
        for vid,r2 in data['bpi2013_IMf02'].items():
            r3=data['bpi2013_IMf03'][vid];assert r2['word']==r3['word']
            a=r2[acceptance];b=r3[acceptance];assert a['status']==b['status']=='EXPLICIT_COMPLETE'
            fa=frozenset(a['family_masks']);fb=frozenset(b['family_masks'])
            cost=a['cost']!=b['cost'];roles=any(a[k]!=b[k] for k in ('possible_positions','mandatory_positions'));joint=fa!=fb
            key=f'cost_{int(cost)}_roles_{int(roles)}_joint_{int(joint)}';counts[key]+=1
            counts['words']+=1;counts['cost_differences']+=int(cost);counts['role_differences']+=int(roles);counts['joint_differences']+=int(joint)
            counts['cost_or_roles_differences']+=int(cost or roles)
            counts['joint_only_at_same_cost_and_roles']+=int(joint and not cost and not roles)
            counts['joint_differences_at_same_roles']+=int(joint and not roles)
            relation=('equal' if fa==fb else 'point2_subset_point3' if fa<fb else 'point3_subset_point2' if fb<fa else 'disjoint' if not fa&fb else 'overlap_incomparable')
            counts['relation_'+relation]+=1
            if joint and not roles:examples.append({'variant_id':vid,'word':r2['word'],'cost2':a['cost'],'cost3':b['cost'],'J2':sorted(fa),'J3':sorted(fb),'cost_same':not cost})
        results[acceptance]={'counts':dict(counts),'joint_difference_same_roles_examples':examples}
    result={'status':'PASS_INDEPENDENT_LITERAL_ALL_WORD_CROSS_REFERENCE_COMPARISON',
        'created_at_utc':datetime.now(timezone.utc).isoformat(),'results':results,
        'inputs':[core.binding(p) for p in [producerfreeze,*inputpaths]],'checker':core.binding(Path(__file__))}
    core.save(HERE/'cross_reference_literal_review.json',result)
    print(json.dumps({a:r['counts'] for a,r in results.items()}))
if __name__=='__main__':main()
