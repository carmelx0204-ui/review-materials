"""Independent explicit-mask oracle; imports no producer solver or ZDD code."""
from collections import Counter, deque
from datetime import datetime, timezone
from heapq import heappush, heappop
from pathlib import Path
from time import perf_counter
import hashlib
import json
import sys

HERE=Path(__file__).resolve().parent
STUDY=HERE.parent.parent
EXT=STUDY/'experimental_extension_2026-10-10_v1'
MODEL_PATHS={
 'bpi2013_IMf01':EXT/'bpi2013_IMf01_model.json',
 'bpi2013_IMf02':STUDY/'bpi2013_model_IMf02.json',
 'bpi2013_IMf03':EXT/'bpi2013_IMf03_model.json',
 'traffic_IM0':STUDY/'traffic_model_IM0.json',
 'traffic_IMf02':STUDY/'traffic_model_IMf02.json',
}
CAP=2000000
INF=10**12

def read(path):return json.loads(Path(path).read_text(encoding='utf-8'))
def binding(path):
    path=Path(path);raw=path.read_bytes()
    return {'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def save(path,data):
    with Path(path).open('x',encoding='utf-8') as f:json.dump(data,f,ensure_ascii=False,indent=2)
def freeze():
    paths=[Path(__file__),HERE/'INDEPENDENT_JOINT_PROTOCOL.md',*MODEL_PATHS.values(),
           EXT/'plan_bpi2013.json',EXT/'plan_traffic.json']
    save(HERE/'independent_joint_frozen.json',{'created_at_utc':datetime.now(timezone.utc).isoformat(),
        'files':[binding(p) for p in paths],'pair_guard':CAP,'base_maximum_word_length':9})
def verify():
    for item in read(HERE/'independent_joint_frozen.json')['files']:
        assert binding(item['path'])==item,item['path']

def original_graph(doc):
    """Re-execute enabled integer arcs, then compare labelled original edges."""
    net=doc['net_doc'];trans=net['transitions'];initial=tuple(net['initial'])
    markings=[initial];index={initial:0};edges=[];q=0
    while q<len(markings):
        marking=markings[q];out=[]
        for ti,t in enumerate(trans):
            assert all(isinstance(x,int) and x>=0 for x in t['pre']+t['post'])
            if all(a>=b for a,b in zip(marking,t['pre'])):
                target=tuple(a-b+c for a,b,c in zip(marking,t['pre'],t['post']))
                if target not in index:
                    assert len(markings)<100000
                    index[target]=len(markings);markings.append(target)
                out.append((index[target],int(t['label'] is not None),t['label'],ti))
        edges.append(out);q+=1
    stored=doc['graph'];stored_markings=[tuple(x) for x in stored['markings']]
    assert set(markings)==set(stored_markings)
    for u,marking in enumerate(markings):
        su=stored_markings.index(marking)
        got={(ti,markings[v]) for v,w,label,ti in edges[u]}
        expected={(ti,stored_markings[v]) for ti,v in stored['edges'][su]}
        assert got==expected,(u,got^expected)
    reverse=[[] for _ in markings]
    for u,ee in enumerate(edges):
        for v,w,label,ti in ee:reverse[v].append((u,w,label,ti))
    return edges,reverse,index[tuple(doc['final'])]

def outgoing(state,word,edges,backward=False):
    m=len(edges);i,p=divmod(state,m);n=len(word)
    have=i>0 if backward else i<n
    nexti=i-1 if backward else i+1
    label=word[i-1 if backward else i] if have else None
    for v,w,tl,ti in edges[p]:
        yield i*m+v,w,0
        if have and tl is not None and tl==label:
            yield nexti*m+v,0,0
    if have:yield nexti*m+p,1,1<<(i-1 if backward else i)

def dijkstra(word,edges,seeds,backward=False):
    size=(len(word)+1)*len(edges);d=[INF]*size;heap=[]
    for s in seeds:d[s]=0;heappush(heap,(0,s))
    while heap:
        du,u=heappop(heap)
        if du!=d[u]:continue
        for v,w,mask in outgoing(u,word,edges,backward):
            nd=du+w
            if nd<d[v]:d[v]=nd;heappush(heap,(nd,v))
    return d

def explicit_family(word,edges,reverse,final,acceptance):
    m=len(edges);n=len(word);targets=list(range(n*m,(n+1)*m)) if acceptance=='prefix' else [n*m+final]
    forward=dijkstra(word,edges,[0]);backward=dijkstra(word,reverse,targets,True)
    optimum=min(forward[x] for x in targets);assert optimum<INF
    seen=[set() for _ in forward];seen[0].add(0);queue=deque([(0,0)])
    visits=1;family=set()
    targets=set(targets)
    while queue:
        u,mask=queue.popleft()
        if u in targets:family.add(mask)
        for v,w,bit in outgoing(u,word,edges):
            if forward[u]+w+backward[v]!=optimum:continue
            nextmask=mask|bit
            if nextmask in seen[v]:continue
            seen[v].add(nextmask);visits+=1
            if visits>CAP:return {'status':'GUARD','cost':optimum,'visited_pairs':visits}
            queue.append((v,nextmask))
    assert family
    union=0;intersection=(1<<n)-1
    for mask in family:union|=mask;intersection&=mask
    return {'status':'EXPLICIT_COMPLETE','cost':optimum,'visited_pairs':visits,
        'family_count':len(family),'family_masks':sorted(family),
        'possible_positions':[i for i in range(n) if union>>i&1],
        'mandatory_positions':[i for i in range(n) if intersection>>i&1]}

def run(model):
    verify();start=perf_counter();doc=read(MODEL_PATHS[model]);edges,rev,final=original_graph(doc)
    cohort='bpi2013' if model.startswith('bpi') else 'traffic';plan=read(EXT/f'plan_{cohort}.json')
    counters=Counter();path=HERE/f'{model}_explicit_base.jsonl'
    with path.open('x',encoding='utf-8') as stream:
        for v in plan['variants']:
            if len(v['word'])>9:continue
            row={'variant_id':v['variant_id'],'word':v['word']}
            for acceptance in ('prefix','completed'):
                a=explicit_family(v['word'],edges,rev,final,acceptance);row[acceptance]=a
                counters[acceptance+'_'+a['status']]+=1
            stream.write(json.dumps(row,ensure_ascii=False,separators=(',',':'))+'\n')
            if sum(counters.values())%200==0:
                stream.flush();print(json.dumps({'model':model,'counts':dict(counters),'seconds':round(perf_counter()-start,2)}),flush=True)
    verify()
    summary={'status':'INDEPENDENT_EXPLICIT_BASE_COMPLETED','model':model,'counts':dict(counters),
        'graph_original_integer_arcs_match_stored':True,'markings':len(edges),
        'elapsed_seconds':perf_counter()-start,'output':binding(path)}
    save(HERE/f'{model}_explicit_base_summary.json',summary);print(json.dumps(summary),flush=True)

if __name__=='__main__':
    if sys.argv[1]=='freeze':freeze()
    else:run(sys.argv[1])
