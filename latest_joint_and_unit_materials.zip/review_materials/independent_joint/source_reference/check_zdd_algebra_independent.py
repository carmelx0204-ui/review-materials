"""Exhaustive small-family tests of producer operations against literal sets."""
from pathlib import Path
from functools import lru_cache
from datetime import datetime, timezone
import importlib.util
import hashlib
import json

HERE=Path(__file__).resolve().parent
PRODUCER=HERE.parent/'real_joint'/'real_joint_exact.py'
spec=importlib.util.spec_from_file_location('joint_producer_for_algebra_test',PRODUCER)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
z=module.ZDD()

def encode(family,position,n):
    if not family:return 0
    if position==n:
        assert family==frozenset({0});return 1
    lo=frozenset(mask for mask in family if not(mask>>position&1))
    hi=frozenset(mask^(1<<position) for mask in family if mask>>position&1)
    return z.mk(position,encode(lo,position+1,n),encode(hi,position+1,n))
@lru_cache(None)
def decode(root):
    if root==0:return frozenset()
    if root==1:return frozenset({0})
    position,lo,hi=z.nodes[root]
    return decode(lo)|frozenset(mask|(1<<position) for mask in decode(hi))
def project(mask,p):
    return (mask&((1<<p)-1))|((mask>>(p+1))<<p)

n=3
families=[frozenset(mask for mask in range(1<<n) if code>>mask&1) for code in range(1<<(1<<n))]
roots=[encode(f,0,n) for f in families]
assert len(set(roots))==len(families)
operations=0
for f,r in zip(families,roots):
    assert decode(r)==f and z.count(r)==len(f)
    for mask in range(1<<n):assert z.contains(r,mask)==(mask in f)
    if f:
        expected_union=0;expected_intersection=(1<<n)-1
        for mask in f:expected_union|=mask;expected_intersection&=mask
        assert z.support(r)==(expected_union,expected_intersection)
        assert z.selected(r)==min(f,key=lambda mask:tuple(mask>>i&1 for i in range(n)))
    for p in range(n):assert decode(z.project_delete(r,p))==frozenset(project(mask,p) for mask in f)
    for g,s in zip(families,roots):
        assert decode(z.union(r,s))==f|g
        assert decode(z.intersection(r,s))==f&g
        assert decode(z.difference(r,s))==f-g
        operations+=3

receipt={'status':'PASS_EXHAUSTIVE_LITERAL_SET_ZDD_ALGEBRA',
    'created_at_utc':datetime.now(timezone.utc).isoformat(),'universe_size':n,
    'all_families':len(families),'all_ordered_family_pairs':len(families)**2,
    'binary_operations_checked':operations,'all_family_position_projections':len(families)*n,
    'source_sha256':hashlib.sha256(PRODUCER.read_bytes()).hexdigest(),
    'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'zdd_nodes':len(z.nodes)}
with (HERE/'zdd_algebra_independent_review.json').open('x',encoding='utf-8') as f:json.dump(receipt,f,indent=2)
print(json.dumps(receipt))
