"""Post-hoc original-arc explanation of the real reference-only joint split."""
from pathlib import Path
from datetime import datetime, timezone
import independent_joint_explicit as core
from real_joint_original_arc_witnesses import constrained
import json

HERE=Path(__file__).resolve().parent
def main():
    core.verify();plan=core.read(core.EXT/'plan_bpi2013.json');vid=459
    word=plan['variants'][vid]['word'];ids=['old_Queued','old_Resolved'];checks=[]
    assert word==['["Queued","Awaiting Assignment"]','["Completed","Resolved"]']
    for model in ('bpi2013_IMf02','bpi2013_IMf03'):
        doc=core.read(core.MODEL_PATHS[model]);edges,rev,final=core.original_graph(doc);trans=doc['net_doc']['transitions']
        markings=[tuple(doc['net_doc']['initial'])];index={markings[0]:0};cursor=0
        while cursor<len(markings):
            marking=markings[cursor]
            for t in trans:
                if all(a>=b for a,b in zip(marking,t['pre'])):
                    target=tuple(a-b+c for a,b,c in zip(marking,t['pre'],t['post']))
                    if target not in index:index[target]=len(markings);markings.append(target)
            cursor+=1
        for mask in range(4):
            answer=constrained(word,ids,edges,final,mask)
            for step in answer['steps']:
                a=markings[step['before_marking_index']];b=markings[step['after_marking_index']];ti=step['transition_index']
                if ti is None:assert a==b
                else:
                    t=trans[ti];assert all(x>=y for x,y in zip(a,t['pre']))
                    assert b==tuple(x-y+z for x,y,z in zip(a,t['pre'],t['post']))
                    step.update(transition_id=t['id'],transition_label=t['label'])
            consumed=[s['record_id'] for s in answer['steps'] if s['record_id'] is not None];assert consumed==ids
            logs={s['record_id'] for s in answer['steps'] if s['kind']=='LOG'};assert sum(1<<i for i,r in enumerate(ids) if r in logs)==mask
            checks.append({'model':model,'variant_id':vid,'word':word,'old_mask':mask,**answer})
    result={'status':'PASS_REFERENCE_SPLIT_ORIGINAL_ARC_WITNESSES','created_at_utc':datetime.now(timezone.utc).isoformat(),
        'posthoc_representative_analysis':True,'all_four_masks_both_references':True,'constrained_solves':len(checks),
        'checks':checks,'checker':core.binding(Path(__file__))}
    core.save(HERE/'cross_reference_original_arc_witnesses.json',result)
    print(json.dumps({'status':result['status'],'costs':[{'model':r['model'],'mask':r['old_mask'],'cost':r['cost'],
        'visible_moves':[(s['kind'],s.get('transition_label'),s['record_id']) for s in r['steps'] if s['kind']!='TAU']} for r in checks]},ensure_ascii=False))
if __name__=='__main__':main()
