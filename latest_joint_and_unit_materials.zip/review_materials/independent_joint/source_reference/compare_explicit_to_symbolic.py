"""Independent literal-set comparison of every real-data endpoint and pair."""
from pathlib import Path
from functools import lru_cache
from collections import Counter
from datetime import datetime, timezone
import independent_joint_explicit as core
import json
import sys

HERE=Path(__file__).resolve().parent
PRODUCER=HERE.parent/'real_joint'
def rows(path):
    with Path(path).open(encoding='utf-8') as f:return [json.loads(s) for s in f if s.strip()]
def project(mask,p):return (mask&((1<<p)-1))|((mask>>(p+1))<<p)
def support(family,n):
    possible=0;mandatory=(1<<n)-1
    for mask in family:possible|=mask;mandatory&=mask
    return possible,mandatory
def selected(family,n):return min(family,key=lambda mask:tuple(mask>>i&1 for i in range(n)))

def run(model):
    core.verify();start=datetime.now(timezone.utc).isoformat()
    short=HERE/f'{model}_explicit_base.jsonl';paths=[short]
    if model.startswith('bpi'):
        paths.append(HERE/f'{model}_explicit_long.jsonl')
        assert (HERE/f'{model}_explicit_long_summary.json').exists()
    explicit={r['variant_id']:r for p in paths for r in rows(p)}
    symbolic={r['variant_id']:r for r in rows(PRODUCER/f'{model}_words.jsonl')}
    cohort='bpi2013' if model.startswith('bpi') else 'traffic'
    plan=core.read(core.EXT/f'plan_{cohort}.json')
    assert set(explicit)==set(symbolic)==set(v['variant_id'] for v in plan['variants'])
    nodes=core.read(PRODUCER/f'{model}_zdd.json')['nodes'];assert nodes[:2]==[None,None]
    triples=set()
    for u,node in enumerate(nodes[2:],2):
        v,lo,hi=node
        assert isinstance(v,int) and v>=0 and 0<=lo<u and 0<hi<u
        assert (v,lo,hi) not in triples;triples.add((v,lo,hi))
        for child in (lo,hi):assert child<2 or nodes[child][0]>v
    @lru_cache(None)
    def decode(root):
        if root==0:return frozenset()
        if root==1:return frozenset({0})
        v,lo,hi=nodes[root]
        return decode(lo)|frozenset(mask|(1<<v) for mask in decode(hi))
    endpoint_counts=Counter();maxfamily={}
    for vid,x in explicit.items():
        y=symbolic[vid];assert x['word']==y['word'];assert y['answer']['status']=='EXACT'
        for acceptance in ('prefix','completed'):
            a=x[acceptance];b=y['answer'][acceptance];assert a['status']=='EXPLICIT_COMPLETE'
            family=frozenset(a['family_masks']);assert family==decode(b['root']),(model,vid,acceptance)
            for field in ('cost','family_count','possible_positions','mandatory_positions'):assert a[field]==b[field],(model,vid,acceptance,field)
            assert len(family)==a['family_count'];endpoint_counts[acceptance]+=1
            if len(family)>maxfamily.get(acceptance,{}).get('count',-1):maxfamily[acceptance]={'count':len(family),'variant_id':vid,'word_length':len(x['word'])}
    pair_counts={a:Counter() for a in ('prefix','completed')};cases={a:{} for a in pair_counts};special=[]
    paired=rows(PRODUCER/f'{model}_pairs.jsonl');assert len(paired)==len(plan['pairs'])
    for expected,pair in zip(plan['pairs'],paired):
        for field,value in expected.items():assert pair[field]==value,(model,pair['pair_id'],field)
        assert pair['status']=='EXACT_PAIR'
        p=pair['position'];n=len(explicit[pair['before_variant']]['word'])
        for acceptance in pair_counts:
            a=explicit[pair['before_variant']][acceptance];b=explicit[pair['after_variant']][acceptance]
            before=frozenset(a['family_masks']);after=frozenset(project(mask,p) for mask in b['family_masks'])
            r=pair[acceptance];meet=before&after;delta=b['cost']-a['cost']
            category=('equal' if before==after else 'proper_contraction' if meet==after else
                      'proper_expansion' if meet==before else 'disjoint' if not meet else 'overlap_incomparable')
            roleschanged=support(before,n)!=support(after,n);jointchanged=before!=after
            assert decode(r['before_root'])==before and decode(r['projected_after_root'])==after
            exact={'before_cost':a['cost'],'after_cost':b['cost'],'delta_cost':delta,'same_cost':delta==0,
                'category':category,'joint_changed':jointchanged,'old_roles_changed':roleschanged,
                'marginal_stable_joint_change':jointchanged and not roleschanged,
                'before_family_count':len(before),'after_projected_family_count':len(after),
                'intersection_count':len(meet),'before_subset_after':before<=after,'after_subset_before':after<=before,
                'canonical_before_mask':selected(before,n),'canonical_after_mask':selected(after,n),
                'canonical_unchanged':selected(before,n)==selected(after,n),
                'canonical_before_remains_admissible':selected(before,n) in after,
                'recovered_record_possible_log':any(mask>>p&1 for mask in b['family_masks']),
                'recovered_record_mandatory_log':all(mask>>p&1 for mask in b['family_masks'])}
            for field,value in exact.items():assert r[field]==value,(model,pair['pair_id'],acceptance,field)
            assert delta in (-1,0,1)
            if delta==1:assert before<=after
            elif delta==-1:assert after<=before
            else:assert not any(mask>>p&1 for mask in b['family_masks'])
            if jointchanged:
                mask=r['distinguishing_mask'];assert (mask in before)==r['distinguishing_membership_before']
                assert (mask in after)==r['distinguishing_membership_after'];assert (mask in before)!=(mask in after)
            count=pair_counts[acceptance];count['pairs']+=1;count['delta_'+str(delta)]+=1;count['category_'+category]+=1
            predicates={'joint_changes':jointchanged,'old_role_changes':roleschanged,
                'marginal_stable_joint_changes':jointchanged and not roleschanged,
                'same_cost_pairs':delta==0,'same_cost_joint_changes':delta==0 and jointchanged,
                'same_cost_role_changes':delta==0 and roleschanged,
                'canonical_unchanged_same_cost_joint_changed':r['canonical_unchanged'] and delta==0 and jointchanged,
                'canonical_unchanged_same_cost_roles_changed':r['canonical_unchanged'] and delta==0 and roleschanged}
            for key,predicate in predicates.items():
                if predicate:count[key]+=1;cases[acceptance].setdefault(key,set()).add(pair['case'])
            if jointchanged and not roleschanged:
                special.append({'pair_id':pair['pair_id'],'case':pair['case'],'acceptance':acceptance,
                    'restored_position':p,'old_ids':pair['old_ids'],'old_word':pair['old_word'],
                    'before_cost':a['cost'],'after_cost':b['cost'],'before_family':sorted(before),
                    'projected_after_family':sorted(after),'before_possible_mandatory_masks':support(before,n),
                    'after_possible_mandatory_masks':support(after,n),'category':category,
                    'distinguishing_mask':r['distinguishing_mask']})
    summary=core.read(PRODUCER/f'{model}_summary.json')
    for acceptance,count in pair_counts.items():
        for key,value in summary['counts'][acceptance].items():
            if key in count:assert count[key]==value,(model,acceptance,key,count[key],value)
    result={'status':'PASS_FULL_POPULATION_EXPLICIT_FAMILY_CHECK','created_at_utc':start,'model':model,
        'endpoint_counts':dict(endpoint_counts),'all_original_arcs_rebuilt':True,
        'all_endpoint_family_counts_and_exact_masks_match':True,'all_pair_projected_masks_match':True,
        'all_pair_categories_marginals_canonical_old_view_and_distinguishers_match':True,
        'unit_insertion_cost_and_support_nesting_pass_every_pair':True,
        'pair_counts':{a:dict(c) for a,c in pair_counts.items()},
        'case_counts':{a:{k:len(v) for k,v in d.items()} for a,d in cases.items()},
        'maximum_family':maxfamily,'marginal_stable_joint_examples':special,
        'zero_resource_guards':True,'zdd_structural_nodes_checked':len(nodes)-2,
        'inputs':[core.binding(p) for p in [*paths,PRODUCER/f'{model}_words.jsonl',PRODUCER/f'{model}_pairs.jsonl',PRODUCER/f'{model}_zdd.json']],
        'checker':core.binding(Path(__file__))}
    core.save(HERE/f'{model}_joint_independent_review.json',result)
    print(json.dumps({k:v for k,v in result.items() if k not in ('inputs','checker','marginal_stable_joint_examples')}))
if __name__=='__main__':run(sys.argv[1])
