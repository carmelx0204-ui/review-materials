# Independent check of real-log joint diagnosis

This protocol is fixed before reading the new joint outcomes. The validator
imports neither the producer's ZDD operations nor its SCC solver.

1. Rebuild the complete finite reachable-marking graph from original integer
   pre/post arcs, preserving every enabled transition and the original markings.
   Compare its exact labelled firing edges with the stored model graph.
2. Use heap Dijkstra on the original observation/marking product to find the
   optimal unit-cost value. Enumerate explicit `(product state, LOG-position mask)`
   pairs on optimal paths. This requires no SCC collapse or symbolic family
   reduction. TAU cycles terminate through exact visited-pair equality.
3. Base population: every frozen structural word of length at most nine, on all
   five real references, under both PREFIX and COMPLETED acceptance. No word is
   selected by its new joint outcome. A 2,000,000 state/mask-pair guard is reported
   explicitly if reached; no guarded family is called complete.
4. Compare every exact explicit family with the ZDD family, its cardinality,
   union and intersection. Test ZDD representation and old-position projection
   against explicit powersets on exhaustive small universes.
5. Extend explicit checking to every endpoint word of a newly discovered
   marginal-stable joint-family change, preserving the same guard. Distinguishing
   projected masks are also checked by independently constrained product search
   whenever the producer exports them. Report this outcome-driven diagnostic
   extension separately from the outcome-independent base population.

All source scripts, models, and plans are SHA256-bound before executing the
validator. The current manuscript is read-only throughout this check.
