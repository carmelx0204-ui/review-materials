# Outcome-independent full-population extension

The initial explicit-mask validator completed both Traffic references and
BPI13 .2/.3 short-word populations quickly, with no resource guards. Their
largest explicit family had four masks. This feasibility information motivates
extending the independent explicit constructor to every remaining frozen word
of length greater than nine, on all references and both acceptance rules.

The producer's new joint comparison outcomes have not been read. This extension
therefore uses the entire complementary word-length population rather than any
joint-positive selection. It retains the same two-million visited state/mask
guard and reports every guard without treating its partial masks as complete.
The original protocol, source, and short-word answers remain unchanged.

The combined base and extension cover all 9,159 model/word inputs under both
acceptance rules: 18,318 endpoint answers. The extension script imports only the
independent explicit oracle, never the symbolic producer or its SCC/ZDD code.
