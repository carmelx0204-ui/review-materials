# Anonymous review materials

This archive contains fixed experiment inputs, full saved results, and verification source for **Diagnostic Stability under Event-Log Restoration in Petri Net Conformance Checking: [Experiments & Analysis]**.

## Coverage

* `unit/matched_acceptance_reproduction.zip`: a self-contained Python 3 standard-library component for the complete matched unit-cost prefix/completed experiment. It contains the five fixed integer-arc Petri references, the two fixed restoration plans, expected costs/individual roles, the relative-path runner, attribution, and a recorded successful recomputation.
* `real_joint/results`: all 9,159 reference/word inputs with exact joint LOG-set families represented as canonical ZDDs, and all 29,817 restoration comparisons under **each** acceptance rule (59,634 paired acceptance queries), including negative outcomes, complete summaries, joint-family inclusion categories, and the cross-reference comparison. Repeated reference conditions reuse the same cases; they are not independent new cases.
* `independent_joint/results`: the independent original-integer-arc explicit-family checks, complete literal family results, exact projection checks, ZDD algebra checks, and replayed distinguishing witnesses. The archived full-population checks cover all 18,318 word/acceptance inputs and 59,634 pair/acceptance comparisons.
* `unit_support_law/results`: complete per-pair unit-cost direction checks, role-transition polarity results, independently checked serialized-family implications, summaries, and representatives.
* `source_reference` and `protocols`: the actual analysis/checker code and frozen query definitions supporting the saved results. These source-reference scripts retain their original project-layout assumptions and are **not** advertised as one-command portable runners. Their historical local paths have been replaced with `WORKSPACE` or `USER_HOME`; manual configuration and the recorded source inputs are required to execute these archival scripts. No third-party optimizer or dependency installation is supplied by these source-reference directories.

## Run the portable unit-cost component

Extract `unit/matched_acceptance_reproduction.zip`. In the resulting `matched_acceptance` directory:

```text
python -B reproduce.py --verify-only
python -B reproduce.py --output ../fresh-matched-results
```

For a shorter single-reference recomputation:

```text
python -B reproduce.py --model traffic_IMf02 --output ../fresh-traffic-results
```

Use a new output directory outside the component. The runner recomputes both acceptance rules and compares every planned word's costs/individual roles and all expected aggregate counts. Its scope is matched **unit-cost** acceptance; the new joint-family and unit-support-law files in this outer archive are the complete saved results and archival verification sources. Weighted/affine domains and constructed controls are separate review components available from the same review page.

## Portable verification of the complete saved joint evidence

From the outer `review_materials` directory, run:

```text
python -B verify_joint_evidence.py --output ../fresh_joint_verification
```

This relative-path standard-library checker independently compares the complete saved ZDD families with the independent explicit-mask families: all **18,318 endpoint families** and **59,634 restoration comparisons**, including costs, P/M, old-record projection, exact families, subset categories, fixed lexicographic selections, and distinguishing witnesses. It is a complete **saved-evidence verification**, not a rerun of the original joint-family optimizer.

The downloadable archive was freshly extracted to a different directory. Its nested portable unit component was actually executed with Python 3.12.14: all five references, 9,159 reference/word inputs, and all 29,817 restoration positions under both acceptance rules passed fresh integer-arc recomputation in **174.743 seconds**. The saved-joint checker was also executed on that extracted evidence and passed the entire population in **2.567 seconds**. Exact observed receipts and freshly recomputed word outputs are in `observed_portable_runs`; timings describe those runs, not a runtime guarantee.

## Scientific objects and interpretation

Each joint-family member records which common-old **record IDs** are consumed as LOG. It does not identify a complete physical MODEL/TAU route. ZDD 0 is the empty family; ZDD 1 is the family containing the empty set; other nodes are `[position,low,high]`. The after-family projection removes the recovered occurrence and shifts subsequent positions to the before coordinate system. The fixed real-log selector is the lexicographically least common-old LOG bit vector, preferring SYNC; software-native selection is a different object.

The two completed marginal-stable joint-change positions come from one BPI case, repeated under two references, at cost 2 to 3. No equal-cost marginal-stable joint changes were observed in these real cohorts. All positive and negative comparisons are retained.

## Anonymous export and bindings

Author-local workspace/user paths were mapped to `WORKSPACE` and `USER_HOME`. Scientific numbers, record IDs, activities, costs, mask families, statuses, and third-party attributions are unchanged. `EXPORT_MANIFEST.json` supplies both the original-source receipt SHA256 and the exported-file SHA256; they can differ because path mapping or JSON formatting changes bytes. Source receipts describe the original local execution and can cite project files outside this selected archive. They are provenance records rather than portable dependency manifests. The export manifest is the binding for this anonymous release.

All files are provided for scientific review. Public-log attribution and the license metadata already recorded by the portable component are preserved in `ATTRIBUTION.json` and inside the nested unit component. Upstream authorship, copyright notices, and citations are retained. This archive does not grant additional redistribution rights for third-party material. The Gap-Aware implementation is cited by its public Zenodo DOI 10.5281/zenodo.22016503; its source is not redistributed here. This package contains selected final evidence, not private progress notes, emails, the entire working directory, or claims of additional experiments.
