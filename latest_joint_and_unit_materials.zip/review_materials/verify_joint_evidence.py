"""Independently verify all saved real-data joint-pattern evidence.

Python 3.11+, standard library only. This checks saved symbolic results against
independently computed explicit families; it does not rerun their optimizers.
Run from any directory:
  python -B verify_joint_evidence.py --output ../fresh_joint_verification
"""
from argparse import ArgumentParser
from collections import Counter
from datetime import datetime, timezone
from functools import lru_cache
from hashlib import sha256
from pathlib import Path
import json
import time


MODELS = {
    "bpi2013_IMf01": (3011, 8735),
    "bpi2013_IMf02": (3011, 8735),
    "bpi2013_IMf03": (3011, 8735),
    "traffic_IM0": (63, 1806),
    "traffic_IMf02": (63, 1806),
}
ACCEPTANCES = ("prefix", "completed")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def rows(path):
    with path.open(encoding="utf-8") as stream:
        return [json.loads(line) for line in stream if line.strip()]


def index(rows_, label):
    result = {}
    for row in rows_:
        key = row["variant_id"]
        require(key not in result, f"Duplicate variant in {label}: {key}")
        result[key] = row
    return result


def project(mask, position):
    return (mask & ((1 << position) - 1)) | ((mask >> (position + 1)) << position)


def support(family, length):
    require(bool(family), "An exact finite-cost endpoint has an empty family")
    possible = 0
    mandatory = (1 << length) - 1
    for mask in family:
        require(isinstance(mask, int) and 0 <= mask < (1 << length), "Out-of-range family mask")
        possible |= mask
        mandatory &= mask
    return possible, mandatory


def positions(mask, length):
    return [i for i in range(length) if (mask >> i) & 1]


def selected(family, length):
    # This is lexicographic selection in the aligned OLD-record view (0 < 1).
    # It is intentionally not numeric mask order or a native full-after selector.
    return min(family, key=lambda mask: tuple((mask >> i) & 1 for i in range(length)))


def verify_model(bundle, model, expected_words, expected_pairs):
    producer = bundle / "real_joint" / "results"
    independent = bundle / "independent_joint" / "results"
    explicit_paths = [independent / f"{model}_explicit_base.jsonl"]
    if model.startswith("bpi"):
        explicit_paths.append(independent / f"{model}_explicit_long.jsonl")
    word_path = producer / f"{model}_words.jsonl"
    pair_path = producer / f"{model}_pairs.jsonl"
    node_path = producer / f"{model}_zdd.json"
    inputs = [*explicit_paths, word_path, pair_path, node_path]
    explicit = index([r for p in explicit_paths for r in rows(p)], "explicit families")
    symbolic = index(rows(word_path), "symbolic families")
    require(set(explicit) == set(symbolic), f"{model}: endpoint identity mismatch")
    require(len(explicit) == expected_words, f"{model}: wrong endpoint cohort size")
    with node_path.open(encoding="utf-8") as stream:
        nodes = json.load(stream)["nodes"]
    require(nodes[:2] == [None, None], f"{model}: invalid ZDD terminals")
    triples = set()
    for node_id, node in enumerate(nodes[2:], 2):
        require(isinstance(node, list) and len(node) == 3, f"{model}: malformed ZDD node")
        variable, lo, hi = node
        require(all(isinstance(x, int) for x in node), f"{model}: noninteger ZDD node")
        require(variable >= 0 and 0 <= lo < node_id and 0 < hi < node_id,
                f"{model}: invalid ZDD acyclicity or zero suppression")
        require(tuple(node) not in triples, f"{model}: duplicate ZDD triple")
        triples.add(tuple(node))
        for child in (lo, hi):
            require(child < 2 or nodes[child][0] > variable, f"{model}: invalid variable order")

    @lru_cache(None)
    def decode(root):
        require(isinstance(root, int) and 0 <= root < len(nodes), f"{model}: invalid root")
        if root == 0:
            return frozenset()
        if root == 1:
            return frozenset({0})
        variable, lo, hi = nodes[root]
        return decode(lo) | frozenset(mask | (1 << variable) for mask in decode(hi))

    for variant_id, x in explicit.items():
        y = symbolic[variant_id]
        require(x["word"] == y["word"], f"{model}/{variant_id}: word mismatch")
        require(y["answer"]["status"] == "EXACT", f"{model}/{variant_id}: censored symbolic endpoint")
        length = len(x["word"])
        for acceptance in ACCEPTANCES:
            a, b = x[acceptance], y["answer"][acceptance]
            context = f"{model}/{variant_id}/{acceptance}"
            require(a["status"] == "EXPLICIT_COMPLETE", context + ": censored explicit endpoint")
            family = frozenset(a["family_masks"])
            require(len(family) == len(a["family_masks"]), context + ": duplicate explicit masks")
            require(family == decode(b["root"]), context + ": literal family mismatch")
            possible, mandatory = support(family, length)
            expected = {"family_count": len(family), "possible_positions": positions(possible, length),
                        "mandatory_positions": positions(mandatory, length)}
            for field, value in expected.items():
                require(a[field] == b[field] == value, context + ": incorrect " + field)
            require(a["cost"] == b["cost"], context + ": cost mismatch")

    paired = rows(pair_path)
    require(len(paired) == expected_pairs, f"{model}: wrong restoration cohort size")
    pair_ids = set()
    counts = {a: Counter() for a in ACCEPTANCES}
    for pair in paired:
        pair_id, restored = pair["pair_id"], pair["position"]
        require(pair_id not in pair_ids, f"{model}: duplicate pair id")
        pair_ids.add(pair_id)
        require(pair["status"] == "EXACT_PAIR", f"{model}/{pair_id}: censored pair")
        x, y = explicit[pair["before_variant"]], explicit[pair["after_variant"]]
        old_word, new_word = x["word"], y["word"]
        length = len(old_word)
        require(0 <= restored <= length and len(new_word) == length + 1,
                f"{model}/{pair_id}: invalid restoration position")
        require(new_word[:restored] + new_word[restored + 1:] == old_word,
                f"{model}/{pair_id}: restoration does not preserve old word")
        require(pair["old_word"] == old_word and len(pair["old_ids"]) == length,
                f"{model}/{pair_id}: old-record alignment mismatch")
        require(len(set(pair["old_ids"])) == length, f"{model}/{pair_id}: duplicate old-record identity")
        for acceptance in ACCEPTANCES:
            a, b, r = x[acceptance], y[acceptance], pair[acceptance]
            before = frozenset(a["family_masks"])
            full_after = frozenset(b["family_masks"])
            after = frozenset(project(mask, restored) for mask in full_after)
            meet = before & after
            delta = b["cost"] - a["cost"]
            category = ("equal" if before == after else "proper_contraction" if after < before else
                        "proper_expansion" if before < after else "disjoint" if not meet else
                        "overlap_incomparable")
            joint_changed = before != after
            roles_changed = support(before, length) != support(after, length)
            canonical_before, canonical_after = selected(before, length), selected(after, length)
            recovered_possible = any((mask >> restored) & 1 for mask in full_after)
            recovered_mandatory = all((mask >> restored) & 1 for mask in full_after)
            context = f"{model}/{pair_id}/{acceptance}"
            require(decode(r["before_root"]) == before, context + ": incorrect before root")
            require(decode(r["after_root"]) == full_after, context + ": incorrect full-after root")
            require(decode(r["projected_after_root"]) == after, context + ": incorrect projected root")
            expected = {
                "before_cost": a["cost"], "after_cost": b["cost"], "delta_cost": delta,
                "same_cost": delta == 0, "category": category, "joint_changed": joint_changed,
                "old_roles_changed": roles_changed, "marginal_stable_joint_change": joint_changed and not roles_changed,
                "before_family_count": len(before), "after_projected_family_count": len(after),
                "intersection_count": len(meet), "before_subset_after": before <= after,
                "after_subset_before": after <= before, "canonical_before_mask": canonical_before,
                "canonical_after_mask": canonical_after, "canonical_unchanged": canonical_before == canonical_after,
                "canonical_before_remains_admissible": canonical_before in after,
                "recovered_record_possible_log": recovered_possible,
                "recovered_record_mandatory_log": recovered_mandatory,
            }
            for field, value in expected.items():
                require(r[field] == value, context + ": incorrect " + field)
            require(delta in (-1, 0, 1), context + ": unit insertion cost law failed")
            if delta == 1:
                require(before <= after and recovered_possible, context + ": expansion law failed")
            else:
                require(not recovered_possible, context + ": forced synchronization law failed")
                if delta == -1:
                    require(after <= before, context + ": contraction law failed")
            if joint_changed:
                mask = r["distinguishing_mask"]
                require((mask in before) == r["distinguishing_membership_before"], context + ": before witness failed")
                require((mask in after) == r["distinguishing_membership_after"], context + ": after witness failed")
                require((mask in before) != (mask in after), context + ": non-distinguishing witness")
            count = counts[acceptance]
            count["pairs"] += 1
            count["delta_" + str(delta)] += 1
            count["category_" + category] += 1
            for name, predicate in {
                "joint_changes": joint_changed, "old_role_changes": roles_changed,
                "marginal_stable_joint_changes": joint_changed and not roles_changed,
                "same_cost_pairs": delta == 0, "same_cost_joint_changes": delta == 0 and joint_changed,
                "same_cost_role_changes": delta == 0 and roles_changed,
                "canonical_unchanged_same_cost_joint_changed": canonical_before == canonical_after and delta == 0 and joint_changed,
                "canonical_unchanged_same_cost_roles_changed": canonical_before == canonical_after and delta == 0 and roles_changed,
            }.items():
                count[name] += int(predicate)
    return {
        "model": model, "status": "PASS", "distinct_words": expected_words,
        "endpoint_families": expected_words * 2, "restoration_pairs": expected_pairs,
        "acceptance_comparisons": expected_pairs * 2, "zdd_nonterminal_nodes": len(nodes) - 2,
        "counts": {a: dict(c) for a, c in counts.items()},
        "inputs": [{"path": p.relative_to(bundle).as_posix(), "bytes": p.stat().st_size,
                    "sha256": sha256(p.read_bytes()).hexdigest()} for p in inputs],
    }


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--bundle", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--output", type=Path, required=True, help="New output directory outside the bundle")
    args = parser.parse_args()
    bundle, output = args.bundle.resolve(), args.output.resolve()
    require(not output.is_relative_to(bundle), "Output must be outside the input bundle")
    require(not output.exists(), "Output directory already exists; choose a fresh path")
    output.mkdir(parents=True)
    started = time.perf_counter()
    receipt = {
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "scope": "Saved-evidence comparison: full symbolic ZDD families versus independent explicit masks; no optimizer rerun",
        "selector": "Lexicographic minimum of the aligned old-record bit vector, with 0 < 1",
        "checker_sha256": sha256(Path(__file__).read_bytes()).hexdigest(),
        "models": [],
    }
    try:
        for model, (words, pairs) in MODELS.items():
            result = verify_model(bundle, model, words, pairs)
            receipt["models"].append(result)
            print(json.dumps({k: result[k] for k in ("model", "status", "endpoint_families", "acceptance_comparisons")}), flush=True)
        receipt["status"] = "PASS_ALL_18318_ENDPOINT_FAMILIES_AND_59634_RESTORATION_COMPARISONS"
        receipt["endpoint_families"] = sum(r["endpoint_families"] for r in receipt["models"])
        receipt["acceptance_comparisons"] = sum(r["acceptance_comparisons"] for r in receipt["models"])
        require(receipt["endpoint_families"] == 18318 and receipt["acceptance_comparisons"] == 59634,
                "Unexpected full-population coverage")
    except Exception as error:
        receipt["status"] = "FAIL"
        receipt["error_type"] = type(error).__name__
        receipt["error"] = str(error)
        raise
    finally:
        receipt["elapsed_seconds"] = round(time.perf_counter() - started, 3)
        (output / "verification_receipt.json").write_text(json.dumps(receipt, indent=2, ensure_ascii=True) + "\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in receipt.items() if k not in ("models",)}), flush=True)


if __name__ == "__main__":
    main()
