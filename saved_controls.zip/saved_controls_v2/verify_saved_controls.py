"""Exact saved-control reaggregation and original-net feasible-path checks.

No discovery, gap-profile optimizer, or weighted alignment optimizer is called.
The zero-deviation checker searches only SYNC/silent paths in the supplied net.
"""
from collections import Counter, defaultdict, deque
from fractions import Fraction
from pathlib import Path
import argparse
import hashlib
import itertools
import json
import platform

HERE = Path(__file__).resolve().parent
FIELDS = ('possible_log_ids', 'mandatory_log_ids', 'forced_sync_ids', 'ambiguous_consumption_ids')
POS = ('possible_log_positions', 'mandatory_log_positions', 'forced_sync_positions', 'ambiguous_positions')
PAIR_KEYS = ('pair_id', 'case', 'position', 'delayed_record_id', 'before_variant', 'after_variant', 'normal_last_record_control')


def need(ok, context):
    if not ok:
        raise ValueError(context)


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def rows(path):
    return [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines() if line.strip()]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def q(value):
    need(set(value) == {'numerator', 'denominator'}, 'Noncanonical rational object')
    n, d = value['numerator'], value['denominator']
    need(type(n) is int and type(d) is int and d > 0, 'Invalid exact rational')
    return Fraction(n, d)


def qdoc(value):
    return {'numerator': value.numerator, 'denominator': value.denominator}


def validate(answer, ids, fields=FIELDS):
    universe = set(ids)
    need(len(ids) == len(universe), 'Repeated record identity')
    p, m, s, a = [set(answer[f]) for f in fields]
    need(m <= p <= universe and s == universe - p and a == p - m, 'Invalid complete role partition')
    need(all(len(answer[f]) == len(set(answer[f])) for f in fields), 'Repeated role entry')
    sync_key = 'possible_sync_ids' if fields == FIELDS else 'possible_sync_positions'
    if sync_key in answer:
        need(set(answer[sync_key]) == universe - m, 'Invalid possible-SYNC support')


def role_changed(before, after, old_ids):
    old = set(old_ids)
    validate(before, old_ids)
    return any(set(before[f]) != set(after[f]) & old for f in FIELDS)


def mapped_unit(row, ids):
    need(row['status'] == 'EXACT' and len(row['word']) == len(ids), 'Incomplete unit answer')
    validate(row, list(range(len(ids))))
    return {'cost': row['cost'], **{f: sorted(ids[i] for i in row[f]) for f in FIELDS}}


def mapped_manual(row, ids):
    need(row['answer']['status'] == 'EXACT', 'Incomplete manual partial-order answer')
    names = {f'v{i:06d}': value for i, value in enumerate(ids)}
    out = {'cost': row['answer']['cost']}
    out.update({f: sorted(names[x] for x in row['answer'][f]) for f in FIELDS})
    validate(out, ids)
    return out


def check_manual():
    plan = read(HERE / 'inputs/manual_po_plan.json')
    answers = read(HERE / 'inputs/manual_po_words.json')
    total = read(HERE / 'inputs/manual_total_pairs.json')
    cases = {c['id']: c for c in plan['cases']}
    need(len(cases) == len(plan['cases']) == 512, 'Manual case coverage')
    total_lookup = {(r['case'], r['position']): r for r in total}
    expected_keys = {(c['id'], i) for c in plan['cases'] for i in range(len(c['events']))}
    need(len(total_lookup) == len(total) == len(plan['pairs']) == len(expected_keys) == 2295, 'Manual position coverage')
    need(set(total_lookup) == expected_keys, 'Missing manual total-order position')
    need(len(answers) == len(plan['variants']) == 107, 'Manual structure coverage')
    for i, (r, v) in enumerate(zip(answers, plan['variants'])):
        need(r['variant_id'] == v['variant_id'] == i and r['word'] == v['word'] and r['pred'] == v['pred'], 'Manual word binding')
        need(len(v['word']) == len(v['pred']), 'Manual predecessor length')
        mapped_manual(r, [f'p{i}' for i in range(len(v['word']))])
    old_positive, new_positive, seen, zero_after = set(), set(), set(), set()
    same = 0
    for p in plan['pairs']:
        key = p['case'], p['position']
        need(key not in seen and key in expected_keys, 'Duplicate/foreign manual pair')
        seen.add(key)
        events = cases[p['case']]['events']
        ids, pos = [e['id'] for e in events], p['position']
        need(len(ids) == len(set(ids)) and ids[pos] == p['delayed_record_id'], 'Manual restoration identity')
        before_events = events[:pos] + events[pos + 1:]
        old_ids = ids[:pos] + ids[pos + 1:]
        for events_now, vid in ((before_events, p['before_variant']), (events, p['after_variant'])):
            v = plan['variants'][vid]
            need(v['word'] == [e['concept'] for e in events_now], 'Manual event/word binding')
            pred = [sum(1 << j for j, e in enumerate(events_now) if e['timestamp_us'] < x['timestamp_us']) for x in events_now]
            need(pred == v['pred'], 'Manual strict-timestamp predecessor mask')
        before = mapped_manual(answers[p['before_variant']], old_ids)
        after = mapped_manual(answers[p['after_variant']], ids)
        same += int(before['cost'] == after['cost'])
        if after['cost'] == 0:
            need(not after['possible_log_ids'] and not after['mandatory_log_ids'], 'Manual zero-cost LOG support')
            zero_after.add(p['case'])
        if before['cost'] == after['cost'] and role_changed(before, after, old_ids):
            new_positive.add(key)
        row = total_lookup[key]
        need(row['delayed_record_id'] == p['delayed_record_id'], 'Manual total-order restored ID')
        validate(row['after'], ids)
        change = role_changed(row['before'], row['after'], old_ids)
        same_total = row['before']['cost'] == row['after']['cost']
        need(change == row['old_role_changed'] and same_total == row['same_cost'], 'Manual saved flags')
        need((same_total and change) == row['same_cost_old_role_revision'], 'Manual target flag')
        if change and same_total:
            old_positive.add(key)
    need(seen == expected_keys and len(old_positive) == 28 and not new_positive and len(zero_after) == 512, 'Manual reconstructed outcome')
    return {'cases': 512, 'positions': 2295, 'partial_order_structures': 107,
            'xml_order_same_cost_positive': len(old_positive), 'partial_order_same_cost_positive': len(new_positive),
            'partial_order_same_cost_pairs': same, 'zero_cost_after_cases': len(zero_after),
            'old_positives_retained': len(old_positive & new_positive), 'new_positives': len(new_positive - old_positive),
            'fresh_partial_order_alignment_optimization': False, 'manual_reference_redistributed': False}


def entries_check(row):
    profile, word = row['profile'], row['word']
    need(profile['status'] == 'EXACT_FIXED_GAP_COUNT_PROFILE', 'Incomplete fixed-K profile')
    need(profile['sentinel_is_original_marking'] is False and profile['acceptance'] == 'prefix_any_original_marking', 'Wrong original-prefix acceptance')
    entries = profile['entries']
    need(entries and len({e['gap_count'] for e in entries}) == len(entries), 'Missing/duplicate fixed-K entry')
    for e in entries:
        k, d = e['gap_count'], e['minimum_total_deviations']
        need(type(k) is int and type(d) is int and 0 <= k <= d, 'Invalid affine K,D counts')
        validate(e, list(range(len(word))), POS)
    return entries


def at(entries, rho, ids):
    value = min(e['gap_count'] * rho + e['minimum_total_deviations'] for e in entries)
    active = [e for e in entries if e['gap_count'] * rho + e['minimum_total_deviations'] == value]
    possible = set().union(*(set(e['possible_log_positions']) for e in active))
    sync = set().union(*(set(e['possible_sync_positions']) for e in active))
    universe = set(range(len(ids)))
    need(possible | sync == universe, 'Active profiles do not consume every record')
    supports = (possible, universe - sync, universe - possible, possible & sync)
    out = {'cost': value, 'active_counts': [[e['gap_count'], e['minimum_total_deviations']] for e in active],
           **{f: sorted(ids[i] for i in s) for f, s in zip(FIELDS, supports)},
           'possible_sync_ids': sorted(ids[i] for i in sync)}
    validate(out, ids)
    return out


def minimum(entries, rho):
    return min(e['gap_count'] * rho + e['minimum_total_deviations'] for e in entries)


def critical(entries):
    points = set()
    for a, b in itertools.combinations(entries, 2):
        if a['gap_count'] != b['gap_count']:
            rho = Fraction(b['minimum_total_deviations'] - a['minimum_total_deviations'], a['gap_count'] - b['gap_count'])
            if rho > 0 and a['gap_count'] * rho + a['minimum_total_deviations'] == minimum(entries, rho):
                points.add(rho)
    return points


def pair_points(before, after):
    points = critical(before) | critical(after)
    for a in before:
        for b in after:
            if a['gap_count'] == b['gap_count']:
                continue
            rho = Fraction(b['minimum_total_deviations'] - a['minimum_total_deviations'], a['gap_count'] - b['gap_count'])
            value = a['gap_count'] * rho + a['minimum_total_deviations']
            if rho > 0 and value == minimum(before, rho) == minimum(after, rho):
                points.add(rho)
    return sorted(points)


def cells(points):
    for left, right in zip([Fraction(0)] + points, points + [None]):
        yield ('open_interval', left, right, left + 1 if right is None else (left + right) / 2)
        if right is not None:
            yield ('point', right, right, right)


def whole_open_line(entries, left, right, probe):
    active = [e for e in entries if e['gap_count'] * probe + e['minimum_total_deviations'] == minimum(entries, probe)]
    need(len(active) == 1, 'Open cell contains an omitted envelope breakpoint')
    k, d = active[0]['gap_count'], active[0]['minimum_total_deviations']
    for e in entries:
        dk, dd = e['gap_count'] - k, e['minimum_total_deviations'] - d
        need(dk * left + dd >= 0, 'Active line fails left-end envelope bound')
        if right is None:
            need(dk >= 0, 'Active tail is not the smallest-slope envelope line')
        else:
            need(dk * right + dd >= 0, 'Active line fails right-end envelope bound')
        if (dk, dd) != (0, 0):
            need(dk * probe + dd > 0, 'A distinct line ties inside an open cell')
    return k, d


def check_saved_answer(expected, saved, ids):
    validate(saved, ids)
    need(q(saved['normalized_cost']) == expected['cost'], 'Saved normalized cost mismatch')
    need(saved['active_counts'] == expected['active_counts'], 'Saved active K,D mismatch')
    need(all(set(saved[f]) == set(expected[f]) for f in FIELDS), 'Saved complete roles mismatch')
    need(set(saved['possible_sync_ids']) == set(expected['possible_sync_ids']), 'Saved possible-SYNC mismatch')


def check_pair_cells(row, before_entries, after_entries):
    ids, old_ids = row['after_ids'], row['before_ids']
    points = pair_points(before_entries, after_entries)
    need(points == [q(p) for p in row['positive_partition_points']], 'Missing/extra exact pair partition point')
    expected_cells = list(cells(points))
    need(len(expected_cells) == len(row['positive_parameter_cells']), 'Missing open/point/tail cell')
    results, required, line_checks = [], set(), 0
    for expected, saved in zip(expected_cells, row['positive_parameter_cells']):
        kind, left, right, rho = expected
        need(saved['kind'] == kind, 'Wrong cell ordering')
        if kind == 'open_interval':
            need(q(saved['left']) == left and (q(saved['right']) if saved['right'] else None) == right, 'Wrong open bounds')
            need(q(saved['probe']) == rho, 'Wrong exact midpoint/tail probe')
            before_line = whole_open_line(before_entries, left, right, rho)
            after_line = whole_open_line(after_entries, left, right, rho)
            same = before_line == after_line
            line_checks += 1
        else:
            need(q(saved['ratio']) == rho, 'Wrong breakpoint atom')
            same = minimum(before_entries, rho) == minimum(after_entries, rho)
        before, after = at(before_entries, rho, old_ids), at(after_entries, rho, ids)
        check_saved_answer(before, saved['before'], old_ids)
        check_saved_answer(after, saved['after'], ids)
        need((before['cost'] == after['cost']) == same, 'An isolated cost crossing was not split into a point cell')
        changed = role_changed(before, after, old_ids)
        yes = same and changed
        need(saved['same_cost'] == same and saved['same_cost_old_summary_revision'] == yes, 'Saved target classification mismatch')
        for f, flag, gain, loss in ((FIELDS[0], 'old_possible_changed', 'possible_gained', 'possible_withdrawn'),
                                   (FIELDS[1], 'old_mandatory_changed', 'mandatory_gained', 'mandatory_withdrawn')):
            bs, aa = set(before[f]), set(after[f]) & set(old_ids)
            need(saved[flag] == (bs != aa) and set(saved[gain]) == aa - bs and set(saved[loss]) == bs - aa, 'Saved role-difference sets')
        results.append((kind, yes))
        required.add(rho)
    unit_before, unit_after = at(before_entries, Fraction(0), old_ids), at(after_entries, Fraction(0), ids)
    check_saved_answer(unit_before, row['unit_boundary']['before'], old_ids)
    check_saved_answer(unit_after, row['unit_boundary']['after'], ids)
    unit = unit_before['cost'] == unit_after['cost'] and role_changed(unit_before, unit_after, old_ids)
    need(row['unit_boundary']['same_cost_old_summary_revision'] == unit, 'Unit-boundary target mismatch')
    any_open = any(yes for kind, yes in results if kind == 'open_interval')
    any_point = any(yes for kind, yes in results if kind == 'point')
    any_yes, all_yes = any_open or any_point, all(yes for _, yes in results)
    category = {'any_positive_rho_revision': any_yes, 'all_positive_rho_revision': all_yes,
                'any_open_interval_revision': any_open, 'any_point_revision': any_point,
                'isolated_point_only_revision': any_point and not any_open, 'unit_revision': unit,
                'unit_revision_persists_all_positive': unit and all_yes,
                'unit_revision_only_some_positive': unit and any_yes and not all_yes,
                'unit_revision_absent_all_positive': unit and not any_yes,
                'new_vs_unit_any_positive_revision': not unit and any_yes,
                'normal_last_any_positive_revision': row['normal_last_record_control'] and any_yes}
    need(row['classification'] == category, 'Reconstructed pair categories differ')
    return category, points, required, line_checks, len(expected_cells)


def check_net(doc):
    n = len(doc['initial'])
    need(n == len(doc['places']) and all(type(x) is int and x >= 0 for x in doc['initial']), 'Invalid original marking')
    need(len({t['id'] for t in doc['transitions']}) == len(doc['transitions']), 'Duplicate transition identity')
    for t in doc['transitions']:
        need(len(t['pre']) == len(t['post']) == n, 'Wrong original incidence dimension')
        need(all(type(x) is int and x >= 0 for x in t['pre'] + t['post']), 'Noninteger original incidence')
        need(t['label'] is None or isinstance(t['label'], str), 'Invalid transition label')


def fire(marking, transition):
    if any(marking[i] < transition['pre'][i] for i in range(len(marking))):
        return None
    return tuple(marking[i] - transition['pre'][i] + transition['post'][i] for i in range(len(marking)))


def zero_path(doc, word, state_cap=100000):
    # Feasibility only: no LOG/MODEL arcs, priority queue, or cost optimizer.
    frontier = {tuple(doc['initial']): []}
    visits = 0
    for position in range(len(word) + 1):
        closure, queue = dict(frontier), deque(frontier)
        while queue:
            marking = queue.popleft()
            visits += 1
            need(visits <= state_cap, 'Zero-deviation feasibility state limit')
            for t in doc['transitions']:
                if t['label'] is None:
                    nxt = fire(marking, t)
                    if nxt is not None and nxt not in closure:
                        closure[nxt] = closure[marking] + [{'kind': 'silent', 'event_position': None, 'transition_id': t['id'], 'deltaK': 0, 'deltaD': 0}]
                        queue.append(nxt)
        if position == len(word):
            marking, moves = next(iter(closure.items()))
            path = {'moves': moves, 'K': 0, 'D': 0, 'gap_histogram': [], 'logged_positions': [],
                    'synced_positions': list(range(len(word))), 'terminal_original_marking': list(marking), 'terminal_gap_open': False}
            need(replay(doc, word, path) == (0, 0), 'New zero-deviation original-arc witness failed replay')
            return path, visits
        frontier = {}
        for marking, moves in closure.items():
            for t in doc['transitions']:
                if t['label'] == word[position]:
                    nxt = fire(marking, t)
                    if nxt is not None and nxt not in frontier:
                        frontier[nxt] = moves + [{'kind': 'sync', 'event_position': position, 'transition_id': t['id'], 'deltaK': 0, 'deltaD': 0}]
        need(bool(frontier), 'Saved zero-cost after word has no original SYNC/silent execution')
    raise RuntimeError('Unreachable zero-path branch')


def replay(doc, word, path):
    transitions = {t['id']: t for t in doc['transitions']}
    marking, position, opened, length = tuple(doc['initial']), 0, False, 0
    k = d = 0
    hist, logged, synced = [], [], []
    for move in path['moves']:
        kind = move['kind']
        need(kind in ('log', 'model', 'sync', 'silent'), 'Unknown saved move kind')
        if kind in ('log', 'sync'):
            need(position < len(word) and move['event_position'] == position, 'Wrong consumed event position')
        else:
            need(move['event_position'] is None, 'Model move consumes a log record')
        dk = dd = 0
        if kind == 'log':
            need(move['transition_id'] is None, 'LOG fires a model transition')
            dk, dd = int(not opened), 1
            logged.append(position)
            position += 1
            opened, length = True, length + 1
        else:
            need(move['transition_id'] in transitions, 'Unknown original transition')
            t = transitions[move['transition_id']]
            nxt = fire(marking, t)
            need(nxt is not None, 'Disabled original integer-net transition')
            if kind == 'silent':
                need(t['label'] is None, 'Visible transition marked silent')
            elif kind == 'model':
                need(t['label'] is not None, 'Silent transition charged as model deviation')
                dk, dd = int(not opened), 1
                opened, length = True, length + 1
            else:
                need(t['label'] is not None and t['label'] == word[position], 'Wrong original SYNC label')
                synced.append(position)
                position += 1
                if length:
                    hist.append(length)
                opened, length = False, 0
            marking = nxt
        need((move['deltaK'], move['deltaD']) == (dk, dd), 'Wrong gap cost increments')
        k, d = k + dk, d + dd
    if length:
        hist.append(length)
    need(position == len(word) and sorted(logged + synced) == list(range(len(word))), 'Incomplete original-prefix execution')
    need((path['K'], path['D']) == (k, d), 'Saved path count mismatch')
    need(path['gap_histogram'] == hist and k == len(hist) and d == sum(hist), 'Saved gap histogram mismatch')
    need(path['logged_positions'] == logged and path['synced_positions'] == synced, 'Saved witness support mismatch')
    need(path['terminal_original_marking'] == list(marking) and path['terminal_gap_open'] == opened, 'Saved original terminal marking mismatch')
    need(all(x >= 0 for x in marking), 'Artificial sentinel is not an original marking')
    return k, d


def check_direct(direct, doc, word, entries):
    need(direct['status'] == 'EXACT_ORIGINAL_AFFINE_SCALAR_AND_RECORD_ROLES' and direct['active_cost_or_roles_certified'] is True, 'Incomplete saved original-arc scalar evidence')
    rho = q(direct['rho'])
    need(rho >= 0, 'Negative normalized affine parameter')
    expected = at(entries, rho, list(range(len(word))))
    validate(direct, list(range(len(word))), POS)
    need(q(direct['normalized_cost']) == expected['cost'], 'Saved direct cost/profile mismatch')
    need(all(set(direct[p]) == set(expected[f]) for f, p in zip(FIELDS, POS)), 'Saved direct roles/profile mismatch')
    need(set(direct['possible_sync_positions']) == set(expected['possible_sync_ids']), 'Saved direct possible-SYNC mismatch')
    path = direct['independently_replayed_feasible_path']
    k, d = replay(doc, word, path)
    need(k * rho + d == expected['cost'], 'Replayed feasible path does not attain saved optimum')
    need(set(direct['mandatory_log_positions']) <= set(path['logged_positions']) <= set(direct['possible_log_positions']), 'Saved witness violates role support')


def check_saved_original_evidence(profiles, required_probes, doc):
    scalar = rows(HERE / 'inputs/traffic_affine_original_arc_scalar_checks.jsonl')
    certificates = read(HERE / 'inputs/traffic_affine_original_arc_certificates.json')
    present, witness_replays = defaultdict(set), 0
    for row in scalar:
        wid, rho = row['word_id'], q(row['rho'])
        need(wid in profiles and row['word'] == profiles[wid]['word'], 'Saved scalar word identity')
        need(row['status'] == 'MATCH_INDEPENDENT_ORIGINAL_ARC_COST_AND_FOUR_ROLES', 'Saved scalar mismatch status')
        need(rho == q(row['direct']['rho']) and rho not in present[wid], 'Duplicate/inconsistent saved scalar parameter')
        check_direct(row['direct'], doc, row['word'], profiles[wid]['profile']['entries'])
        present[wid].add(rho)
        witness_replays += 1
    intervals, cert_counts = defaultdict(set), Counter()
    for row in certificates:
        wid, cert = row['word_id'], row['certificate']
        need(wid in profiles and row['word'] == profiles[wid]['word'], 'Saved certificate word identity')
        need(cert['inactive_or_dominated_fixed_K_scope_certified'] is False, 'Unexpected fixed-K certificate scope')
        word, entries = row['word'], profiles[wid]['profile']['entries']
        k, d = cert['line_K_D']
        left = q(cert['left'])
        if cert['status'] == 'CERTIFIED_FINITE_OPEN_INTERVAL_COST_AND_RECORD_ROLES':
            right, probe = q(cert['right']), q(cert['probe'])
            need(0 <= left < probe < right and probe == (left + right) / 2, 'Saved finite certificate bounds')
            need(whole_open_line(entries, left, right, probe) == (k, d), 'Saved certificate line differs from whole-cell profile')
            for answer, rho in ((cert['left_direct_answer'], left), (cert['right_direct_answer'], right), (cert['interior_direct_answer'], probe)):
                need(q(answer['rho']) == rho and q(answer['normalized_cost']) == k * rho + d, 'Certificate endpoint/line mismatch')
                check_direct(answer, doc, word, entries)
                witness_replays += 1
            need(replay(doc, word, cert['interior_direct_answer']['independently_replayed_feasible_path']) == (k, d), 'Certificate feasible line counts')
            interval = left, right
            cert_counts['finite'] += 1
        else:
            need(cert['status'] == 'CERTIFIED_UNBOUNDED_OPEN_TAIL_COST_AND_RECORD_ROLES', 'Unknown saved certificate status')
            need(whole_open_line(entries, left, None, left + 1) == (k, d), 'Saved certificate tail/profile line')
            lex = cert['lexicographic_certificate']
            need(lex['status'] == 'EXACT_ORIGINAL_LEXICOGRAPHIC_MINIMUM_K_D' and lex['minimum_K_D_claimed'] is True, 'Incomplete saved lexical certificate')
            need((lex['globally_minimum_K'], lex['minimum_D_at_minimum_K']) == (k, d), 'Saved lexical counts mismatch')
            need((k, d) == min((e['gap_count'], e['minimum_total_deviations']) for e in entries), 'Saved lexical/profile minimum mismatch')
            need(replay(doc, word, lex['independently_replayed_feasible_path']) == (k, d), 'Lexical original-arc feasible path')
            witness_replays += 1
            for answer, rho in ((cert['left_direct_answer'], left), (cert['interior_direct_answer'], left + 1)):
                need(q(answer['rho']) == rho and q(answer['normalized_cost']) == k * rho + d, 'Tail certificate parameter/line mismatch')
                check_direct(answer, doc, word, entries)
                witness_replays += 1
            interval = left, None
            cert_counts['tail'] += 1
        need(interval not in intervals[wid], 'Duplicate saved active-interval certificate')
        intervals[wid].add(interval)
    for wid, row in profiles.items():
        points = sorted(critical(row['profile']['entries']))
        expected = set(zip([Fraction(0)] + points, points + [None]))
        need(intervals[wid] == expected, 'Missing own-envelope finite interval or tail certificate')
        required_probes[wid].update(points + [Fraction(0)])
        for left, right in expected:
            required_probes[wid].add(left + 1 if right is None else (left + right) / 2)
        need(required_probes[wid] <= present[wid], 'Missing saved scalar breakpoint/refinement/interior evidence')
    need(len(scalar) == 108 and len(certificates) == 22 and cert_counts == {'finite': 4, 'tail': 18}, 'Saved original-arc evidence coverage')
    return {'saved_scalar_records_reaggregated': len(scalar), 'saved_certificates_cross_checked': len(certificates),
            'finite_interval_certificates': cert_counts['finite'], 'unbounded_tail_certificates': cert_counts['tail'],
            'saved_feasible_paths_replayed_on_original_net': witness_replays,
            'fresh_global_optimality_or_lexicographic_solver_calls': 0,
            'saved_global_optimality_assertions_used_as_saved_evidence': True}


def check_traffic():
    plan = read(HERE / 'inputs/traffic_affine_plan.json')
    unitplan = read(HERE / 'inputs/traffic_unit_plan.json')
    unitwords = read(HERE / 'inputs/traffic_unit_words.json')
    coverage = read(HERE / 'inputs/traffic_affine_full_coverage.json')
    paired = read(HERE / 'inputs/traffic_affine_pairs.json')
    word_rows = rows(HERE / 'inputs/traffic_affine_words.jsonl')
    doc = read(HERE / 'inputs/traffic_original_model.json')['net_doc']
    check_net(doc)
    need(unitplan['acceptance'] == 'PREFIX_ANY_REACHABLE_MARKING', 'Traffic unit acceptance contract')
    cases = {c['id']: c for c in unitplan['cases']}
    pairs = {r['pair_id']: r for r in unitplan['pairs']}
    expected_keys = {(c['id'], i) for c in unitplan['cases'] for i in range(len(c['events']))}
    need(len(cases) == len(unitplan['cases']) == 512 and len(pairs) == len(unitplan['pairs']) == len(expected_keys) == 1806, 'Full Traffic case/position denominator')
    need([r['variant_id'] for r in unitwords] == list(range(len(unitwords))) and len(unitwords) == len(unitplan['variants']) == 63, 'Full Traffic unit word coverage')
    for row, variant in zip(unitwords, unitplan['variants']):
        need(row['word'] == variant['word'] and row['variant_id'] == variant['variant_id'], 'Unit word identity')
        mapped_unit(row, list(range(len(row['word']))))
        need(type(row['cost']) is int and row['cost'] >= 0, 'Invalid nonnegative unit optimum')
        if row['cost'] == 0:
            need(not row['possible_log_ids'], 'Zero-deviation optimum admits LOG role')
    cov = {r['pair_id']: r for r in coverage}
    need(len(cov) == len(coverage) == 1806 and set(cov) == set(pairs), 'Traffic full-coverage identity set')
    planned_coverage = {r['pair_id']: r for r in plan['all_pair_coverage']}
    need(len(planned_coverage) == len(plan['all_pair_coverage']) == 1806 and set(planned_coverage) == set(cov), 'Planned/final coverage identity set')
    for pid in cov:
        need(all(cov[pid][k] == planned_coverage[pid][k] for k in PAIR_KEYS + ('coverage',)), 'Planned/final coverage scientific identity disagreement')
    candidates = {r['pair_id']: r for r in plan['candidate_pairs']}
    profiles_by_pair = {r['pair_id']: r for r in paired}
    need(len(candidates) == len(plan['candidate_pairs']) == len(profiles_by_pair) == len(paired) == 17, 'Traffic numeric candidate coverage')
    profiles = {r['word_id']: r for r in word_rows}
    planned_words = {r['word_id']: r for r in plan['words']}
    need(set(profiles) == set(planned_words) == set(range(18)) and len(word_rows) == len(plan['words']) == 18, 'Full affine word identity set')
    for wid, row in profiles.items():
        need(row['word'] == planned_words[wid]['word'], 'Affine profile word binding')
        entries_check(row)
    zero_witnesses, zero_case_ids, analytical_ids, numeric_ids, unit_positives, seen_keys = {}, set(), set(), set(), set(), set()
    required_probes, categories, all_points = defaultdict(set), Counter(), set()
    reconstructed, open_checks, pair_cell_count, normal_count = [], 0, 0, 0
    for pid, item in sorted(pairs.items()):
        need(all(cov[pid][key] == item[key] for key in PAIR_KEYS), 'Coverage row is bound to a different Traffic pair')
        case, pos = cases[item['case']], item['position']
        ids = [e['id'] for e in case['events']]
        old_ids = ids[:pos] + ids[pos + 1:]
        key = item['case'], pos
        need(key not in seen_keys and key in expected_keys and ids[pos] == item['delayed_record_id'], 'Traffic restoration identity')
        seen_keys.add(key)
        need(item['normal_last_record_control'] == (pos == len(ids) - 1), 'Traffic normal-last contract')
        normal_count += int(item['normal_last_record_control'])
        before_row, after_row = unitwords[item['before_variant']], unitwords[item['after_variant']]
        word = [e['concept'] for e in case['events']]
        need(after_row['word'] == word and before_row['word'] == word[:pos] + word[pos + 1:], 'Full Traffic event/word/variant mapping')
        before, after = mapped_unit(before_row, old_ids), mapped_unit(after_row, ids)
        unit_yes = before['cost'] == after['cost'] and role_changed(before, after, old_ids)
        if unit_yes:
            unit_positives.add(pid)
        if after['cost'] == 0:
            zero_case_ids.add(item['case'])
            vid = item['after_variant']
            if vid not in zero_witnesses:
                path, visits = zero_path(doc, word)
                zero_witnesses[vid] = {'variant_id': vid, 'word': word, 'path': path, 'visited_sync_silent_states': visits}
            analytical_ids.add(pid)
            need(pid not in candidates and pid not in profiles_by_pair, 'Zero-after analytic pair wrongly replaced by numeric subset')
            need(cov[pid]['coverage'] == 'ANALYTICAL_ZERO_AFTER_SAME_COST_ROLE_NEGATIVE_ALL_RHO_POSITIVE', 'Wrong analytic coverage label')
            need(cov[pid]['all_positive_rho_same_cost_role_revision_possible'] is False and cov[pid]['numerical_affine_execution_claimed'] is False, 'Analytic coverage claims disagree with proof')
            need(not unit_yes, 'Zero-after same-cost role change contradicts positive deviation cost')
            reconstructed.append({'pair_id': pid, 'case': item['case'], 'position': pos, 'coverage': 'ORIGINAL_NET_ZERO_DEVIATION_WITNESS', 'unit_target': False, 'any_positive_rho_target': False, 'all_positive_rho_target': False})
            continue
        numeric_ids.add(pid)
        need(pid in candidates and pid in profiles_by_pair, 'Missing nonzero-after numeric profile')
        candidate, row = candidates[pid], profiles_by_pair[pid]
        need(all(candidate[key] == row[key] == item[key] for key in PAIR_KEYS), 'Candidate/profile/full-cohort identity mismatch')
        need(row['status'] == 'EXACT_PAIR_FULL_POSITIVE_RHO_PROFILE', 'Incomplete numeric pair profile')
        for answer in (candidate, row):
            need(answer['after_ids'] == ids and answer['before_ids'] == old_ids, 'Numeric profile record identities differ')
            need(answer['unit_pair']['pair_id'] == pid and all(answer['unit_pair'][k] == item[k] for k in PAIR_KEYS), 'Numeric saved unit-pair identity mismatch')
            for endpoint, current in (('before', before), ('after', after)):
                saved = answer['unit_pair'][endpoint]
                need(saved['cost'] == current['cost'] and all(set(saved[f]) == set(current[f]) for f in FIELDS), 'Numeric unit-pair/full saved word answer mismatch')
            need(answer['unit_pair']['same_cost_old_role_revision'] == unit_yes, 'Numeric unit target/full answer mismatch')
            need(answer['before_word_id'] == row['before_word_id'] and answer['after_word_id'] == row['after_word_id'], 'Candidate affine word index mismatch')
        before_entries = profiles[row['before_word_id']]['profile']['entries']
        after_entries = profiles[row['after_word_id']]['profile']['entries']
        need(profiles[row['before_word_id']]['word'] == before_row['word'] and profiles[row['after_word_id']]['word'] == after_row['word'], 'Affine word/unit variant binding')
        for entries, saved in ((before_entries, before), (after_entries, after)):
            zero = at(entries, Fraction(0), old_ids if saved is before else ids)
            need(zero['cost'] == saved['cost'] and all(set(zero[f]) == set(saved[f]) for f in FIELDS), 'Affine rho=0/full unit answer mismatch')
        category, points, probes, count, cell_count = check_pair_cells(row, before_entries, after_entries)
        need(category['unit_revision'] == unit_yes, 'Pair profile unit-target inconsistency')
        need(cov[pid]['coverage'] == 'NUMERICAL_AFFINE_CANDIDATE_ALL_ORIGINAL_POSITIONS' and cov[pid]['numerical_affine_execution_claimed'] is True, 'Wrong final numeric coverage label')
        need(planned_coverage[pid]['numerical_affine_execution_claimed'] is False, 'Unexpected planned execution claim')
        need(cov[pid]['classification'] == category, 'Final full-coverage row classification mismatch')
        categories.update({k: int(v) for k, v in category.items()})
        all_points.update(points)
        required_probes[row['before_word_id']].update(probes)
        required_probes[row['after_word_id']].update(probes)
        open_checks += count
        pair_cell_count += cell_count
        reconstructed.append({'pair_id': pid, 'case': item['case'], 'position': pos, 'coverage': 'EXACT_SAVED_AFFINE_ENVELOPE', 'unit_target': unit_yes, 'any_positive_rho_target': category['any_positive_rho_revision'], 'all_positive_rho_target': category['all_positive_rho_revision']})
    need(seen_keys == expected_keys and len(analytical_ids) == 1789 and len(zero_case_ids) == 510 and len(numeric_ids) == 17, 'Derived full-cohort analytic/numeric partition')
    need(numeric_ids == set(candidates) == set(profiles_by_pair), 'Omitted/duplicate numeric target identities')
    need(normal_count == 512, 'Full Traffic normal-last control denominator')
    for _, _, _, probe in cells(sorted(all_points)):
        for wid in profiles:
            required_probes[wid].add(probe)
    original_evidence = check_saved_original_evidence(profiles, required_probes, doc)
    positives = [r for r in reconstructed if r['any_positive_rho_target']]
    persistent = [r for r in reconstructed if r['all_positive_rho_target']]
    need(len(unit_positives) == 6 and len(positives) == len(persistent) == 2 and len({r['case'] for r in positives}) == 2, 'Traffic reconstructed target counts')
    need(categories['normal_last_any_positive_revision'] == 0, 'Traffic normal-last target count')
    return {'cases': len(cases), 'positions': len(pairs), 'unit_words': len(unitwords),
            'analytical_zero_after_positions': len(analytical_ids), 'analytical_zero_after_cases': len(zero_case_ids),
            'new_original_net_zero_deviation_witnesses': len(zero_witnesses),
            'zero_deviation_witnesses_cover_all_analytic_positions': True,
            'numerically_profiled_positions': len(numeric_ids), 'unit_same_cost_positive': len(unit_positives),
            'all_positive_rho_same_cost_positive': len(persistent), 'any_positive_rho_same_cost_positive': len(positives),
            'positive_cases': len({r['case'] for r in positives}), 'persistent_pair_ids': [r['pair_id'] for r in persistent],
            'full_normal_last_controls': normal_count, 'normal_last_positive': categories['normal_last_any_positive_revision'],
            'open_cells_verified_as_entire_affine_functions': open_checks, 'exact_pair_cells_rebuilt': pair_cell_count,
            'category_pair_counts': dict(categories), 'saved_original_evidence': original_evidence,
            'fresh_affine_profile_optimization': False, 'fresh_weighted_alignment_optimization': False,
            'positive_axis': 'normalized g(length)=length+rho for nonempty gaps; rho>0; g(0)=0',
            'zero_after_proof': 'Every included after word has a newly replayed original SYNC/silent execution with D=K=0. Nonempty gaps have strictly positive cost for every rho>0. Every optimal zero-cost path therefore has no LOG/MODEL moves. If the before optimum equals the after optimum zero, its LOG support is also empty; retained-record role revision is impossible.'}, reconstructed, zero_witnesses


def check_manifest():
    manifest = read(HERE / 'manifest.json')
    paths = [r['path'] for r in manifest['files']]
    need(len(paths) == len(set(paths)), 'Duplicate shipped-file manifest entry')
    shipped = {str(p.relative_to(HERE)).replace('\\', '/') for p in HERE.rglob('*') if p.is_file()}
    need(shipped == set(paths) | {'manifest.json'}, 'Unlisted or missing shipped component')
    for row in manifest['files']:
        path = HERE / row['path']
        need(path.resolve().is_relative_to(HERE.resolve()), 'Manifest path escapes bundle')
        need(path.stat().st_size == row['bytes'] and digest(path) == row['sha256'], 'Shipped component hash mismatch: ' + row['path'])
    return manifest


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    need(not args.output.exists() and not args.output.resolve().is_relative_to(HERE.resolve()), 'Output must be new and outside bundle')
    manifest = check_manifest()
    manual = check_manual()
    traffic, pairs, witnesses = check_traffic()
    need(check_manifest() == manifest, 'Shipped metadata changed during verification')
    report = {'status': 'PASS_FULL_IDENTITY_BOUND_SAVED_CONTROLS_AND_ORIGINAL_ZERO_DEVIATION_WITNESSES_V2',
              'manual': manual, 'traffic': traffic,
              'fresh_discovery_or_gap_profile_optimization_executed': False,
              'fresh_weighted_alignment_optimization_executed': False,
              'new_sync_silent_feasibility_and_original_arc_witness_replay_executed': True,
              'manual_reference_global_optimality_recomputed': False,
              'nonzero_affine_global_optimality_recomputed': False,
              'source_manifest_sha256': digest(HERE / 'manifest.json'),
              'platform_observed': platform.system(), 'python_observed': platform.python_version()}
    args.output.mkdir(parents=True, exist_ok=False)
    (args.output / 'report.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    (args.output / 'traffic_full_pair_reaggregation.json').write_text(json.dumps(pairs, indent=2) + '\n', encoding='utf-8')
    (args.output / 'traffic_original_zero_after_witnesses.json').write_text(json.dumps(list(witnesses.values()), indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report), flush=True)


if __name__ == '__main__':
    main()
