# Saved timestamp and Traffic controls, V2

Run `python -B verify_saved_controls.py --output ../new-control-result`.
Use Python 3.9 or later; the standard library is sufficient. The result directory
must be new and outside this bundle. No network or external optimizer is used.

The consumer verifies the complete shipped file set and all SHA256 hashes before
and after execution. Every source file is an exact scientific byte copy; the
manifest records its source-relative path and source hash.

## Manual-reference ordering control

The input includes all 512 cases, all 2,295 deletion/restoration positions, all
107 saved partial-order word structures, and the full original XML-order pair
answers. The consumer reconstructs original-position restoration, common record
identities, and predecessor masks directly from event timestamps. It reaggregates
all four saved complete roles, minimum costs, and target comparisons under both
ordering contracts. Expected result: XML-order 28 targets; unordered timestamp
ties 0; all 512 unordered-tie after traces have saved cost zero. A target is an
equal-cost revision of complete roles of retained records.

The manual reference PNML is omitted because its redistribution permission is
unresolved. Its alignment optimization is not rerun by this consumer. The manual
experiment checks ordering sensitivity of this external reference; it supplies
neither business-error labels nor an independently sampled process.

## Complete Traffic denominator and zero-after proof

The bundle contains the full 512-case/1,806-position unit plan, all 63 exact saved
unit word answers, the original integer Petri net, the affine plan, and the final
full-cohort coverage table. All pair, case, position, record, and variant identities
are bound across these inputs. The 17 numeric pairs are exactly all positions of
the two cases with nonzero after cost. The 1,789 remaining positions belong to
510 after-zero cases; this partition is derived from the full saved unit answers,
not from prewritten negative flags.

For each distinct after-zero word, the consumer newly finds a feasible execution
using only SYNC and silent transitions of the original integer net, then replays
it. These executions end in ordinary original markings under PREFIX acceptance.
For every positive rho, nonempty gaps cost length+rho and zero-length gaps cost
zero. The new zero-deviation witnesses therefore establish minimum cost zero;
every optimal zero-cost execution contains no LOG/MODEL move. If the before and
after costs are equal, both have zero cost and empty LOG supports, so the target
is impossible for all 1,789 positions. This is a feasibility/proof check, not a
new weighted alignment or gap-profile optimization run.

## Nonzero affine profiles and saved original-arc evidence

All 18 saved fixed-K word profiles and all 17 paired profiles are used. Exact
rational lower envelopes are rebuilt from K*rho+D entries. Each word-envelope
breakpoint and each active before/after cost crossing is derived independently.
The consumer requires every open interval, every breakpoint point atom, and the
unbounded tail; omissions, duplicates, and incorrect point ordering stop the run.
Open-cell equality is equality of the entire active (K,D) functions, verified by
endpoint envelope inequalities and smallest-slope tail inequalities. Equality
at a midpoint alone is insufficient. Complete active role unions, record-ID
projection, and gain/loss sets are recomputed and compared with the saved rows.

The consumer also uses all 108 saved original-arc scalar records and all 22 saved
active-interval certificates (4 finite intervals and 18 tails). It checks their
word/parameter identities, costs, four roles, finite endpoint/interior lines,
lexicographic count consistency, and complete required-probe coverage. It newly
replays every included scalar/certificate/lexicographic feasible path on the
original integer arcs. This replays feasibility and cross-checks saved optimality
evidence. It does not rerun the nonzero global scalar or lexicographic optimizer,
re-certify all inactive/dominated fixed-K entries, or execute a third-party native
method. Expected Traffic result: unit target 6; targets for every positive rho 2;
the full denominator remains 1,806; every normal-last target count is zero.

## Saved outputs and scope

The result directory contains `report.json`, every reconstructed Traffic pair in
`traffic_full_pair_reaggregation.json`, and new original-net zero-deviation
witnesses in `traffic_original_zero_after_witnesses.json`. The report separates
new feasible-path executions from saved-profile reaggregation and saved original-
arc evidence. This bundle supplements the core and unit-extension artifacts.

The public data sources are BPI Challenge 2012 and Road Traffic Fine Management
Process on 4TU.ResearchData. Dataset attribution and individual redistribution
terms accompany the review landing page. No blanket third-party license is
inferred; no manual PNML or third-party optimizer source is redistributed here.
Record IDs, event concepts, and timestamps are scientific data. No manuscript,
private machine path, author identity, account credential, or visitor tracking is
included. The artifact reports the platform actually exercised; portability to
unexercised operating systems is not an observed experimental result.
