"""Portable standard-library consumer; independent pair aggregation and original arcs."""
from collections import Counter
from fractions import Fraction
from pathlib import Path
import argparse, hashlib, json, platform, time
import original_active_oracle as oracle

HERE=Path(__file__).resolve().parent
FIELDS=('possible_log_ids','mandatory_log_ids','forced_sync_ids','ambiguous_consumption_ids')
ORACLE_FIELDS=('possible_log_positions','mandatory_log_positions','forced_sync_positions','ambiguous_positions')
MODELS=('bpi2013_IMf01','bpi2013_IMf02','bpi2013_IMf03','traffic_IM0','traffic_IMf02')

def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def validate(row):
    assert row['status'].startswith('EXACT')
    n=len(row['word']); P,M,S,A=map(lambda f:set(row[f]),FIELDS);U=set(range(n))
    assert all(len(row[f])==len(set(row[f])) for f in FIELDS)
    assert M<=P<=U and S==U-P and A==P-M
def mapped(row,ids):
    assert len(row['word'])==len(ids)
    return {f:{ids[i] for i in row[f]} for f in FIELDS}

def run(out):
    start=time.monotonic();out.mkdir(exist_ok=False)
    manifest=read(HERE/'manifest.json')
    for e in manifest['files']:
        p=HERE/e['path']; assert p.stat().st_size==e['bytes'] and sha(p)==e['sha256'],e['path']
    reviews=[]
    for name in MODELS:
        p=read(HERE/'inputs'/('plan_'+('bpi2013' if name.startswith('bpi') else 'traffic')+'.json'))
        words=read(HERE/'inputs'/('words_'+name+'.json')); expected=read(HERE/'inputs'/('expected_'+name+'.json'))
        assert [r['variant_id'] for r in words]==list(range(len(words)))
        assert len(words)==len(p['variants'])
        for row,v in zip(words,p['variants']): assert row['word']==v['word'];validate(row)
        cases={c['id']:c for c in p['cases']};assert len(cases)==len(p['cases'])
        assert len(p['pairs'])==sum(len(c['events']) for c in p['cases'])
        cnt=Counter();positive_endpoints=set();positive_cases=set();seen_pairs=set()
        for item in p['pairs']:
            c=cases[item['case']];pos=item['position'];es=c['events'];ids=[e['id'] for e in es];word=[e['concept'] for e in es]
            assert len(ids)==len(set(ids)) and item['delayed_record_id']==ids[pos]
            assert (c['id'],pos) not in seen_pairs;seen_pairs.add((c['id'],pos))
            b,a=words[item['before_variant']],words[item['after_variant']]
            assert a['word']==word and b['word']==word[:pos]+word[pos+1:]
            beforeids=ids[:pos]+ids[pos+1:];B=mapped(b,beforeids);A=mapped(a,ids);old=set(beforeids)
            rev=any(B[f]!=(A[f]&old) for f in FIELDS);same=b['cost']==a['cost'];d1=b['cost']==a['cost']==1
            normal=pos==len(es)-1;assert item['normal_last_record_control']==normal
            cnt.update({'planned_pairs':1,'exact_pairs':1,'normal_last_controls':int(normal),
                'same_cost_pairs':int(same),'old_role_changed_pairs':int(rev),
                'same_cost_role_revision_pairs':int(same and rev),'both_D1_pairs':int(d1),
                'D1_role_revision_pairs':int(d1 and rev),'normal_last_exact_controls':int(normal),
                'normal_last_same_cost_role_revisions':int(normal and same and rev),
                'normal_last_D1_role_revisions':int(normal and d1 and rev),
                'D1_mandatory_gain_pairs':int(d1 and bool((A['mandatory_log_ids']&old)-B['mandatory_log_ids'])),
                'D1_mandatory_withdrawal_pairs':int(d1 and bool(B['mandatory_log_ids']-A['mandatory_log_ids']))})
            if same and rev: positive_cases.add(c['id']);positive_endpoints.update([item['before_variant'],item['after_variant']])
        for key,value in expected['counts'].items():
            if key=='planned_cases':assert value==len(cases)
            elif key=='censored_pairs':assert value==0
            else:assert cnt[key]==value,(name,key,cnt[key],value)
        assert len(positive_cases)==expected['same_cost_revision_cases']
        selected=sorted(words,key=lambda r:hashlib.sha256(('portable-extension-v1|'+name+'|'+json.dumps(r['word'],ensure_ascii=False,separators=(',',':'))).encode()).hexdigest())[:32]
        vids={r['variant_id'] for r in selected}|positive_endpoints
        model=read(HERE/'inputs'/('model_'+name+'.json'))['net_doc'];graph=oracle.original_graph(model)
        assert graph['status']=='EXACT_ORIGINAL_GRAPH'
        with (out/(name+'_original_arc_checks.jsonl')).open('x',encoding='utf-8') as stream:
            for vid in sorted(vids):
                row=words[vid];prod=oracle.build_product(graph,row['word'],final=None,cap=100000)
                assert prod['status'].startswith('EXACT'),prod['status']
                got=oracle.scalar_and_roles(prod,Fraction(0))
                exact_cost=Fraction(got['normalized_cost']['numerator'],got['normalized_cost']['denominator'])
                assert exact_cost==row['cost'],(name,vid,'cost')
                for f,g in zip(FIELDS,ORACLE_FIELDS):assert got[g]==sorted(row[f]),(name,vid,f)
                stream.write(json.dumps({'variant_id':vid,'cost':str(exact_cost),'status':'PASS_COST_AND_ALL_FOUR_ROLES'})+'\n')
        reviews.append({'model':name,'all_pair_counts':dict(cnt),'cases':len(cases),'words':len(words),
            'same_cost_revision_cases':len(positive_cases),'independent_original_arc_words':len(vids),
            'hash_selected_words':len(selected),'positive_endpoint_words':len(positive_endpoints),
            'markings':len(graph['markings']),'status':'PASS_ALL_SAVED_ROWS_AND_DECLARED_INDEPENDENT_SUBSET'})
        print(json.dumps(reviews[-1]),flush=True)
    for e in manifest['files']:assert sha(HERE/e['path'])==e['sha256']
    receipt={'status':'ACTUAL_PORTABLE_CONSUMER_COMPLETE','reviews':reviews,
        'full_fresh_optimization':False,'fresh_discovery':False,'acceptance':'PREFIX',
        'manifest_sha256':sha(HERE/'manifest.json'),'python':platform.python_version(),'seconds':time.monotonic()-start}
    with (out/'receipt.json').open('x',encoding='utf-8') as stream:json.dump(receipt,stream,indent=2)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);args=ap.parse_args();run(args.out)
