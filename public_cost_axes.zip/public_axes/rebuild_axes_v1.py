"""Fresh complete public weighted/affine axes from original integer arcs, stdlib only."""
import argparse
import ast
from collections import Counter, defaultdict
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import platform
import sys
import time
import traceback

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from kernels import weighted_layers as layers
from kernels import weighted_oracle as weighted
from kernels import zero_one
from kernels import full_mapping as mapping
from kernels import original_active_oracle as oracle
from kernels import affine_axis as axis
from kernels import unit_axis_proof as proof
from kernels import raw_fixtures as raw

FIELDS=('possible_log_ids','mandatory_log_ids','forced_sync_ids','ambiguous_consumption_ids')
ROLE_FIELDS=axis.ROLE_FIELDS
POSITION_FIELDS=axis.POSITION_FIELDS
CATEGORIES=('any_positive_revision','all_positive_revision','open_interval_revision','point_revision','isolated_only_revision','classic_revision','default_revision')
CAP=100000

def sha(data):return hashlib.sha256(data).hexdigest()
def read(relative):return json.loads((ROOT/relative).read_text(encoding='utf-8'))
def rows(relative):
    with (ROOT/relative).open(encoding='utf-8') as f:return [json.loads(s) for s in f if s.strip()]
def save(path,obj):
    with path.open('x',encoding='utf-8',newline='\n') as f:
        json.dump(obj,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
def emit(f,obj):f.write(json.dumps(obj,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n');f.flush()
def same(a,b,label):assert a==b,(label,a,b)
def unique(objects,field):
    result={r[field]:r for r in objects};same(len(result),len(objects),('unique',field));return result
def q(v):return mapping.q(Fraction(v))
def frac(doc):return Fraction(doc['numerator'],doc['denominator'])
def source_functions(data):
    lines=data.splitlines(keepends=True);result={}
    for node in ast.parse(data.decode('utf-8')).body:
        if isinstance(node,ast.FunctionDef):
            first=min([node.lineno]+[d.lineno for d in node.decorator_list])
            result[node.name]=(b''.join(lines[first-1:node.end_lineno]),node)
    return result
def verify_bundle():
    manifest=read('manifest.json');parsed={}
    for r in manifest['files']:
        path=ROOT/r['export_relative'];assert path.resolve().is_relative_to(ROOT)
        data=path.read_bytes();same(len(data),r['export_bytes'],'export bytes');same(sha(data),r['export_sha256'],'export SHA')
        if r['transformation']=='UNCHANGED_BYTE_COPY':same(r['source_sha256'],r['export_sha256'],'unchanged source SHA')
    for r in manifest['exact_function_provenance']:
        for name in [r['shipped_source_relative'],r['derivative_relative']]:
            if name not in parsed:parsed[name]=source_functions((ROOT/name).read_bytes())
        a,anode=parsed[r['shipped_source_relative']][r['name']];b,bnode=parsed[r['derivative_relative']][r['name']]
        same(a,b,('exact function bytes',r['name']));same(sha(a),r['function_bytes_sha256'],'exact function SHA')
        ast_bytes=ast.dump(anode,include_attributes=False).encode('utf-8')
        same(sha(ast_bytes),r['function_AST_sha256'],'AST SHA')
        same(ast.dump(anode,include_attributes=False),ast.dump(bnode,include_attributes=False),'AST exact')
    return manifest
def after_call(start,cohort):
    elapsed=time.monotonic()-start
    assert elapsed<=200,('PORTABLE_LIMIT_POST_CALL_200_SECONDS',elapsed)
    assert time.monotonic()-cohort<=7200,'PORTABLE_LIMIT_POST_INPUT_7200_SECONDS'

def load_scope():
    plan=read('data/plan.json');variants=rows('data/variants.jsonl');cases=rows('data/native_cases.jsonl')
    original=read('data/original_subset_prepared_data.json')
    original_ids={c['id'] for c in original['evaluation_cases']}
    same(len(original_ids),128,'original evaluation subset independently supplied')
    same(len(cases),1511,'all source cases');same(sum(len(c['events']) for c in cases),8735,'all source records')
    rebuilt_plan=mapping.make_plan(cases,original_ids)
    same(rebuilt_plan,plan,'WHOLE plan independently rebuilt from source event IDs/positions/clocks/subset IDs')
    same(len(variants),3011,'all distinct words');same(len(plan['variants']),3011,'all planned variants')
    same(len(plan['snapshots']),10246,'all snapshots');same(len(plan['pairs']),8735,'all restoration pairs')
    same(sum(p['normal_last_record_control'] for p in plan['pairs']),1511,'all normal-last controls')
    same(len({tuple(v['word']) for v in variants}),3011,'unique word population')
    for i,(v,p) in enumerate(zip(variants,plan['variants'])):
        same(v['variant_id'],i,'whole word IDs');same({k:v[k] for k in p},p,'full source word')
        mapping.weighted_contract(v['weighted_profile'],v['word'])
        same(v['affine_profile']['status'],'EXACT_FIXED_GAP_COUNT_PROFILE','all saved candidate affine profiles exact')
    model=read('data/model.json')
    start=time.monotonic();transitions,graph=layers.own_graph(model['net_doc']);after_call(start,start)
    same(len(graph['markings']),145,'original markings');same(sum(map(len,graph['edges'])),637,'original firings')
    same(layers.edge_set(transitions,graph),layers.edge_set(model['net_doc']['transitions'],model['graph']),'all original integer-arc edge sets')
    direct_graph=oracle.original_graph(model['net_doc'])
    same(direct_graph['status'],'EXACT_ORIGINAL_GRAPH','fresh exact original affine graph')
    same(layers.edge_set(transitions,graph),axis.original_edge_set(direct_graph['transitions'],direct_graph) if hasattr(axis,'original_edge_set') else
         {(tuple(direct_graph['markings'][u]),direct_graph['transitions'][ti]['id'],tuple(direct_graph['markings'][v])) for u,edges in enumerate(direct_graph['edges']) for ti,v in edges},'independent graph conventions exact')
    historical=rows('data/independent_words.jsonl');same(len(historical),3011,'historical independent whole words')
    same(sum(r['affine']['status']=='LIMIT_INDEPENDENT_ORIGINAL_PRODUCT' for r in historical),68,'historical fixed-K LIMITs preserved')
    return plan,variants,cases,transitions,graph,direct_graph,unique(historical,'variant_id')

def fixtures():
    results={'weighted_thresholds':weighted.self_test()}
    doc={'places':['p0','p1'],'initial':[1,0],'transitions':[
        {'id':'a','label':'A','pre':[1,0],'post':[0,1]},
        {'id':'x0','label':'X','pre':[1,0],'post':[1,0]},
        {'id':'x1','label':'X','pre':[0,1],'post':[0,1]}]}
    transitions,graph=layers.own_graph(doc);cyclic=[]
    for word,want in [([],[0]),(['A'],[0,0]),(['B'],[None,0]),(['A','A'],[None,0,0])]:
        events=[{'id':str(i),'concept':label} for i,label in enumerate(word)]
        product=mapping.fixed_count_product(transitions,graph,word)
        minima=layers.layered_minimum_models(transitions,graph,events,Counter())
        same(minima,want,'cyclic original weighted fixed-j fixture')
        distances=zero_one.zero_one(product['edges'],[0])
        same([min((distances[u] for u in ends),default=None) for ends in product['endpoints']],minima,'independent DP/0-1 fixture')
        cyclic.append({'word':word,'minimum_models_by_log_count':minima})
    same(mapping.fixed_count_product(transitions,graph,['A','A'],cap=3)['status'],'LIMIT_INDEPENDENT_WEIGHTED_COUNT_PRODUCT','weighted negative cap fixture')
    results['cyclic_weighted']=cyclic
    rows_out=[];checks=0;proof_checks=0
    fixtures_spec=[(('A','B'),('A','B'),False,False,False),(('A','B'),('A','B'),True,False,False),
        (('A','B'),('A',),False,False,False),(('A','B'),('A',),True,False,False),
        (('A','B'),('Z','A','B'),True,False,False),(('A','A'),('A','A','A'),True,False,False),
        (('A','A'),('A',),True,True,False),(('A','B'),('Z','Z'),True,True,True),
        (('A','B'),(),False,False,False),(('A','B'),(),True,True,False),
        (('S','A','B','E'),('S','A','A','E'),True,False,False),(('A','B','C'),('A','X','C','Y'),True,False,False)]
    for index,(labels,word,completed,silent,duplicate) in enumerate(fixtures_spec):
        doc,final=raw.serial(labels,silent,duplicate);accept=final if completed else None
        graph=oracle.original_graph(doc);product=oracle.build_product(graph,word,accept)
        paths=raw.raw_paths(doc,word,accept)
        unit=oracle.scalar_and_roles(product,0);ids=['v%06d'%i for i in range(len(word))]
        unit_ids={'cost':frac(unit['normalized_cost']).numerator,
            **{field:sorted(ids[p] for p in unit[position]) for field,position in zip(FIELDS,('possible_log_positions','mandatory_log_positions','forced_sync_positions','ambiguous_positions'))}}
        for rho in [Fraction(0),Fraction(1,3),Fraction(1),Fraction(2),Fraction(3),Fraction(10)]:
            expected,counts=raw.raw_at(paths,rho,len(word));actual=oracle.scalar_and_roles(product,rho)
            same({k:actual[k] for k in ('normalized_cost',)+POSITION_FIELDS},expected,'independent original raw path / scalar full role fixture')
            if unit_ids['cost'] in (0,1):
                inherited=proof.proof_at(unit_ids,rho,ids)
                same(inherited['normalized_cost'],expected['normalized_cost'],'D0/D1 whole-axis inheritance fixture')
                for field,position in zip(ROLE_FIELDS,POSITION_FIELDS):same(inherited[field],sorted(ids[p] for p in expected[position]),'D0/D1 complete role inheritance fixture')
                proof_checks+=1
            checks+=1
        lexical=oracle.lexicographic_K_D(product)
        same((lexical['globally_minimum_K'],lexical['minimum_D_at_minimum_K']),min((len(g),sum(g)) for g,_,_ in paths),'raw lexical fixture')
        rows_out.append({'fixture':index,'raw_paths':len(paths),'unit_D':unit_ids['cost']})
    doc,final=raw.serial(('A','B','C'));product=oracle.build_product(oracle.original_graph(doc),('A','X','C','Y'),final)
    finite=oracle.certify_finite_interval(product,0,2,2,3);tail=oracle.certify_unbounded_tail(product,2,1,5)
    same(finite['interior_direct_answer']['mandatory_log_positions'],[1,3],'real finite breakpoint roles')
    same(tail['interior_direct_answer']['mandatory_log_positions'],[1,2,3],'real lexical tail roles')
    same(oracle.scalar_and_roles(product,2)['ambiguous_positions'],[2],'complete breakpoint tie role')
    negative=[('wrong_finite_interval',lambda:oracle.certify_finite_interval(product,0,4,2,3)),
        ('infeasible_line',lambda:oracle.certify_finite_interval(product,0,1,1,3)),
        ('wrong_tail_minimum_K',lambda:oracle.certify_unbounded_tail(product,0,2,3)),
        ('negative_rho',lambda:oracle.scalar_and_roles(product,-1)),
        ('empty_interval',lambda:oracle.certify_finite_interval(product,2,2,1,5)),
        ('D2_inheritance_rejected',lambda:proof.proof_at({'cost':2},Fraction(0),[])),
        ('negative_inheritance_rho',lambda:proof.proof_at({'cost':0},Fraction(-1),[]))]
    rejected=[]
    for name,call in negative:
        try:call()
        except AssertionError:rejected.append(name)
        else:raise AssertionError(('invalid proof accepted',name))
    cyclic_doc,cyclic_final=raw.serial(('A','B'),zero_self=True);plain_doc,plain_final=raw.serial(('A','B'))
    cyclic_product=oracle.build_product(oracle.original_graph(cyclic_doc),('A','Z','B'),cyclic_final)
    plain_product=oracle.build_product(oracle.original_graph(plain_doc),('A','Z','B'),plain_final)
    for rho in [Fraction(0),Fraction(1,2),Fraction(2),Fraction(9)]:
        a,b=oracle.scalar_and_roles(cyclic_product,rho),oracle.scalar_and_roles(plain_product,rho)
        same({k:a[k] for k in ('normalized_cost',)+POSITION_FIELDS},{k:b[k] for k in ('normalized_cost',)+POSITION_FIELDS},'zero silent cycle full roles')
    same(oracle.build_product(oracle.original_graph(plain_doc),('A','Z','B'),plain_final,cap=23)['status'],'LIMIT_RIGOROUS_FULL_PRODUCT_BOUND','affine negative product cap')
    results.update(status='PASS_EXISTING_MEANINGFUL_FULL_AXIS_RAW_PATH_INTEGER_THRESHOLD_CYCLIC_CAP_AND_FALSE_PROOF_FIXTURES',
        raw_DAG_fixtures=rows_out,raw_scalar_role_checks=checks,unit_D0_D1_inheritance_checks=proof_checks,invalid_proofs_rejected=rejected,
        finite_breakpoint_certificate=finite,lexicographic_tail_certificate=tail,formal_words_computed=0,native_calls=0)
    return results

def weighted_word(variant,transitions,graph,historical,counters):
    word=variant['word'];profile=variant['weighted_profile'];ids=['v%06d'%i for i in range(len(word))]
    events=[{'id':i,'concept':label} for i,label in zip(ids,word)]
    product=mapping.fixed_count_product(transitions,graph,word,cap=CAP)
    same(product['status'],'COMPLETE_ORIGINAL_WEIGHTED_COUNT_PRODUCT','full original fixed-count product')
    minima=layers.layered_minimum_models(transitions,graph,events,counters)
    distance=zero_one.zero_one(product['edges'],[0])
    direct=[min((distance[u] for u in targets),default=None) for targets in product['endpoints']]
    same(minima,direct,'ALL fixed-j minima DP and independent 0-1 original product')
    same(minima,[e['model_count'] for e in profile['entries']],'ALL saved fixed-j minimum costs')
    same(minima,historical['weighted']['fixed_j_minimum_model_counts'],'ALL independent fixed-j costs')
    counters['weighted_fixed_j_rows_checked']+=len(minima)
    counters['weighted_fixed_count_states']+=len(product['states']);counters['weighted_fixed_count_edges']+=sum(map(len,product['edges']))
    costs=[(j,m) for j,m in enumerate(minima) if m is not None]
    points=layers.envelope_points(costs)
    probes=set(points)|{Fraction(1)}|{probe for _,_,probe in layers.samples(points)}
    queries={};checks=[]
    for value in sorted(probes):
        rigorous_bound=(len(word)+1)*len(graph['markings'])
        assert rigorous_bound<=CAP,'total-order weighted full product rigorous cap'
        answer=weighted.weighted_oracle(transitions,graph,events,[(1<<i)-1 for i in range(len(word))],value.numerator,value.denominator)
        assert answer['product_states']<=rigorous_bound
        result={'normalized_cost':q(Fraction(answer['cost'],value.denominator)),
            'active_counts':[list(v) for v in layers.active_lines(costs,value)],**{field:answer[field] for field in FIELDS}}
        same(result,mapping.at(profile,'lambda',value,ids),'complete weighted original-arc active cost/all-ID roles')
        queries[value]=result;checks.append({'ratio':q(value),'result':result,'original_oracle_states':answer['product_states'],'restricted_solver_runs':answer['restricted_solver_runs']})
        counters['weighted_active_support_probes']+=1;counters['weighted_forbidden_edge_solver_runs']+=answer['restricted_solver_runs']
    same(checks,historical['weighted']['active_support_certificates'],'ALL independently frozen active weighted support queries')
    unit=queries[Fraction(1)]
    assert frac(unit['normalized_cost']).denominator==1
    unit_result={'cost':frac(unit['normalized_cost']).numerator,**{field:unit[field] for field in FIELDS}}
    entries=[]
    for left,right,probe in layers.samples(points):
        # Exact fixed-j minima give the complete finite line envelope; all active paths on an open cell have the same (j,m).
        active=layers.active_lines(costs,probe);same(len(active),1,'one weighted active count line on each open cell')
        entries.append({'kind':'open_interval','left':q(left),'right':q(right) if right is not None else None,'probe':q(probe),
            'line_LOG_MODEL':list(active[0]),'fresh_original_role_answer':queries[probe]})
        if right is not None:entries.append({'kind':'point','ratio':q(right),'fresh_original_role_answer':queries[right]})
    return {'variant_id':variant['variant_id'],'word':word,'status':'CERTIFIED_COMPLETE_POSITIVE_WEIGHTED_COST_AND_ALL_RECORD_ROLES',
        'fixed_j_minimum_model_counts':minima,'original_fixed_count_states':len(product['states']),
        'original_fixed_count_edges':sum(map(len,product['edges'])),'critical_points':[q(v) for v in points],
        'cells':entries,'lambda_one_unit':unit_result,'fresh_support_queries':checks,
        'inactive_fixed_j_role_supports_independently_certified':False},queries

def affine_word(variant,unit,graph,counters):
    word=variant['word'];ids=['v%06d'%i for i in range(len(word))]
    if unit['cost'] in (0,1):
        record={'variant_id':variant['variant_id'],'word':word,'status':'CERTIFIED_ENTIRE_NONNEGATIVE_AFFINE_ACTIVE_COST_AND_RECORD_ROLES',
            'method':'FRESH_ORIGINAL_UNIT_WHOLE_OPTIMUM_D0_D1_EXACT_INHERITANCE','fresh_unit':unit,
            'proof':'D0: K=D=0. D1: every unit-optimal path has K=D=1; every other path has D>=2 and K>=1, hence costs at least rho+2 for all rho>=0.',
            'all_rho_nonnegative_cost_and_complete_roles_certified':True,'dominated_fixed_K_scope_upgraded':False,'all_active_count_sets_at_ties_claimed':False}
        points=axis.critical_points(variant['affine_profile']['entries'])
        probes={Fraction(0),Fraction(2)}|set(points)|{axis.f(c['probe']) for c in axis.candidate_cells(variant['affine_profile']['entries']) if c['kind']=='open_interval'}
        for rho in sorted(probes):
            inherited=proof.proof_at(unit,rho,ids)
            expected=axis.expected_profile_answer(variant['affine_profile']['entries'],rho,len(word))
            same(inherited['normalized_cost'],expected['normalized_cost'],'D0/D1 complete saved affine cost envelope')
            for field,position in zip(ROLE_FIELDS,POSITION_FIELDS):same(inherited[field],sorted(ids[i] for i in expected[position]),'D0/D1 complete saved role envelope')
        counters['affine_D0_D1_exact_inheritance_words']+=1
    else:
        planned={'variant_id':variant['variant_id'],'word':word,'candidate_cells':axis.candidate_cells(variant['affine_profile']['entries'])}
        record=axis.certify_word(planned,variant,graph)
        same(record['status'],'CERTIFIED_ENTIRE_NONNEGATIVE_AFFINE_ACTIVE_COST_AND_RECORD_ROLES','every D>=2 full original affine axis')
        record={**record,'method':'FRESH_ORIGINAL_SMALL_PRODUCT_ENDPOINT_CHORD_AND_LEXICOGRAPHIC_TAIL'}
        counters['affine_D_ge_2_fresh_entire_axis_words']+=1
        counters['affine_finite_intervals']+=sum(c['kind']=='open_interval' and c['right'] is not None for c in record['cells'])
        counters['affine_critical_points']+=sum(c['kind']=='point' for c in record['cells'])
        counters['affine_lexicographic_unbounded_tails']+=1
    counters['unit_D_'+str(unit['cost'])]+=1
    return record

def affine_mapped(profile,certificate,rho,ids):
    if certificate['method']=='FRESH_ORIGINAL_UNIT_WHOLE_OPTIMUM_D0_D1_EXACT_INHERITANCE':
        inherited=proof.proof_at(certificate['fresh_unit'],Fraction(rho),ids)
        return {k:inherited[k] for k in ('normalized_cost',)+ROLE_FIELDS}
    result=axis.positions_at(certificate,rho)
    return {'normalized_cost':result['normalized_cost'],**{field:sorted(ids[p] for p in result[position]) for field,position in zip(ROLE_FIELDS,POSITION_FIELDS)}}

def weighted_mapped(certificate,ratio,ids):
    ratio=Fraction(ratio);assert ratio>0
    result=None
    for cell in certificate['cells']:
        if cell['kind']=='point' and ratio==frac(cell['ratio']):result=cell['fresh_original_role_answer'];break
        if cell['kind']=='open_interval' and ratio>frac(cell['left']) and (cell['right'] is None or ratio<frac(cell['right'])):
            j,m=cell['line_LOG_MODEL'];result={**cell['fresh_original_role_answer'],'normalized_cost':q(j*ratio+m)};break
    assert result is not None
    source=['v%06d'%i for i in range(len(ids))];translation=dict(zip(source,ids))
    return {k:result[k] for k in ('normalized_cost','active_counts')}|{field:sorted(translation[e] for e in result[field]) for field in FIELDS}

def weighted_pair(before,after,bids,aids):
    before_lines=[(j,m) for j,m in enumerate(before['fixed_j_minimum_model_counts']) if m is not None]
    after_lines=[(j,m) for j,m in enumerate(after['fixed_j_minimum_model_counts']) if m is not None]
    points,_=layers.pair_points(before_lines,after_lines);cells=[]
    def at(value):
        b,a=weighted_mapped(before,value,bids),weighted_mapped(after,value,aids)
        return {'ratio':q(value),'before':b,'after':a,**mapping.change(b,a,set(bids))}
    for left,right,probe in layers.samples(points):
        record=at(probe);record.pop('ratio')
        cells.append({'kind':'open_interval','left':q(left),'right':q(right) if right is not None else None,'probe':q(probe),**record})
        if right is not None:cells.append({'kind':'point',**at(right)})
    classic=at(Fraction(1));open_effect=any(c['same_cost_old_summary_revision'] for c in cells if c['kind']=='open_interval')
    point_effect=any(c['same_cost_old_summary_revision'] for c in cells if c['kind']=='point')
    return {'status':'EXACT_ALL_POSITIVE_PARAMETER_CELLS','parameter':'lambda','critical_points':[q(p) for p in points],
        'cells':cells,'classic':classic,'default':classic,'categories':{'any_positive_revision':open_effect or point_effect,
            'all_positive_revision':all(c['same_cost_old_summary_revision'] for c in cells),'open_interval_revision':open_effect,
            'point_revision':point_effect,'isolated_only_revision':point_effect and not open_effect,
            'classic_revision':classic['same_cost_old_summary_revision'],'default_revision':classic['same_cost_old_summary_revision']}}

def all_pairs(plan,variants,weighted_certificates,affine_certificates,output,counters):
    saved=unique(rows('data/pairs.jsonl'),'pair_id');same(set(saved),set(range(8735)),'full saved pair IDs')
    historical_affine=unique(rows('data/historical_full_affine_pair_scope.jsonl'),'pair_id')
    same(set(historical_affine),set(range(8735)),'historical whole affine pair coverage')
    aggregate={parameter:Counter() for parameter in ('lambda','rho')};category_cases=defaultdict(set)
    # The exact source pair_result calls this explicitly hashed portable proof-dispatch adapter.
    original_mapping=axis.mapped_at
    axis.mapped_at=affine_mapped
    try:
        with (output/'all_8735_parameter_pair_rebuilds.jsonl').open('x',encoding='utf-8',newline='\n') as f:
            for p in plan['pairs']:
                pid=p['pair_id'];before,after=plan['snapshots'][p['before_snapshot_id']],plan['snapshots'][p['after_snapshot_id']]
                bi,ai=before['variant_id'],after['variant_id'];bids,aids=before['event_ids'],after['event_ids']
                same(aids[:p['delayed_position']]+aids[p['delayed_position']+1:],bids,'restored exactly original occurrence ID')
                same({k:saved[pid][k] for k in p},p,'all saved pair source fields')
                w=weighted_pair(weighted_certificates[bi],weighted_certificates[ai],bids,aids)
                a=axis.pair_result(variants[bi]['affine_profile'],variants[ai]['affine_profile'],affine_certificates[bi],affine_certificates[ai],bids,aids)
                same(w,saved[pid]['lambda_result'],'ALL weighted pair cells/points/cost/ID roles/gains/categories')
                axis.compare_saved_pair(a,saved[pid]['rho_result'])
                same(a['categories'],historical_affine[pid]['categories'],'ALL final saved active affine categories')
                for parameter,result in [('lambda',w),('rho',a)]:
                    counters[parameter+'_pairs_checked']+=1;counters[parameter+'_whole_positive_cells_checked']+=len(result['cells'])
                    aggregate[parameter]['all_pairs']+=1
                    for category,positive in result['categories'].items():
                        aggregate[parameter][category]+=int(positive)
                        if positive:category_cases[parameter+'__'+category].add(p['case'])
                    if p['normal_last_record_control']:
                        aggregate[parameter]['normal_last_pairs']+=1
                        assert not any(result['categories'].values()),'normal-last negative control'
                emit(f,{**p,'lambda_result':w,'rho_result':a})
    finally:axis.mapped_at=original_mapping
    same(counters['lambda_pairs_checked'],8735,'all weighted restoration pairs');same(counters['rho_pairs_checked'],8735,'all affine restoration pairs')
    same(counters['lambda_whole_positive_cells_checked'],10799,'full weighted joint cells')
    same(counters['rho_whole_positive_cells_checked'],10829,'full affine joint cells')
    return {p:dict(c) for p,c in aggregate.items()},{k:sorted(v) for k,v in category_cases.items()}

def main():
    parser=argparse.ArgumentParser();modes=parser.add_mutually_exclusive_group(required=True)
    modes.add_argument('--prepare',action='store_true');modes.add_argument('--pilot',action='store_true');modes.add_argument('--run',action='store_true')
    parser.add_argument('--output',required=True);args=parser.parse_args()
    output=Path(args.output).resolve()
    if output.exists():raise FileExistsError('Output exists; use an exclusive fresh version/directory')
    output.mkdir(parents=True);started=time.monotonic()
    try:
        manifest=verify_bundle();plan,variants,cases,transitions,graph,direct_graph,historical=load_scope()
        fixture_results=fixtures();save(output/'meaningful_fixtures.json',fixture_results)
        if args.prepare:
            save(output/'preexecution_gate.json',{'status':'PASS_SOURCE_BOUND_FULL_3011_WORD_10246_IDENTITY_8735_PAIR_PREEXECUTION_GATES',
                'words':3011,'cases':1511,'events':8735,'snapshots':10246,'pairs':8735,'normal_last_controls':1511,
                'original_markings':145,'original_enabled_firings':637,'exact_source_function_records':len(manifest['exact_function_provenance']),
                'historical_68_fixed_K_LIMITs_preserved':True,'formal_words_computed':0,'native_calls':0,'guard_contract':read('guard_contract.json')})
            print(json.dumps({'preexecution':'PASS','words':3011,'pairs':8735,'formal_words_computed':0,'elapsed_seconds':round(time.monotonic()-started,3)}),flush=True);return
        if args.pilot:
            selected=[next(v for v in variants if len(v['word'])==length) for length in [0,6,13,26,40]]
            results=[]
            for v in selected:
                counts=Counter();t=time.monotonic();w,_=weighted_word(v,transitions,graph,historical[v['variant_id']],counts);weighted_elapsed=time.monotonic()-t
                t=time.monotonic();a=affine_word(v,w['lambda_one_unit'],direct_graph,counts);affine_elapsed=time.monotonic()-t
                results.append({'variant_id':v['variant_id'],'word_length':len(v['word']),'unit_D':w['lambda_one_unit']['cost'],
                    'weighted_seconds':weighted_elapsed,'affine_seconds':affine_elapsed,'affine_method':a['method'],
                    'weighted_original_fixed_count_states':w['original_fixed_count_states'],'weighted_active_probes':counts['weighted_active_support_probes'],
                    'weighted_forbidden_runs':counts['weighted_forbidden_edge_solver_runs']})
                print(json.dumps({'pilot_length':len(v['word']),'weighted_seconds':round(weighted_elapsed,3),'affine_seconds':round(affine_elapsed,3),'unit_D':w['lambda_one_unit']['cost']}),flush=True)
            save(output/'performance_pilot.json',{'status':'PASS_LENGTH_SELECTED_PERFORMANCE_PILOT_NOT_FULL_SCOPE_CERTIFICATE',
                'selection_rule':'first frozen variant at each word length 0,6,13,26,40; independent of measured positive outcomes',
                'results':results,'full_word_count':3011,'full_weighted_expected_probes':3609,'full_forbidden_expected_runs':89216,
                'full_D0_D1_expected_words':2307,'full_D_ge_2_expected_fresh_axis_words':704,'native_calls':0,
                'runtime_prediction_is_estimate_not_completion_evidence':True})
            return
        counters=Counter()
        weighted_certificates,affine_certificates={},{}
        cohort=time.monotonic()
        with (output/'weighted_all_3011_words_rebuilt.jsonl').open('x',encoding='utf-8',newline='\n') as wfile,(output/'affine_all_3011_words_rebuilt.jsonl').open('x',encoding='utf-8',newline='\n') as afile:
            for index,v in enumerate(variants):
                t=time.monotonic();w,_=weighted_word(v,transitions,graph,historical[index],counters);after_call(t,cohort)
                t=time.monotonic();a=affine_word(v,w['lambda_one_unit'],direct_graph,counters);after_call(t,cohort)
                weighted_certificates[index]=w;affine_certificates[index]=a;emit(wfile,w);emit(afile,a)
                if (index+1)%25==0 or index==3010:
                    print(json.dumps({'full_axis_words_rebuilt':index+1,'of':3011,'elapsed_seconds':round(time.monotonic()-cohort,3),
                        'weighted_probes':counters['weighted_active_support_probes'],'affine_fresh_D_ge_2_words':counters['affine_D_ge_2_fresh_entire_axis_words']}),flush=True)
        expected_counts={'weighted_fixed_j_rows_checked':41780,'weighted_fixed_count_states':43364036,'weighted_fixed_count_edges':243247406,
            'weighted_active_support_probes':3609,'weighted_forbidden_edge_solver_runs':89216,'affine_D0_D1_exact_inheritance_words':2307,
            'affine_D_ge_2_fresh_entire_axis_words':704,'unit_D_0':1211,'unit_D_1':1096,'unit_D_2':449,'unit_D_3':205,'unit_D_4':23,'unit_D_5':26,'unit_D_6':1}
        for key,value in expected_counts.items():same(counters[key],value,('full fresh count',key))
        snapshot_count=0
        with (output/'all_10246_snapshot_identity_axis_maps.jsonl').open('x',encoding='utf-8',newline='\n') as sfile:
            for s in plan['snapshots']:
                vid=s['variant_id'];ids=s['event_ids'];same(len(ids),len(variants[vid]['word']),'all snapshot position IDs')
                same(len(ids),len(set(ids)),'all opaque IDs unique')
                emit(sfile,{**s,'fresh_weighted_variant_id':vid,'fresh_affine_variant_id':vid,'whole_axis_support_position_to_ID_map':list(enumerate(ids))})
                snapshot_count+=1
        same(snapshot_count,10246,'full snapshot map count')
        aggregate,category_cases=all_pairs(plan,variants,weighted_certificates,affine_certificates,output,counters)
        verify_bundle()
        report={'status':'PASS_FRESH_ORIGINAL_ARC_FULL_3011_WEIGHTED_AND_AFFINE_AXES_ALL_8735_PAIRS_V1',
            'words':3011,'cases':1511,'events':8735,'snapshots':snapshot_count,'restoration_pairs':8735,'normal_last_controls':1511,
            'all_counts':dict(counters),'aggregate':aggregate,'category_case_ids':category_cases,
            'category_case_counts':{k:len(v) for k,v in category_cases.items()},'exact_function_provenance_records_verified':len(manifest['exact_function_provenance']),
            'fresh_optimum_support_reconstructed_not_saved_numerical_reaggregation':True,
            'weighted_entire_positive_axis_complete_cost_and_per_ID_roles':True,'affine_entire_nonnegative_axis_complete_cost_and_per_ID_roles':True,
            'historical_68_fixed_K_LIMITs_preserved':True,'dominated_fixed_K_or_all_active_count_tuple_sets_at_ties_upgraded':False,
            'source_subset_and_original_event_count_independently_rebuilt_from_cases_and_128_case_source':True,
            'guard_contract':read('guard_contract.json'),'observed_platform':{'system':platform.system(),'python_version':platform.python_version()},
            'other_platform_runs_claimed':False,'historical_resource_equivalence_claimed':False,
            'bundle_manifest_sha256':sha((ROOT/'manifest.json').read_bytes()),'all_shipped_bindings_unchanged_before_after':True,
            'native_calls':0,'optimizer_calls':0,'protected_runtime_files_hashed':0,'third_party_imports':0,
            'elapsed_seconds':time.monotonic()-started,'manuscript_or_goal_written':False,'network_operations':0}
        save(output/'report.json',report)
        files=[{'name':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(output.iterdir()) if p.is_file()]
        save(output/'output_manifest.json',{'status':'EXCLUSIVE_COMPLETE_FRESH_AXIS_OUTPUTS','files':files})
        print(json.dumps({'status':report['status'],'words':3011,'pairs':8735,'elapsed_seconds':round(report['elapsed_seconds'],3),'native_calls':0}),flush=True)
    except BaseException:
        save(output/'failure.json',{'status':'FAIL_PRESERVED_NO_PASS_NO_OVERWRITE','traceback':traceback.format_exc(),'native_calls':0});raise

if __name__=='__main__':main()
