"""Independent all-position intervention audit: layered DP and edge bans.

Never imports cost_profiles, weighted_core, or a producer runner. Every fixed
log-count minimum is recalculated by event layers and multi-source model-only
shortest-path closures. All positive-ratio active cells, critical points, pair
equality points and saved policies are checked with the previously independent
forbidden-edge weighted oracle, deduplicated by case, visible identity tuple,
and reduced rational ratio. No explicit logged-identity-mask expansion.
"""
import ast
from collections import Counter, defaultdict, deque
from datetime import datetime, timezone
from fractions import Fraction
import hashlib
import heapq
import json
from pathlib import Path
from time import perf_counter

HERE = Path(__file__).resolve().parent


def load_frozen_oracle_functions():
    """Reuse only frozen independent solver functions, avoiding module imports.

    The old oracle module's normal imports indirectly load unused old production
    module definitions. We neither need nor load those definitions here.
    """
    source = HERE / 'weighted_independent_audit.py'
    required = ['positive_integer', 'build_product', 'dijkstra', 'weighted_oracle']
    source_bytes = source.read_bytes()
    parsed = ast.parse(source_bytes.decode('utf-8'), filename=str(source))
    definitions = {node.name: node for node in parsed.body if isinstance(node, ast.FunctionDef)}
    selected = ast.Module(body=[definitions[name] for name in required], type_ignores=[])
    namespace = {'__builtins__': __builtins__, 'deque': deque, 'heapq': heapq, 'INF': float('inf')}
    exec(compile(selected, str(source), 'exec'), namespace)
    return namespace['weighted_oracle'], hashlib.sha256(source_bytes).hexdigest()


weighted_oracle, ORACLE_SOURCE_SHA256 = load_frozen_oracle_functions()


def own_graph(doc):
    """Rebuild original marking graph directly from input/output arc vectors."""
    transitions = sorted(doc['transitions'], key=lambda t: t['id'])
    initial = tuple(doc['initial'])
    markings = [initial]
    index = {initial: 0}
    pending = deque([0])
    edges = []
    while pending:
        source = pending.popleft()
        marking = markings[source]
        outgoing = []
        for ti, transition in enumerate(transitions):
            if not all(a >= b for a, b in zip(marking, transition['pre'])):
                continue
            target = tuple(a - b + c for a, b, c in
                           zip(marking, transition['pre'], transition['post']))
            if target not in index:
                assert len(markings) < 10000
                index[target] = len(markings)
                markings.append(target)
                pending.append(index[target])
            outgoing.append((ti, index[target]))
        edges.append(outgoing)
    return transitions, {'markings': markings, 'edges': edges}

POLICIES = [(1, 4), (1, 2), (1, 1), (2, 1), (4, 1)]
FIELDS = ['cost', 'possible_log_ids', 'mandatory_log_ids',
          'forced_sync_ids', 'ambiguous_consumption_ids']


def load(name):
    return json.loads((HERE / name).read_text(encoding='utf-8'))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def fraction(value):
    return Fraction(value['numerator'], value['denominator'])


def rdoc(value):
    return {'numerator': value.numerator, 'denominator': value.denominator}


def edge_set(transitions, graph):
    return {(tuple(graph['markings'][u]), transitions[ti]['id'],
             tuple(graph['markings'][v]))
            for u, outgoing in enumerate(graph['edges']) for ti, v in outgoing}


def closure(seeds, model_edges, counts):
    """Independent within-layer closure; no event-consuming edges here."""
    distance = list(seeds)
    queue = [(cost, marking) for marking, cost in enumerate(distance) if cost is not None]
    heapq.heapify(queue)
    while queue:
        cost, source = heapq.heappop(queue)
        if distance[source] != cost:
            continue
        counts['layer_closure_settled_markings'] += 1
        for target, weight in model_edges[source]:
            candidate = cost + weight
            if distance[target] is None or candidate < distance[target]:
                distance[target] = candidate
                heapq.heappush(queue, (candidate, target))
    return distance


def layered_minimum_models(transitions, graph, events, counts):
    """DP(i,j,marking), accepting any marking after the final event."""
    width = len(graph['markings'])
    model_edges = [[(target, int(transitions[ti]['label'] is not None))
                    for ti, target in outgoing] for outgoing in graph['edges']]
    sync_by_label = defaultdict(lambda: [[] for _ in range(width)])
    for source, outgoing in enumerate(graph['edges']):
        for ti, target in outgoing:
            label = transitions[ti]['label']
            if label is not None:
                sync_by_label[label][source].append(target)
    layers = [[None] * width]
    layers[0][0] = 0
    for i in range(len(events) + 1):
        closed = [closure(seeds, model_edges, counts) for seeds in layers]
        counts['layer_closure_jobs'] += len(closed)
        if i == len(events):
            minima = [min((v for v in row if v is not None), default=None) for row in closed]
            counts['layered_profile_jobs'] += 1
            return minima
        following = [[None] * width for _ in range(i + 2)]
        sync_edges = sync_by_label[events[i]['concept']]
        for j, distance in enumerate(closed):
            for marking, cost in enumerate(distance):
                if cost is None:
                    continue
                previous = following[j + 1][marking]
                if previous is None or cost < previous:
                    following[j + 1][marking] = cost
                for target in sync_edges[marking]:
                    previous = following[j][target]
                    if previous is None or cost < previous:
                        following[j][target] = cost
        layers = following
    raise AssertionError('Unreachable DP end')


def active_interval(line, lines):
    """Intersection of affine half-planes for this line to be minimal."""
    j, m = line
    left, right = Fraction(0), None
    for other_j, other_m in lines:
        delta = j - other_j
        if delta == 0:
            if m > other_m:
                return None
            continue
        boundary = Fraction(other_m - m, delta)
        if delta > 0:
            right = boundary if right is None else min(right, boundary)
        else:
            left = max(left, boundary)
    if right is not None and (right <= 0 or right < left):
        return None
    return left, right


def envelope_points(lines):
    points = set()
    for line in lines:
        interval = active_interval(line, lines)
        if interval is None:
            continue
        left, right = interval
        if left > 0:
            points.add(left)
        if right is not None and right > 0:
            points.add(right)
    return sorted(points)


def active_lines(lines, ratio):
    minimum = min(j * ratio + m for j, m in lines)
    return sorted([(j, m) for j, m in lines if j * ratio + m == minimum])


def samples(points):
    bounds = [Fraction(0)] + sorted(points) + [None]
    return [(left, right, (left + right) / 2 if right is not None else left + 1)
            for left, right in zip(bounds, bounds[1:])]


def pair_points(before_lines, after_lines):
    """First partition individual envelopes, then solve equality per cell."""
    individual = sorted(set(envelope_points(before_lines)) | set(envelope_points(after_lines)))
    additions = set()
    for left, right, sample in samples(individual):
        a = active_lines(before_lines, sample)
        b = active_lines(after_lines, sample)
        assert len(a) == len(b) == 1
        ja, ma = a[0]
        jb, mb = b[0]
        if ja != jb:
            equality = Fraction(mb - ma, ja - jb)
            if equality > left and (right is None or equality < right):
                assert equality > 0
                additions.add(equality)
    return sorted(set(individual) | additions), sorted(additions)


def profile_at_saved(profile, ratio):
    feasible = [e for e in profile['entries'] if e['feasible']]
    lcost, mcost = ratio.numerator, ratio.denominator
    optimum = min(lcost * e['log_count'] + mcost * e['model_count'] for e in feasible)
    best = [e for e in feasible if lcost * e['log_count'] + mcost * e['model_count'] == optimum]
    possible = set().union(*(set(e['possible_log_ids']) for e in best))
    mandatory = set(best[0]['mandatory_log_ids'])
    for e in best[1:]:
        mandatory &= set(e['mandatory_log_ids'])
    return {'cost': optimum, 'possible_log_ids': sorted(possible),
            'mandatory_log_ids': sorted(mandatory),
            'forced_sync_ids': sorted(set(profile['event_ids']) - possible),
            'ambiguous_consumption_ids': sorted(possible - mandatory)}


def changes(before, after, common):
    pchange = set(before['possible_log_ids']) & common != set(after['possible_log_ids']) & common
    mchange = set(before['mandatory_log_ids']) & common != set(after['mandatory_log_ids']) & common
    same_cost = before['cost'] == after['cost']
    return {'same_cost': same_cost, 'old_possible_changed': pchange,
            'old_mandatory_changed': mchange,
            'same_cost_old_summary_revision': same_cost and (pchange or mchange)}


def verify_saved_change(actual, expected):
    for name, value in expected.items():
        assert actual[name] == value, (name, actual.get(name), value)


def main():
    started = perf_counter()
    summary_path = HERE / 'bpi2013_position_delay_summary.json'
    if not summary_path.exists():
        raise RuntimeError('Producer summary does not exist; audit did not read partial outputs')
    report = {'status': 'RUNNING', 'started_at_utc': datetime.now(timezone.utc).isoformat(),
              'script_sha256': sha(__file__), 'counts': {},
              'production_analyzers_imported': False, 'PM4Py_imported': False,
              'clinical_inputs_read': False, 'normative_business_violation_claimed': False}
    counts = Counter()
    output = HERE / 'bpi2013_position_delay_audit.json'
    if output.exists():
        previous = load(output.name)
        previous_runs = previous.pop('prior_runs', [])
        previous['superseded_reason'] = 'normal independent-oracle module import indirectly loaded unused old production definitions; final run isolates only frozen solver functions'
        report['prior_runs'] = previous_runs + [previous]
    try:
        producer_frozen = load('bpi2013_position_delay_frozen_inputs.json')
        for name, digest in producer_frozen.items():
            assert sha(HERE / name) == digest, name
        audit_inputs = ['bpi2013_position_delay_results.jsonl', 'bpi2013_position_delay_summary.json',
                        'bpi2013_position_delay_frozen_inputs.json', 'weighted_independent_audit.py',
                        'bpi2013_model_IMf02.json', 'bpi2013_prepared_data.json']
        report['input_sha256'] = {name: sha(HERE / name) for name in audit_inputs}
        assert report['input_sha256']['weighted_independent_audit.py'] == ORACLE_SOURCE_SHA256
        report['forbidden_oracle_loading'] = {
            'method': 'AST selection of four existing frozen independent function definitions only',
            'source_sha256': sha(HERE / 'weighted_independent_audit.py'),
            'selected_functions': ['positive_integer', 'build_product', 'dijkstra', 'weighted_oracle'],
            'module_imports_executed': False,
            'old_production_definitions_loaded': False}
        data, doc = load('bpi2013_prepared_data.json'), load('bpi2013_model_IMf02.json')
        cases = {c['id']: sorted(c['events'], key=lambda e: (e['timestamp_us'], e['xml_index']))
                 for c in data['evaluation_cases']}
        assert len(cases) == 128 and sum(map(len, cases.values())) == 786
        for events in cases.values():
            assert len({e['id'] for e in events}) == len(events)
            assert all(a['timestamp_us'] < b['timestamp_us'] for a, b in zip(events, events[1:]))
        transitions, graph = own_graph(doc['net_doc'])
        assert edge_set(transitions, graph) == edge_set(transitions, doc['graph'])
        counts['independent_markings'] = len(graph['markings'])
        after_rows, intervention_rows = {}, {}
        with (HERE / 'bpi2013_position_delay_results.jsonl').open(encoding='utf-8') as stream:
            for line in stream:
                row = json.loads(line)
                cid = row['case']
                assert cid in cases
                if row['type'] == 'after_profile':
                    assert cid not in after_rows
                    after_rows[cid] = row
                else:
                    assert row['type'] == 'intervention'
                    key = cid, row['delayed_position']
                    assert key not in intervention_rows
                    intervention_rows[key] = row
        assert set(after_rows) == set(cases)
        assert set(intervention_rows) == {(cid, i) for cid, e in cases.items() for i in range(len(e))}
        profiles = {}
        profile_lines = {}
        profile_events = {}
        required_ratios = defaultdict(set)
        for cid, events in cases.items():
            profiles[cid, -1] = after_rows[cid]['profile']
            profile_events[cid, -1] = events
            for position in range(len(events)):
                row = intervention_rows[cid, position]
                assert row['delayed_record_id'] == events[position]['id']
                assert row['original_event_count'] == len(events)
                assert row['normal_last_record_control'] == (position == len(events) - 1)
                profiles[cid, position] = row['before_profile']
                profile_events[cid, position] = events[:position] + events[position + 1:]
                counts['reconstructed_intervention_pairs'] += 1
        for index, (key, profile) in enumerate(profiles.items()):
            events = profile_events[key]
            if profile.get('status') == 'LIMIT':
                counts['LIMIT_profiles_preserved'] += 1
                assert all(k not in profile for k in ['cost', 'entries', 'possible_log_ids', 'mandatory_log_ids'])
                raise RuntimeError('LIMIT preserved without approximate cost; producer complete-scope summary requires review')
            assert profile['status'] == 'EXACT'
            assert profile['acceptance'] == 'prefix_any_marking' and profile['final'] is None
            assert profile['event_ids'] == sorted(e['id'] for e in events)
            assert profile['event_count'] == len(events) and profile['no_evidence'] == (len(events) == 0)
            assert profile['state_limit'] == 100000
            assert len(profile['entries']) == len(events) + 1
            minima = layered_minimum_models(transitions, graph, events, counts)
            assert profile['feasible_log_counts'] == [j for j, minimum in enumerate(minima) if minimum is not None]
            lines = []
            for j, (entry, minimum) in enumerate(zip(profile['entries'], minima)):
                assert entry['log_count'] == j and entry['feasible'] == (minimum is not None)
                assert entry['model_count'] == minimum
                counts['fixed_log_count_minima_checked'] += 1
                if minimum is None:
                    assert all(entry[f] is None for f in FIELDS if f != 'cost')
                    counts['infeasible_log_counts'] += 1
                else:
                    lines.append((j, minimum))
                    possible = set(entry['possible_log_ids'])
                    mandatory = set(entry['mandatory_log_ids'])
                    ids = {e['id'] for e in events}
                    assert entry['possible_log_ids'] == sorted(possible)
                    assert entry['mandatory_log_ids'] == sorted(mandatory)
                    assert mandatory <= possible <= ids
                    assert entry['forced_sync_ids'] == sorted(ids - possible)
                    assert entry['ambiguous_consumption_ids'] == sorted(possible - mandatory)
                    assert len(mandatory) <= j <= len(possible)
            profile_lines[key] = lines
            points = envelope_points(lines)
            required_ratios[key] |= set(points)
            required_ratios[key] |= {sample for left, right, sample in samples(points)}
            required_ratios[key] |= {Fraction(l, m) for l, m in POLICIES}
            if (index + 1) % 128 == 0:
                print(json.dumps({'stage': 'layered_profile_minima', 'profiles': index + 1}), flush=True)
        for key, row in intervention_rows.items():
            cid, position = key
            points, additions = pair_points(profile_lines[key], profile_lines[cid, -1])
            assert [fraction(p) for p in row['partition_points']] == points
            for ratio in points + [sample for left, right, sample in samples(points)]:
                required_ratios[key].add(ratio)
                required_ratios[cid, -1].add(ratio)
            counts['cross_profile_equality_points_not_individual_breakpoints'] += len(additions)
        oracle_cache = {}
        for index, key in enumerate(profiles):
            cid, position = key
            events = profile_events[key]
            ids_tuple = tuple(e['id'] for e in events)
            predecessor = [(1 << i) - 1 for i in range(len(events))]
            for ratio in sorted(required_ratios[key]):
                cache_key = cid, ids_tuple, ratio
                if cache_key not in oracle_cache:
                    answer = weighted_oracle(transitions, graph, events, predecessor,
                                             ratio.numerator, ratio.denominator, None)
                    oracle_cache[cache_key] = answer
                    counts['fresh_forbidden_edge_summary_jobs'] += 1
                    counts['forbidden_edge_dijkstra_runs'] += answer['restricted_solver_runs']
                    counts['summary_product_states'] += answer['product_states']
                else:
                    counts['duplicate_requested_oracle_jobs_reused'] += 1
                expected = oracle_cache[cache_key]
                actual = profile_at_saved(profiles[key], ratio)
                for field in FIELDS:
                    assert actual[field] == expected[field], (key, str(ratio), field)
                counts['profile_at_ratio_support_matches'] += 1
            if (index + 1) % 64 == 0:
                print(json.dumps({'stage': 'all_active_supports', 'profiles': index + 1,
                                  'oracle_jobs': counts['fresh_forbidden_edge_summary_jobs']}), flush=True)

        def answer_at(key, ratio):
            cid, _ = key
            ids = tuple(e['id'] for e in profile_events[key])
            return oracle_cache[cid, ids, ratio]

        reconstructed_counts = Counter(after_profiles=len(after_rows), before_profiles=len(intervention_rows),
                                       native_after_policy_matches=128 * 3,
                                       weighted_before_policy_matches=len(intervention_rows) * 5)
        policy_counts = {f'{l}/{m}': Counter() for l, m in POLICIES}
        case_sets = {'any_open_interval_revision': set(), 'any_isolated_point_revision': set()}
        control_counts = defaultdict(Counter)
        strata_counts = defaultdict(Counter)
        interval_cases, isolated_only_cases = [], []
        for key, row in intervention_rows.items():
            cid, position = key
            after_key = cid, -1
            common = {e['id'] for e in profile_events[key]}
            assert len(row['policies']) == len(POLICIES)
            for item, (l, m) in zip(row['policies'], POLICIES):
                ratio = Fraction(l, m)
                assert (item['log_cost'], item['model_cost']) == (l, m)
                a, b = answer_at(key, ratio), answer_at(after_key, ratio)
                for field in FIELDS:
                    assert item['before'][field] == a[field] and item['after'][field] == b[field]
                assert item['before']['optimal_log_counts'] == [j for j, mvalue in active_lines(profile_lines[key], ratio)]
                assert item['after']['optimal_log_counts'] == [j for j, mvalue in active_lines(profile_lines[after_key], ratio)]
                expected = changes(a, b, common)
                verify_saved_change(item, expected)
                assert fraction(item['normalized_before_cost']) == Fraction(a['cost'], m)
                assert fraction(item['normalized_after_cost']) == Fraction(b['cost'], m)
                pc = policy_counts[f'{l}/{m}']
                pc['interventions'] += 1
                for metric in ['same_cost_old_summary_revision', 'old_possible_changed', 'old_mandatory_changed']:
                    pc[metric] += expected[metric]
                pc['before_positive_cost'] += int(a['cost'] > 0)
                control = 'last_record_normal_extension' if row['normal_last_record_control'] else 'earlier_record_delayed'
                control_counts[f'{l}/{m}|{control}']['pairs'] += 1
                control_counts[f'{l}/{m}|{control}']['same_cost_old_summary_revision'] += expected['same_cost_old_summary_revision']
                strata = 'before_positive' if a['cost'] > 0 else 'before_zero'
                strata_counts[f'{l}/{m}|{strata}']['pairs'] += 1
                strata_counts[f'{l}/{m}|{strata}']['same_cost_old_summary_revision'] += expected['same_cost_old_summary_revision']
                if a['cost'] == 0:
                    assert not expected['same_cost_old_summary_revision']
                counts['saved_policy_pairs_independently_checked'] += 1
            points, _ = pair_points(profile_lines[key], profile_lines[after_key])
            open_cells = samples(points)
            assert len(row['parameter_cells']) == len(open_cells) + len(points)
            open_revisions = point_revisions = 0
            for saved, (left, right, sample) in zip(row['parameter_cells'], open_cells):
                assert saved['kind'] == 'open_interval'
                assert fraction(saved['left']) == left
                assert (None if saved['right'] is None else fraction(saved['right'])) == right
                assert fraction(saved['sample']) == sample
                a, b = answer_at(key, sample), answer_at(after_key, sample)
                expected = changes(a, b, common)
                aa, bb = active_lines(profile_lines[key], sample), active_lines(profile_lines[after_key], sample)
                assert saved['before_active_lines'] == [list(v) for v in aa]
                assert saved['after_active_lines'] == [list(v) for v in bb]
                assert saved['normalized_before_cost'] is None and saved['normalized_after_cost'] is None
                verify_saved_change(saved, expected)
                if expected['same_cost']:
                    assert aa == bb, (key, 'equal interior values must be identical affine lines')
                open_revisions += expected['same_cost_old_summary_revision']
                counts['open_interval_cells_independently_checked'] += 1
            for saved, point in zip(row['parameter_cells'][len(open_cells):], points):
                assert saved['kind'] == 'point' and fraction(saved['ratio']) == point
                expected = changes(answer_at(key, point), answer_at(after_key, point), common)
                verify_saved_change(saved, expected)
                assert saved['normalized_before_cost'] is None and saved['normalized_after_cost'] is None
                point_revisions += expected['same_cost_old_summary_revision']
                counts['point_cells_independently_checked'] += 1
            reconstructed_counts['intervention_pairs'] += 1
            reconstructed_counts['pairs_with_open_interval_revision'] += int(open_revisions > 0)
            reconstructed_counts['pairs_with_point_revision'] += int(point_revisions > 0)
            reconstructed_counts['pairs_with_isolated_only_revision'] += int(point_revisions > 0 and open_revisions == 0)
            if open_revisions:
                case_sets['any_open_interval_revision'].add(cid)
                interval_cases.append({'case': cid, 'delayed_position': position,
                                       'delayed_record_id': row['delayed_record_id']})
            if point_revisions:
                case_sets['any_isolated_point_revision'].add(cid)
            if point_revisions and not open_revisions:
                isolated_only_cases.append({'case': cid, 'delayed_position': position,
                                            'delayed_record_id': row['delayed_record_id']})
        summary = load('bpi2013_position_delay_summary.json')
        assert summary['status'] == 'PRODUCER_COMPLETE_PENDING_INDEPENDENT_AUDIT'
        assert summary['counts'] == dict(reconstructed_counts)
        assert summary['policies'] == {k: dict(v) for k, v in policy_counts.items()}
        assert summary['case_counts'] == {k: len(v) for k, v in case_sets.items()}
        assert summary['case_ids'] == {k: sorted(v) for k, v in case_sets.items()}
        assert summary['intervention_is_simulated'] is True
        assert summary['clinical_inputs_read'] is False and summary['violation_truth_claimed'] is False
        for name, digest in producer_frozen.items():
            assert sha(HERE / name) == digest, name
        for name, digest in report['input_sha256'].items():
            assert sha(HERE / name) == digest, name
        report.update(status='PASS', counts=dict(counts), recomputed_producer_counts=dict(reconstructed_counts),
                      recomputed_policy_counts={k: dict(v) for k, v in policy_counts.items()},
                      recomputed_case_counts={k: len(v) for k, v in case_sets.items()},
                      normal_extension_control_counts={k: dict(v) for k, v in control_counts.items()},
                      positive_cost_strata_counts={k: dict(v) for k, v in strata_counts.items()},
                      open_interval_revision_pairs=interval_cases,
                      isolated_only_revision_pairs=isolated_only_cases,
                      source_hashes_unchanged=True, reused_prior_native_support_checks=0,
                      scope={'all_interventions_reconstructed': 786, 'all_profile_cost_entries': 914,
                             'all_positive_ratios': 'each active breakpoint and open interval, plus cross-profile equality partition and all five policies',
                             'inactive_fixed_log_count_ID_sets': 'contract checked; not separately forbidden-edge checked',
                             'source_XES_split_reconstruction': 'not included; frozen prepared identities and timestamps are the input contract',
                             'isolated_point_case_label': 'producer any_isolated_point_revision denotes any point revision, including pairs also persistent on intervals; isolated-only pairs counted separately'})
    except Exception as exc:
        report.update(status='FAIL', counts=dict(counts), error_type=type(exc).__name__, error=str(exc))
        raise
    finally:
        report['elapsed_seconds'] = perf_counter() - started
        report['completed_at_utc'] = datetime.now(timezone.utc).isoformat()
        with output.open('w', encoding='utf-8') as stream:
            json.dump(report, stream, ensure_ascii=False, indent=2)
            stream.write('\n')
        print(json.dumps({'status': report['status'], 'counts': report['counts'],
                          'elapsed_seconds': report['elapsed_seconds']}), flush=True)


if __name__ == '__main__':
    main()
