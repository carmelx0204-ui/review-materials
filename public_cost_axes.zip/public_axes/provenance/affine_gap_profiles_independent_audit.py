"""Integer original-product audit of all affine gap-ratio profiles.

No anchor reduction, producer, scalar gap solver, Petri container or PM4Py
implementation is imported. Distances count original log/visible model steps.
All fixed-K role supports are checked, a stronger scope than active cells alone.
"""
from collections import Counter, deque
from fractions import Fraction
import hashlib
from itertools import combinations
import json
from pathlib import Path
import sys
from time import perf_counter

HERE = Path(__file__).resolve().parent
MODEL_LIMIT = 10000
PRODUCT_LIMIT = 100000
ROLE_FIELDS = ("possible_log_positions", "possible_sync_positions", "mandatory_log_positions",
               "forced_sync_positions", "ambiguous_positions")


def load(name):
    return json.loads((HERE / name).read_text(encoding="utf-8"))


def sha(path):
    answer = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(4 * 1024 * 1024), b""):
            answer.update(block)
    return answer.hexdigest()


def original_graph(doc):
    initial = tuple(doc["initial"])
    marks, index, rows = [initial], {initial: 0}, []
    queue = deque([0])
    while queue:
        u = queue.popleft()
        outgoing = []
        for transition in doc["transitions"]:
            if any(have < need for have, need in zip(marks[u], transition["pre"])):
                continue
            successor = tuple(have - need + give for have, need, give in zip(marks[u], transition["pre"], transition["post"]))
            if successor not in index:
                if len(marks) >= MODEL_LIMIT:
                    return {"status": "LIMIT_ORIGINAL_MARKINGS", "reached_markings": len(marks)}
                index[successor] = len(marks)
                marks.append(successor)
                queue.append(index[successor])
            outgoing.append((index[successor], transition["label"]))
        rows.append(outgoing)
    return {"status": "COMPLETE_ORIGINAL_GRAPH", "markings": marks, "index": index, "edges": rows}


def zero_one(adjacency, roots):
    distance = [None] * len(adjacency)
    queue = deque()
    for root in roots:
        distance[root] = 0
        queue.append(root)
    while queue:
        u = queue.popleft()
        cost = distance[u]
        for edge in adjacency[u]:
            v, weight = edge[:2]
            candidate = cost + weight
            if distance[v] is None or candidate < distance[v]:
                distance[v] = candidate
                if weight:
                    queue.append(v)
                else:
                    queue.appendleft(v)
    return distance


def product_graph(g, final, word):
    # K counts closed nonempty gaps. `opened` records whether the current gap
    # contains any original log or visible-model step. Tau never changes it.
    states, index, edges, reverse = [(0, 0, 0, False)], {(0, 0, 0, False): 0}, [], [[]]
    queue = deque([0])
    while queue:
        u = queue.popleft()
        i, marking, closed_k, opened = states[u]
        assert closed_k <= i
        moves = []
        if i < len(word):
            moves.append(((i + 1, marking, closed_k, True), 1, i + 1))
        for next_marking, label in g["edges"][marking]:
            moves.append(((i, next_marking, closed_k, opened or label is not None), int(label is not None), 0))
            if i < len(word) and label == word[i]:
                moves.append(((i + 1, next_marking, closed_k + int(opened), False), 0, -(i + 1)))
        row = []
        for successor, weight, role in moves:
            if successor not in index:
                if len(states) >= PRODUCT_LIMIT:
                    return {"status": "LIMIT_ORIGINAL_PRODUCT", "reached_product_states": len(states)}
                index[successor] = len(states)
                states.append(successor)
                reverse.append([])
                queue.append(index[successor])
            v = index[successor]
            row.append((v, weight, role))
            reverse[v].append((u, weight))
        edges.append(row)
    distance = zero_one(edges, [0])
    target_marking = g["index"][tuple(final)]
    endpoints = {}
    for u, (i, marking, closed_k, opened) in enumerate(states):
        if i == len(word) and marking == target_marking:
            gap_count = closed_k + int(opened)
            assert 0 <= gap_count <= len(word) + 1
            endpoints.setdefault(gap_count, []).append(u)
    minima = {k: min(distance[u] for u in terminals) for k, terminals in endpoints.items()}
    return {"status": "COMPLETE_ORIGINAL_PRODUCT", "states": states, "edges": edges, "reverse": reverse,
            "distance": distance, "endpoints": endpoints, "minima": minima}


def role_fields(logged, synced, size):
    universe = set(range(size))
    return {"possible_log_positions": sorted(logged), "possible_sync_positions": sorted(synced),
            "mandatory_log_positions": sorted(universe - synced), "forced_sync_positions": sorted(universe - logged),
            "ambiguous_positions": sorted(logged & synced)}


def fixed_profile(product, size):
    entries = []
    edge_checks = 0
    for k, optimum in sorted(product["minima"].items()):
        backward = zero_one(product["reverse"], product["endpoints"][k])
        logged, synced = set(), set()
        for u, row in enumerate(product["edges"]):
            if backward[u] is None or product["distance"][u] + backward[u] != optimum:
                continue
            for v, weight, role in row:
                edge_checks += 1
                if role and backward[v] is not None and product["distance"][u] + weight + backward[v] == optimum:
                    (logged if role > 0 else synced).add(abs(role) - 1)
        assert logged | synced == set(range(size))
        entries.append({"gap_count": k, "minimum_total_deviations": optimum, **role_fields(logged, synced, size)})
    return entries, edge_checks


def fraction_doc(value):
    return {"numerator": value.numerator, "denominator": value.denominator}


def fraction_value(value):
    return Fraction(value["numerator"], value["denominator"])


def evaluate(entries, ratio, size):
    optimum = min(Fraction(row["minimum_total_deviations"]) + ratio * row["gap_count"] for row in entries)
    active = [row for row in entries if row["minimum_total_deviations"] + ratio * row["gap_count"] == optimum]
    logged = set().union(*(set(row["possible_log_positions"]) for row in active))
    synced = set().union(*(set(row["possible_sync_positions"]) for row in active))
    return {"normalized_cost": fraction_doc(optimum), "active_counts": [[row["gap_count"], row["minimum_total_deviations"]] for row in active],
            **role_fields(logged, synced, size)}


def partition(entries, size):
    candidates = set()
    for a, b in combinations(entries, 2):
        point = Fraction(b["minimum_total_deviations"] - a["minimum_total_deviations"], a["gap_count"] - b["gap_count"])
        if point > 0:
            candidates.add(point)
    critical = sorted(point for point in candidates if len(evaluate(entries, point, size)["active_counts"]) > 1)
    cells = []
    left = Fraction(0)
    for right in critical + [None]:
        probe = left + 1 if right is None else (left + right) / 2
        cells.append({"kind": "open_interval", "left": fraction_doc(left), "right": None if right is None else fraction_doc(right),
                      "probe": fraction_doc(probe), "result": evaluate(entries, probe, size)})
        if right is not None:
            cells.append({"kind": "point", "ratio": fraction_doc(right), "result": evaluate(entries, right, size)})
            left = right
    return {"classic_boundary": evaluate(entries, Fraction(0), size), "default_affine": evaluate(entries, Fraction(2), size),
            "critical_positive_ratios": [fraction_doc(point) for point in critical], "positive_cells": cells}


def raw_move_paths(doc, final, word):
    g = original_graph(doc)
    assert g["status"] == "COMPLETE_ORIGINAL_GRAPH"
    active, complete = set(), set()
    def check_acyclic(u):
        assert u not in active
        if u in complete:
            return
        active.add(u)
        for v, _ in g["edges"][u]:
            check_acyclic(v)
        active.remove(u)
        complete.add(u)
    check_acyclic(0)
    target = g["index"][tuple(final)]
    answers = []
    def visit(i, marking, closed_k, opened, deviations, log_mask):
        if i == len(word) and marking == target:
            answers.append((closed_k + int(opened), deviations, log_mask))
        if i < len(word):
            visit(i + 1, marking, closed_k, True, deviations + 1, log_mask | (1 << i))
        for v, label in g["edges"][marking]:
            if label is None:
                visit(i, v, closed_k, opened, deviations, log_mask)
            else:
                visit(i, v, closed_k, True, deviations + 1, log_mask)
                if i < len(word) and label == word[i]:
                    visit(i + 1, v, closed_k + int(opened), False, deviations, log_mask)
    visit(0, 0, 0, False, 0, 0)
    return answers, g


def raw_profile(paths, size):
    minima = {}
    masks = {}
    for k, d, mask in paths:
        if k not in minima or d < minima[k]:
            minima[k], masks[k] = d, [mask]
        elif d == minima[k]:
            masks[k].append(mask)
    result = []
    for k, d in sorted(minima.items()):
        possible, mandatory = 0, (1 << size) - 1
        for mask in masks[k]:
            possible |= mask
            mandatory &= mask
        logged = {i for i in range(size) if possible >> i & 1}
        synced = {i for i in range(size) if not mandatory >> i & 1}
        result.append({"gap_count": k, "minimum_total_deviations": d, **role_fields(logged, synced, size)})
    return result


def check_partition(actual, expected):
    # Costs at reported rational probes are checked even if a producer uses a
    # different valid interior probe for the same exact interval.
    assert actual["critical_positive_ratios"] == expected["critical_positive_ratios"]
    for boundary in ("classic_boundary", "default_affine"):
        assert actual[boundary] == expected[boundary], (boundary, actual[boundary], expected[boundary])
    assert len(actual["positive_cells"]) == len(expected["positive_cells"])
    for a, b in zip(actual["positive_cells"], expected["positive_cells"]):
        assert a["kind"] == b["kind"]
        if a["kind"] == "open_interval":
            assert a["left"] == b["left"] and a["right"] == b["right"]
        else:
            assert a["ratio"] == b["ratio"]
        assert a == b, (a, b)


def audit_calibration(counts):
    calibration = load("affine_gap_profiles_calibration.json")
    certificates = []
    for ordinal, row in enumerate(calibration["rows"]):
        if row["kind"] == "acyclic_raw_paths":
            paths, g = raw_move_paths(row["net_doc"], row["final"], row["word"])
            assert len(paths) == row["paths"]
            p = product_graph(g, row["final"], row["word"])
            assert p["status"] == "COMPLETE_ORIGINAL_PRODUCT"
            entries, _ = fixed_profile(p, len(row["word"]))
            assert entries == raw_profile(paths, len(row["word"])) == row["profile"]["entries"]
            check_partition(row["partition"], partition(entries, len(row["word"])))
            counts["acyclic_inputs"] += 1
            counts["original_move_paths_enumerated"] += len(paths)
            counts["acyclic_fixed_K_all_role_checks"] += len(entries)
        elif row["kind"] == "visible_self_loop_analytic":
            g = original_graph(row["net_doc"])
            p = product_graph(g, row["final"], row["word"])
            entries, _ = fixed_profile(p, len(row["word"]))
            assert [(r["gap_count"], r["minimum_total_deviations"]) for r in entries] == [(0, 0), (1, 1)]
            assert all(r["possible_log_positions"] == [] and r["forced_sync_positions"] == [0, 1] for r in entries)
            assert entries == row["profile"]["entries"]
            counts["visible_self_loop_analytic_inputs"] += 1
        else:
            raise AssertionError(row["kind"])
        certificates.append({"input_index": ordinal, "kind": row["kind"], "original_product_states": len(p["states"]),
                             "fixed_K_minima_and_all_role_sets": entries, "status": "PASS"})
    assert counts["acyclic_inputs"] == 171 and counts["original_move_paths_enumerated"] == 2703
    assert counts["visible_self_loop_analytic_inputs"] == 1
    return certificates


def main():
    started = perf_counter()
    assert (HERE / "affine_gap_profiles_summary.json").exists()
    assert not any(name.startswith("pm4py") or name in ("affine_gap_profiles", "gap_objective_oracle", "gap_support", "petri_core", "revision_core", "weighted_core") for name in sys.modules)
    protocol = (HERE / "affine_gap_profiles_protocol.md").read_text(encoding="utf-8")
    assert "positive-visible" in protocol and "100000" in protocol and "640" in protocol
    frozen = load("affine_gap_profiles_frozen_inputs.json")["sha256"]
    names = set(frozen) | {"affine_gap_profiles_frozen_inputs.json", "affine_gap_profiles_calibration.json", "affine_gap_profiles_results.jsonl",
                           "affine_gap_profiles_summary.json", "gap_author_core_v2_case_results.jsonl", "bpi_clock_results.jsonl", "bpi2013_native_results.jsonl"}
    before = {name: sha(HERE / name) for name in sorted(names)}
    assert all(before[name] == digest for name, digest in frozen.items())
    counts = Counter()
    calibration = audit_calibration(counts)
    docs = {"BPI2012": load("bpi_reference_models.json")["IMf02"], "BPI2013": load("bpi2013_model_IMf02.json")}
    prepared = {"BPI2012": load("bpi_prepared_data.json"), "BPI2013": load("bpi2013_prepared_data.json")}
    cases = {dataset: {row["id"]: row for row in d["evaluation_cases"]} for dataset, d in prepared.items()}
    graphs = {dataset: original_graph(row["net_doc"]) for dataset, row in docs.items()}
    for dataset, g in graphs.items():
        assert g["status"] == "COMPLETE_ORIGINAL_GRAPH"
        assert set(g["markings"]) == set(map(tuple, docs[dataset]["graph"]["markings"]))
        model = docs[dataset]
        captured = {(tuple(model["graph"]["markings"][u]), model["net_doc"]["transitions"][ti]["label"], tuple(model["graph"]["markings"][v]))
                    for u, row in enumerate(model["graph"]["edges"]) for ti, v in row}
        rebuilt = {(g["markings"][u], label, g["markings"][v]) for u, row in enumerate(g["edges"]) for v, label in row}
        assert captured == rebuilt
    old_support = {(r["dataset"], r["case_id"]): r for r in map(json.loads, (HERE / "gap_support_results.jsonl").read_text(encoding="utf-8").splitlines())}
    author = {(r["dataset"], r["case_id"]): r for r in map(json.loads, (HERE / "gap_author_core_v2_case_results.jsonl").read_text(encoding="utf-8").splitlines())}
    old_classic = {}
    with (HERE / "bpi_clock_results.jsonl").open(encoding="utf-8") as handle:
        for text in handle:
            row = json.loads(text)
            if row["model"] == "IMf02" and row["granularity"] == "original_us" and row["order"] == "timestamp_xml" and row["acceptance"] == "completed":
                old_classic["BPI2012", row["case"]] = row["result"]
    with (HERE / "bpi2013_native_results.jsonl").open(encoding="utf-8") as handle:
        for text in handle:
            row = json.loads(text)
            if row["acceptance"] == "completed" and row["log_cost"] == row["model_cost"] == 1:
                old_classic["BPI2013", row["case"]] = row["exact"]

    seen, cache, results, sensitive = set(), {}, [], []
    aggregate, datasets, author_statuses = Counter(), {dataset: Counter() for dataset in docs}, Counter()
    with (HERE / "affine_gap_profiles_results.jsonl").open(encoding="utf-8") as handle:
        for ordinal, text in enumerate(handle, 1):
            row = json.loads(text)
            dataset, cid = row["dataset"], row["case_id"]
            case_key = dataset, cid
            assert cid in cases[dataset] and case_key not in seen
            seen.add(case_key)
            events = sorted(cases[dataset][cid]["events"], key=lambda e: (e["timestamp_us"], e["xml_index"]))
            ids, word = [e["id"] for e in events], [e["concept"] for e in events]
            assert row["event_ids"] == ids and row["word"] == word
            assert row["model"] == "IMf02" and row["acceptance"] == "completed"
            assert row["author_status"] == author[case_key]["status"] == old_support[case_key]["author_status"]
            author_statuses[row["author_status"]] += 1
            word_key = dataset, tuple(word)
            if word_key not in cache:
                p = product_graph(graphs[dataset], docs[dataset]["final"], word)
                assert p["status"] == "COMPLETE_ORIGINAL_PRODUCT", p
                entries, optimal_edge_checks = fixed_profile(p, len(word))
                regions = partition(entries, len(word))
                cache[word_key] = entries, regions
                results.append({"dataset": dataset, "word": word, "status": "COMPLETE_ALL_FIXED_K_MINIMA_AND_ROLE_SUPPORTS",
                                "original_product_states": len(p["states"]), "original_product_edges": sum(map(len, p["edges"])),
                                "fixed_K_entries": entries, "partition": regions})
                counts["distinct_real_words"] += 1
                counts["real_fixed_K_minimum_and_full_support_checks"] += len(entries)
                counts["reverse_0_1_searches"] += len(entries)
                counts["real_original_product_states"] += len(p["states"])
                counts["real_original_product_edges"] += sum(map(len, p["edges"]))
                counts["optimal_prefix_edge_membership_checks"] += optimal_edge_checks
                aggregate["distinct_words"] += 1
                datasets[dataset]["distinct_words"] += 1
                print(json.dumps({"stage": "original_product_profile", "distinct_words": len(cache), "case_rows": ordinal,
                                  "states": len(p["states"]), "fixed_K": len(entries), "seconds": round(perf_counter() - started, 2)}), flush=True)
                del p
            entries, regions = cache[word_key]
            assert row["profile"]["status"] == "EXACT_FIXED_GAP_COUNT_PROFILE"
            assert row["profile"]["entries"] == entries
            assert row["profile"]["event_count"] == len(word) and row["profile"]["state_limit"] == PRODUCT_LIMIT
            assert row["profile"]["reachable_markings"] == len(graphs[dataset]["markings"])
            assert row["profile"]["expanded_anchor_states"] <= PRODUCT_LIMIT
            check_partition(row["partition"], regions)
            for name, objective, scale in [("classic_boundary", "classic", 1), ("default_affine", "affine", 2)]:
                actual = regions[name]
                previous = old_support[case_key]["support"]["objectives"][objective]
                assert previous["support_claimed"]
                assert fraction_value(actual["normalized_cost"]) == Fraction(previous["cost_decimal"]) * scale
                for field in ROLE_FIELDS:
                    assert actual[field] == previous[field]
                if name == "classic_boundary":
                    assert fraction_value(actual["normalized_cost"]) == old_classic[case_key]["cost"]
                    assert sorted(ids[i] for i in actual["possible_log_positions"]) == old_classic[case_key]["possible_log_ids"]
                    assert sorted(ids[i] for i in actual["mandatory_log_positions"]) == old_classic[case_key]["mandatory_log_ids"]
            signatures = {(tuple(c["result"]["possible_log_positions"]), tuple(c["result"]["mandatory_log_positions"])) for c in regions["positive_cells"]}
            classic_signature = tuple(regions["classic_boundary"]["possible_log_positions"]), tuple(regions["classic_boundary"]["mandatory_log_positions"])
            values = {"EXACT_FIXED_GAP_COUNT_PROFILE": 1, "classic_boundary_matches": 1, "default_affine_matches": 1,
                      "cases_with_positive_breakpoints": int(bool(regions["critical_positive_ratios"])),
                      "positive_axis_identity_sensitive_cases": int(len(signatures) > 1),
                      "any_positive_rho_roles_differ_from_classic_cases": int(any(s != classic_signature for s in signatures)),
                      "fixed_cases_accounted": 1}
            aggregate.update(values)
            datasets[dataset].update(values)
            counts["logical_case_full_fixed_K_support_checks"] += len(entries)
            counts["logical_case_positive_cell_support_checks"] += len(regions["positive_cells"])
            if values["any_positive_rho_roles_differ_from_classic_cases"]:
                sensitive.append({"dataset": dataset, "case_id": cid, "event_ids": ids,
                                  "positive_breakpoints": regions["critical_positive_ratios"], "partition": regions})
    assert seen == {(dataset, cid) for dataset, rows in cases.items() for cid in rows}
    assert len(seen) == 640 and len(cache) == 74
    assert dict(aggregate) == load("affine_gap_profiles_summary.json")["counts"]
    assert {dataset: dict(values) for dataset, values in datasets.items()} == load("affine_gap_profiles_summary.json")["datasets"]
    assert before == {name: sha(HERE / name) for name in sorted(names)}
    report = {"status": "PASS_ALL_FIXED_K_COSTS_AND_ALL_FIXED_K_ROLE_SUPPORTS", "client_date": "2026-10-04",
              "counts": dict(counts), "aggregate_recomputed": dict(aggregate), "datasets_recomputed": {d: dict(c) for d, c in datasets.items()},
              "author_statuses_preserved": dict(author_statuses), "arithmetic": "Integer step distances and exact Fraction lower envelopes; no numerical comparisons",
              "independent_state": ["event_position", "original_marking", "closed_nonempty_gaps", "open_nonempty_gap_boolean"],
              "support_method": "An original log/sync edge is possible at fixed K iff forward_D[u]+edge_D+reverse_D_K[v]=minimum_D_K; mandatory log is the complement of possible sync. All fixed-K supports were audited, including rho>=0-dominated lines.",
              "limits": {"original_markings": MODEL_LIMIT, "actually_reached_original_product_states": PRODUCT_LIMIT,
                         "producer_anchor_and_independent_product_state_counts_are_different_representations": True,
                         "unsupported_real_inputs": [], "producer_LIMIT_or_UNKNOWN_reclassified": False},
              "calibration": calibration, "distinct_real_word_certificates": results, "positive_axis_sensitive_case_expansion": sensitive,
              "input_sha256": before, "script_sha256": sha(Path(__file__)), "all_inputs_unchanged": True,
              "producer_or_scalar_solver_imported": False, "production_Petri_container_imported": False,
              "business_truth_or_runtime_superiority_claimed": False, "seconds_diagnostic_not_performance_claim": perf_counter() - started}
    with (HERE / "affine_gap_profiles_independent_audit.json").open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(report, handle, ensure_ascii=False, indent=2)
        handle.write("\n")
    print(json.dumps({"status": report["status"], "counts": report["counts"], "aggregate": report["aggregate_recomputed"],
                      "json_sha256": sha(HERE / "affine_gap_profiles_independent_audit.json"), "script_sha256": report["script_sha256"]}), flush=True)


if __name__ == "__main__":
    main()
