"""Independent positive-integer move-cost audit; never imports production code.

API: weighted_oracle(transitions, graph, events, pred, log_cost, model_cost,
                     final=None, all_markings=False)
     analyze_document(net_doc, events, order, log_cost, model_cost, final=None)
CLI: python -B weighted_independent_audit.py [--self-test] [--results PATH]
     [--family PATH] [--frozen PATH] [--output PATH]

Result schema: policies=[{id,log_cost,model_cost}], records use old R1 metadata
plus policy=id (inline log_cost/model_cost also accepted). Family schema:
families=[{k,net,final,events,rows:[{log_cost,model_cost,prefix,completed}]}].
"""
from __future__ import annotations
import argparse
from collections import Counter,deque
from datetime import datetime,timezone
import hashlib
import heapq
import json
import os
from pathlib import Path
import sys
from time import perf_counter

HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
INF=float('inf')
sys.path.insert(0,str(ROOT/'petri_discovery_baseline_v1'))
from independent_discovery_audit import own_graph


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def load(path):return json.loads(Path(path).read_text(encoding='utf-8'))


def positive_integer(value,name):
    if type(value) is not int or value<=0:raise ValueError(name+' must be a positive integer')
    return value


def predecessors(events,order):
    if len({e['id'] for e in events})!=len(events):raise ValueError('Record IDs must be distinct')
    if order=='occurrence_partial':
        return [sum(1<<j for j,f in enumerate(events) if f['occurrence_seconds']<e['occurrence_seconds']) for e in events]
    if order not in ['occurrence','availability']:raise ValueError('Unknown order contract')
    clock=order+'_seconds'
    ordering=sorted(range(len(events)),key=lambda i:(events[i][clock],events[i]['concept'],events[i]['id']))
    masks=[0]*len(events)
    for pos,index in enumerate(ordering):masks[index]=sum(1<<j for j in ordering[:pos])
    return masks


def build_product(transitions,graph,events,pred,log_cost,model_cost):
    if len(pred)!=len(events):raise ValueError('Predecessor count mismatch')
    states=[(0,0)];index={(0,0):0};work=deque([0]);adj=[]
    while work:
        u=work.popleft();mask,mi=states[u];moves=[]
        for i,e in enumerate(events):
            if mask>>i&1 or pred[i]&mask!=pred[i]:continue
            moves.append(((mask|1<<i,mi),log_cost,'log',e['id']))
            for ti,v in graph['edges'][mi]:
                if transitions[ti]['label'] is not None and transitions[ti]['label']==e['concept']:
                    moves.append(((mask|1<<i,v),0,'sync',e['id']))
        for ti,v in graph['edges'][mi]:
            label=transitions[ti]['label'];moves.append(((mask,v),model_cost if label is not None else 0,
                                                      'model' if label is not None else 'silent',None))
        edges=[]
        for state,weight,kind,eid in moves:
            if state not in index:index[state]=len(states);states.append(state);work.append(index[state])
            edges.append((index[state],weight,kind,eid))
        adj.append(edges)
    return states,adj


def dijkstra(adj,seeds,forbidden=None):
    distance=[INF]*len(adj);queue=[]
    for u in seeds:distance[u]=0;heapq.heappush(queue,(0,u))
    while queue:
        cost,u=heapq.heappop(queue)
        if distance[u]!=cost:continue
        for v,w,kind,eid in adj[u]:
            if forbidden is not None and (kind,eid)==forbidden:continue
            candidate=cost+w
            if candidate<distance[v]:distance[v]=candidate;heapq.heappush(queue,(candidate,v))
    return distance


def weighted_oracle(transitions,graph,events,pred,log_cost,model_cost,final=None,all_markings=False):
    log_cost=positive_integer(log_cost,'log_cost');model_cost=positive_integer(model_cost,'model_cost')
    if len({e['id'] for e in events})!=len(events):raise ValueError('Duplicate identity')
    states,adj=build_product(transitions,graph,events,pred,log_cost,model_cost)
    full=(1<<len(events))-1
    targets=[u for u,(mask,mi) in enumerate(states) if mask==full and
             (final is None or tuple(graph['markings'][mi])==tuple(final))]
    if not targets:raise ValueError('No accepting product state')
    forward=dijkstra(adj,[0]);optimum=min(forward[u] for u in targets)
    if optimum==INF:raise ValueError('No finite accepted alignment')
    possible=set();mandatory=set();restricted={}
    for e in events:
        eid=e['id'];force_log=dijkstra(adj,[0],('sync',eid));force_sync=dijkstra(adj,[0],('log',eid))
        log_best=min(force_log[u] for u in targets);sync_best=min(force_sync[u] for u in targets)
        if log_best==optimum:possible.add(eid)
        if sync_best>optimum:mandatory.add(eid)
        restricted[eid]=(force_log,force_sync)
    reverse=[[] for _ in states]
    for u,edges in enumerate(adj):
        for v,w,kind,eid in edges:reverse[v].append((u,w,kind,eid))
    backward=dijkstra(reverse,targets)
    all_ids={e['id'] for e in events}
    answer={'cost':optimum,'possible_log_ids':sorted(possible),'mandatory_log_ids':sorted(mandatory),
            'forced_sync_ids':sorted(all_ids-possible),'ambiguous_consumption_ids':sorted(possible-mandatory),
            'product_states':len(states),'optimal_edges':sum(forward[u]+w+backward[v]==optimum
                for u,edges in enumerate(adj) for v,w,kind,eid in edges),
            'restricted_solver_runs':2*len(events)}
    if all_markings:
        rows=[]
        for mi in range(len(graph['markings'])):
            u=next(u for u,(mask,m) in enumerate(states) if mask==full and m==mi)
            rows.append({'cost':forward[u],
                         'possible_log_ids':sorted(eid for eid,(dl,ds) in restricted.items() if dl[u]==forward[u]),
                         'mandatory_log_ids':sorted(eid for eid,(dl,ds) in restricted.items() if ds[u]>forward[u])})
        answer['marking_frontier']=rows
    return answer


def analyze_document(net_doc,events,order,log_cost,model_cost,final=None):
    transitions,graph=own_graph(net_doc)
    return weighted_oracle(transitions,graph,events,predecessors(events,order),log_cost,model_cost,final)


def weighted_witness(doc,events,pred,result,log_cost,model_cost,final=None):
    by_id={e['id']:i for i,e in enumerate(events)};ts={t['id']:t for t in doc['transitions']}
    marking=tuple(doc['initial']);mask=0;total=0;logged=[]
    for move in result['moves']:
        kind=move['kind'];eid=move['event_id'];tid=move['transition']
        if kind not in ['sync','log','model','silent']:raise ValueError('Unknown move')
        expected=log_cost if kind=='log' else model_cost if kind=='model' else 0
        assert move['cost']==expected;total+=expected
        if kind in ['sync','log']:
            i=by_id[eid];assert not mask>>i&1 and pred[i]&mask==pred[i];mask|=1<<i
        else:assert eid is None
        if kind=='log':assert tid is None;logged.append(eid);continue
        t=ts[tid]
        if kind=='sync':assert t['label'] is not None and t['label']==events[by_id[eid]]['concept']
        if kind=='model':assert t['label'] is not None
        if kind=='silent':assert t['label'] is None
        assert all(m>=p for m,p in zip(marking,t['pre']))
        marking=tuple(m-p+q for m,p,q in zip(marking,t['pre'],t['post']))
    assert mask==(1<<len(events))-1 and total==result['cost'] and list(marking)==result['final_marking']
    if final is not None:assert marking==tuple(final)
    assert set(result['mandatory_log_ids'])<=set(logged)<=set(result['possible_log_ids'])
    if 'witness_log_ids' in result:assert result['witness_log_ids']==sorted(logged)


def result_fields(actual,expected):
    assert str(actual['status']).startswith('EXACT')
    for field in ['cost','possible_log_ids','mandatory_log_ids','forced_sync_ids','ambiguous_consumption_ids','product_states']:
        if field in actual or field in ['cost','possible_log_ids','mandatory_log_ids','product_states']:
            assert actual[field]==expected[field],(field,actual.get(field),expected[field])
    if 'optimal_edges' in actual:assert actual['optimal_edges']==expected['optimal_edges']


def costs(policy):
    if isinstance(policy,(tuple,list)) and len(policy)==2:return tuple(positive_integer(v,n) for v,n in zip(policy,['log_cost','model_cost']))
    if not isinstance(policy,dict):raise ValueError('Cost policy must identify both move costs')
    l=next((policy[k] for k in ['log_cost','log','L'] if k in policy),None)
    m=next((policy[k] for k in ['model_cost','model','M'] if k in policy),None)
    return positive_integer(l,'log_cost'),positive_integer(m,'model_cost')


def policy_map(doc):
    entries=doc['policies'];out={}
    if isinstance(entries,dict):return {key:costs(value) for key,value in entries.items()}
    for item in entries:
        l,m=costs(item);key=item.get('id',item.get('name',f'L{l}_M{m}')) if isinstance(item,dict) else f'L{l}_M{m}'
        if key in out:raise ValueError('Duplicate policy ID')
        out[key]=(l,m)
    return out


def row_costs(row,mapping):
    if 'log_cost' in row and 'model_cost' in row:return costs(row)
    p=row.get('policy',row.get('policy_id'))
    if isinstance(p,(dict,list,tuple)):return costs(p)
    if p not in mapping:raise ValueError('Unknown policy ID: '+str(p))
    return mapping[p]


def serial_doc(k):
    size=k+2;transitions=[]
    for i in range(k+1):
        pre=[0]*size;post=[0]*size;pre[i]=1;post[i+1]=1
        transitions.append({'id':'t'+str(i),'label':'A'+str(i+1) if i<k else 'B','pre':pre,'post':post})
    return {'name':'analytical_k'+str(k),'places':['p'+str(i) for i in range(size)],
            'initial':[1]+[0]*(size-1),'transitions':transitions},[0]*(size-1)+[1]


def threshold_expected(k,l,m,eid):
    return {'prefix_cost':min(l,k*m),'prefix_possible_log_ids':[eid] if l<=k*m else [],
            'prefix_mandatory_log_ids':[eid] if l<k*m else [],'completed_cost':k*m}


def family_check(family_doc,counts):
    families=family_doc['families'];assert {f['k'] for f in families}==set(range(1,9)) and len(families)==8
    seen=set()
    for family in families:
        k=family['k'];doc=family['net'];final=family['final'];events=family['events'];transitions,graph=own_graph(doc)
        assert len(events)==1 and events[0]['concept']=='B'
        # Certify the declared k-predecessor simple serial family structurally.
        assert len(transitions)==k+1 and len(graph['markings'])==k+2
        assert all(t['label'] is not None for t in transitions)
        mark=0;labels=[];visited={mark}
        while graph['edges'][mark]:
            assert len(graph['edges'][mark])==1
            ti,target=graph['edges'][mark][0];labels.append(transitions[ti]['label'])
            assert target not in visited;visited.add(target);mark=target
        assert len(visited)==k+2 and len(labels)==k+1 and labels[-1]=='B' and 'B' not in labels[:-1]
        assert tuple(graph['markings'][mark])==tuple(final)
        for row in family['rows']:
            l,m=costs(row);assert l in range(1,11) and m in [1,2] and (k,l,m) not in seen;seen.add((k,l,m))
            threshold=threshold_expected(k,l,m,events[0]['id']);pred=predecessors(events,'occurrence_partial')
            for phase,finish in [('prefix',None),('completed',final)]:
                expected=weighted_oracle(transitions,graph,events,pred,l,m,finish)
                actual=row[phase];result_fields(actual,expected)
                if 'moves' in actual:weighted_witness(doc,events,pred,actual,l,m,finish)
                counts['analytical_family_results_checked']+=1
                counts['constrained_dijkstra_runs']+=expected['restricted_solver_runs']
                if phase=='prefix':
                    assert expected['cost']==threshold['prefix_cost']
                    assert expected['possible_log_ids']==threshold['prefix_possible_log_ids']
                    assert expected['mandatory_log_ids']==threshold['prefix_mandatory_log_ids']
                else:assert expected['cost']==threshold['completed_cost'] and not expected['possible_log_ids']
    assert seen=={(k,l,m) for k in range(1,9) for l in range(1,11) for m in [1,2]}


def self_test():
    count=0
    for k in range(1,9):
        doc,final=serial_doc(k);transitions,graph=own_graph(doc)
        events=[{'id':'b','concept':'B','occurrence_seconds':10,'availability_seconds':10}]
        for l in range(1,11):
            for m in [1,2]:
                want=threshold_expected(k,l,m,'b')
                prefix=weighted_oracle(transitions,graph,events,[0],l,m)
                complete=weighted_oracle(transitions,graph,events,[0],l,m,final)
                assert prefix['cost']==want['prefix_cost'] and prefix['possible_log_ids']==want['prefix_possible_log_ids']
                assert prefix['mandatory_log_ids']==want['prefix_mandatory_log_ids']
                assert complete['cost']==want['completed_cost'] and not complete['possible_log_ids'];count+=2
    for invalid in [0,-1,True,1.5]:
        try:positive_integer(invalid,'invalid')
        except ValueError:pass
        else:raise AssertionError('Invalid cost accepted')
    return {'status':'SELF_TEST_PASS','analytical_threshold_results':count,'invalid_cost_rejections':4,
            'production_outputs_audited':False}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--self-test',action='store_true');parser.add_argument('--results',type=Path,default=HERE/'weighted_results.json')
    parser.add_argument('--family',type=Path,default=HERE/'analytical_family.json');parser.add_argument('--frozen',type=Path)
    parser.add_argument('--output',type=Path,default=HERE/'weighted_independent_audit.json')
    args=parser.parse_args()
    for key in ['TEMP','TMP','TMPDIR']:os.environ[key]=str(ROOT/'tmp')
    if args.self_test:print(json.dumps(self_test()));return
    started=perf_counter();counts=Counter()
    report={'status':'RUNNING','script_sha256':sha(__file__),'started_at_utc':datetime.now(timezone.utc).isoformat(),
            'clinical_inputs_read':False,'eicu_inputs_read':False,'mortality_fields_accessed':False,
            'expected_solver':'Independent Dijkstra on complete product graph; per-ID forbidden sync/log edges',
            'production_module_imported':False}
    try:
        inputs={'weighted_results.json':args.results,'analytical_family.json':args.family,
                '../petri_revision_truth_v1/specification.json':ROOT/'petri_revision_truth_v1'/'specification.json',
                '../petri_revision_truth_v1/alignment_results.json':ROOT/'petri_revision_truth_v1'/'alignment_results.json',
                '../petri_discovery_baseline_v1/independent_discovery_audit.py':ROOT/'petri_discovery_baseline_v1'/'independent_discovery_audit.py'}
        frozen_path=args.frozen
        if frozen_path is None:
            frozen_path=next((p for p in [HERE/'frozen_inputs.json',HERE/'weighted_frozen_inputs.json'] if p.exists()),None)
        frozen=None
        if frozen_path is not None:
            frozen=load(frozen_path);inputs[frozen_path.name]=frozen_path
            for key,item in frozen['inputs'].items():
                path=Path(item.get('path',key));assert sha(path)==item['sha256']
                if 'bytes' in item:assert path.stat().st_size==item['bytes']
                inputs.setdefault(key,path)
        report['inputs']={name:sha(path) for name,path in inputs.items()}
        spec=load(ROOT/'petri_revision_truth_v1'/'specification.json');episodes={e['id']:e for e in spec['episodes']}
        original=load(ROOT/'petri_revision_truth_v1'/'alignment_results.json')['records']
        base={(r['episode'],r['time'],r['phase'],r['order']):r for r in original};assert len(base)==6975
        result_doc=load(args.results);mapping=policy_map(result_doc)
        pairs={(1,4),(1,2),(1,1),(2,1),(4,1)};assert set(mapping.values())==pairs and len(mapping)==5
        rows=result_doc['records'];assert len(rows)==34875
        compiled={name:own_graph(model['net']) for name,model in spec['models'].items()}
        seen=set();policy_counts={str(pair):Counter() for pair in sorted(pairs)};supports={}
        for row in rows:
            l,m=row_costs(row,mapping);key=(row['episode'],row['time'],row['phase'],row['order']);tag=(key,l,m)
            assert key in base and (l,m) in pairs and tag not in seen;seen.add(tag)
            old=base[key];ep=episodes[row['episode']];name=ep['model']
            for field in ['model','source_mode','observation_mode','visible_record_ids']:
                assert row[field]==old[field],(tag,field)
            if 'source_truth' in row:assert row['source_truth']==old['source_truth']
            if 'all_occurred_source_actions_represented' in row:
                assert row['all_occurred_source_actions_represented']==old['all_occurred_source_actions_represented']
            visible=[r for r in ep['records'] if r['availability_seconds']<=row['time']]
            assert row['visible_record_ids']==[r['id'] for r in visible]
            pred=predecessors(visible,row['order']);final=spec['models'][name]['final'] if row['phase']=='closure_completed' else None
            transitions,graph=compiled[name];expected=weighted_oracle(transitions,graph,visible,pred,l,m,final)
            actual=row['result'];result_fields(actual,expected)
            weighted_witness(spec['models'][name]['net'],visible,pred,actual,l,m,final)
            if 'acceptance' in actual:assert actual['acceptance']==('completed_final_marking' if final is not None else 'prefix_any_marking')
            if (l,m)==(1,1):
                for field in ['cost','possible_log_ids','mandatory_log_ids']:assert actual[field]==old['result'][field]
                counts['unit_policy_previous_result_checks']+=1
            counts['weighted_results_checked']+=1;counts['weighted_witnesses_replayed']+=1
            counts['constrained_dijkstra_runs']+=expected['restricted_solver_runs'];counts['product_states']+=expected['product_states']
            pc=policy_counts[str((l,m))];pc['jobs']+=1;pc['positive_cost_jobs']+=expected['cost']>0
            pc['possible_log_nonempty_jobs']+=bool(expected['possible_log_ids']);pc['mandatory_log_nonempty_jobs']+=bool(expected['mandatory_log_ids'])
            supports.setdefault(key,set()).add((tuple(expected['possible_log_ids']),tuple(expected['mandatory_log_ids'])))
        assert seen=={(key,l,m) for key in base for l,m in pairs}
        family_check(load(args.family),counts)
        report['policy_counts']={k:dict(v) for k,v in policy_counts.items()}
        report['matched_job_keys_with_policy_sensitive_optimal_log_sets']=sum(len(v)>1 for v in supports.values())
        report['analytical_formula']='Prefix min(L,k*M); possible-log iff L<=k*M; mandatory-log iff L<k*M. Completed k*M, forced sync B.'
        report['interpretation']='All-optimal explanations conditional on declared move costs; not unique causal/source diagnoses.'
        for name,path in inputs.items():assert sha(path)==report['inputs'][name],('changed input',name)
        if frozen is not None:
            for key,item in frozen['inputs'].items():assert sha(item.get('path',key))==item['sha256']
        report['status']='PASS'
    except Exception as exc:
        report['status']='FAIL';report['failure']=repr(exc);raise
    finally:
        report['counts']=dict(counts);report['seconds']=perf_counter()-started
        report['completed_at_utc']=datetime.now(timezone.utc).isoformat()
        if args.output.exists():
            previous=load(args.output);report['prior_runs']=previous.get('prior_runs',[])+[{k:v for k,v in previous.items() if k!='prior_runs'}]
        args.output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        print(json.dumps({'status':report['status'],'counts':report['counts'],'seconds':report['seconds'],'failure':report.get('failure')}))


if __name__=='__main__':main()
