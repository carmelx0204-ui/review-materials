"""Complete-cohort original-arc audit with independent state LIMITs preserved."""
import argparse
import ast
from collections import Counter, defaultdict, deque
from datetime import datetime, timezone
from fractions import Fraction
import hashlib
import heapq
from itertools import combinations
import json
from pathlib import Path
import sys
from time import perf_counter
import traceback

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parent
MODEL_LIMIT, PRODUCT_LIMIT = 10000, 100000
FIELDS = ("possible_log_ids", "mandatory_log_ids", "forced_sync_ids", "ambiguous_consumption_ids")
CATEGORIES = ("any_positive_revision", "all_positive_revision", "open_interval_revision",
              "point_revision", "isolated_only_revision", "classic_revision", "default_revision")
REUSED = {
 "bpi2013_position_delay_audit.py": "9f26f649b7092d5fb16c89b2e2604b71d70bdc6048022f6852b4d37df53c517f",
 "weighted_independent_audit.py": "665adda422571b34a89a5bd815026dd56285d3124a7305f77a364f03aa8059b9",
 "affine_gap_delay_independent_audit_v3.py": "42215e75c64ccf47aa0f4f3c3e31f218958c8eb11e2a2b2d77ef160f2247b463",
 "affine_gap_profiles_independent_audit.py": "7e0b0f2881fb987c6f1465e44bd4544ae21342b18ba939e33d8b04c6d597ed11"}


def sha(path):
    answer = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            answer.update(block)
    return answer.hexdigest()


def bind(path):
    path = Path(path).resolve()
    return {"path": str(path), "sha256": sha(path), "bytes": path.stat().st_size}


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def rows(path):
    with Path(path).open(encoding="utf-8") as stream:
        return [json.loads(line) for line in stream if line.strip()]


def save(path, value):
    with Path(path).open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def q(value):
    return None if value is None else {"numerator": value.numerator, "denominator": value.denominator}


def ast_functions(name, wanted, namespace):
    path = ROOT / name
    assert sha(path) == REUSED[name], ("Prior independent source changed", name)
    tree = ast.parse(path.read_text(encoding="utf-8"))
    definitions = {node.name: node for node in tree.body if isinstance(node, ast.FunctionDef)}
    selected = [definitions[function] for function in wanted]
    assert all(not any(isinstance(node, (ast.Import, ast.ImportFrom)) for node in ast.walk(function))
               for function in selected)
    exec(compile(ast.Module(body=selected, type_ignores=[]), str(path), "exec"), namespace)
    return namespace


def primitives():
    common = {"__builtins__": __builtins__, "deque": deque, "Counter": Counter,
              "defaultdict": defaultdict, "Fraction": Fraction, "heapq": heapq,
              "combinations": combinations, "MODEL_LIMIT": MODEL_LIMIT, "PRODUCT_LIMIT": PRODUCT_LIMIT}
    weighted = ast_functions("bpi2013_position_delay_audit.py",
        ["own_graph", "edge_set", "closure", "layered_minimum_models", "active_interval",
         "envelope_points", "active_lines", "samples", "pair_points", "profile_at_saved"], dict(common))
    forbidden = ast_functions("weighted_independent_audit.py",
        ["positive_integer", "build_product", "dijkstra", "weighted_oracle"], {**common, "INF": float("inf")})
    affine = ast_functions("affine_gap_profiles_independent_audit.py",
        ["original_graph", "zero_one", "role_fields", "fixed_profile", "fraction_doc", "fraction_value",
         "evaluate", "partition", "raw_profile"], dict(common))
    prefix = ast_functions("affine_gap_delay_independent_audit_v3.py",
        ["original_prefix_product", "prefix_raw_paths"], {**common, "PRIMITIVES": affine})
    return weighted, forbidden, affine, prefix


def fixed_count_product(transitions, graph, word, cap=PRODUCT_LIMIT):
    """Cap the complete original (i, marking, j) state set before layered DP."""
    states = [(0, 0, 0)]
    indices = {states[0]: 0}
    pending = deque([0])
    edges, reverse = [], [[]]
    while pending:
        u = pending.popleft()
        position, marking, logs = states[u]
        moves = []
        if position < len(word):
            moves.append(((position + 1, marking, logs + 1), 0))
        for ti, target in graph["edges"][marking]:
            label = transitions[ti]["label"]
            moves.append(((position, target, logs), int(label is not None)))
            if position < len(word) and label is not None and label == word[position]:
                moves.append(((position + 1, target, logs), 0))
        outgoing = []
        for successor, weight in moves:
            if successor not in indices:
                if len(states) >= cap:
                    return {"status": "LIMIT_INDEPENDENT_WEIGHTED_COUNT_PRODUCT", "reached_product_states": len(states), "state_cap": cap}
                indices[successor] = len(states)
                states.append(successor)
                pending.append(indices[successor])
                reverse.append([])
            v = indices[successor]
            outgoing.append((v, weight))
            reverse[v].append((u, weight))
        edges.append(outgoing)
    endpoints = [[] for _ in range(len(word) + 1)]
    for u, (position, marking, logs) in enumerate(states):
        if position == len(word):
            endpoints[logs].append(u)
    return {"status": "COMPLETE_ORIGINAL_WEIGHTED_COUNT_PRODUCT", "states": states,
            "edges": edges, "endpoints": endpoints}


def weighted_contract(profile, word):
    assert profile["state_limit"] == PRODUCT_LIMIT
    assert profile["event_count"] == len(word)
    ids = ["v%06d" % i for i in range(len(word))]
    assert profile["event_ids"] == ids and len(set(ids)) == len(ids)
    assert profile["acceptance"] == "prefix_any_marking" and profile["final"] is None
    assert profile["product_states"] <= PRODUCT_LIMIT
    if profile["status"] != "EXACT":
        assert profile["status"] == "LIMIT" and "entries" not in profile
        return
    assert len(profile["entries"]) == len(word) + 1
    feasible = []
    for j, entry in enumerate(profile["entries"]):
        assert entry["log_count"] == j
        if not entry["feasible"]:
            assert entry["model_count"] is None and all(entry[field] is None for field in FIELDS)
            continue
        feasible.append(j)
        assert type(entry["model_count"]) is int and entry["model_count"] >= 0
        sets = {field: set(entry[field]) for field in FIELDS}
        assert all(entry[field] == sorted(sets[field]) for field in FIELDS)
        possible, mandatory = sets["possible_log_ids"], sets["mandatory_log_ids"]
        assert mandatory <= possible <= set(ids)
        assert sets["forced_sync_ids"] == set(ids) - possible
        assert sets["ambiguous_consumption_ids"] == possible - mandatory
        assert len(mandatory) <= j <= len(possible)
    assert feasible == profile["feasible_log_counts"] and feasible


def affine_contract(profile, word):
    assert profile["acceptance"] == "prefix_any_original_marking"
    assert profile["original_reachable_markings"] == 145 and profile["adapter_graph_vertices"] == 146
    assert profile["sentinel_is_original_marking"] is False and profile["state_limit"] == PRODUCT_LIMIT
    if profile["status"] != "EXACT_FIXED_GAP_COUNT_PROFILE":
        assert profile["status"] == "LIMIT_EXPANDED_ANCHORS" and "entries" not in profile
        assert profile["states_at_stop"] <= PRODUCT_LIMIT
        return
    assert profile["expanded_anchor_states"] <= PRODUCT_LIMIT
    previous = -1
    universe = set(range(len(word)))
    for entry in profile["entries"]:
        k = entry["gap_count"]
        assert previous < k <= len(word) + 1 and k >= 0
        previous = k
        assert type(entry["minimum_total_deviations"]) is int and entry["minimum_total_deviations"] >= k
        logged, synced = set(entry["possible_log_positions"]), set(entry["possible_sync_positions"])
        assert logged | synced == universe
        assert entry["mandatory_log_positions"] == sorted(universe - synced)
        assert entry["forced_sync_positions"] == sorted(universe - logged)
        assert entry["ambiguous_positions"] == sorted(logged & synced)
        assert entry["possible_log_positions"] == sorted(logged) and entry["possible_sync_positions"] == sorted(synced)


def lines(profile, objective):
    if objective == "lambda":
        return [(entry["log_count"], entry["model_count"]) for entry in profile["entries"] if entry["feasible"]]
    return [(entry["gap_count"], entry["minimum_total_deviations"]) for entry in profile["entries"]]


def at(profile, objective, value, ids):
    if objective == "lambda":
        feasible = [entry for entry in profile["entries"] if entry["feasible"]]
        optimum = min(value * entry["log_count"] + entry["model_count"] for entry in feasible)
        active = [entry for entry in feasible if value * entry["log_count"] + entry["model_count"] == optimum]
        structural = {"v%06d" % i: event_id for i, event_id in enumerate(ids)}
        possible = set().union(*(set(entry["possible_log_ids"]) for entry in active))
        mandatory = set.intersection(*(set(entry["mandatory_log_ids"]) for entry in active))
        all_ids = set(structural)
        roles = {"possible_log_ids": possible, "mandatory_log_ids": mandatory,
                 "forced_sync_ids": all_ids - possible, "ambiguous_consumption_ids": possible - mandatory}
        return {"normalized_cost": q(optimum),
                "active_counts": [[entry["log_count"], entry["model_count"]] for entry in active],
                **{field: sorted(structural[event_id] for event_id in answer) for field, answer in roles.items()}}
    optimum = min(value * entry["gap_count"] + entry["minimum_total_deviations"] for entry in profile["entries"])
    active = [entry for entry in profile["entries"] if value * entry["gap_count"] + entry["minimum_total_deviations"] == optimum]
    possible = set().union(*(set(entry["possible_log_positions"]) for entry in active))
    synced = set().union(*(set(entry["possible_sync_positions"]) for entry in active))
    universe = set(range(len(ids)))
    roles = {"possible_log_ids": possible, "mandatory_log_ids": universe - synced,
             "possible_sync_ids": synced, "forced_sync_ids": universe - possible,
             "ambiguous_consumption_ids": possible & synced}
    return {"normalized_cost": q(optimum),
            "active_counts": [[entry["gap_count"], entry["minimum_total_deviations"]] for entry in active],
            **{field: sorted(ids[i] for i in answer) for field, answer in roles.items()}}


def change(before, after, common):
    bp, ap = set(before["possible_log_ids"]) & common, set(after["possible_log_ids"]) & common
    bm, am = set(before["mandatory_log_ids"]) & common, set(after["mandatory_log_ids"]) & common
    same = before["normalized_cost"] == after["normalized_cost"]
    return {"same_cost": same, "old_possible_changed": bp != ap, "old_mandatory_changed": bm != am,
            "same_cost_old_summary_revision": same and (bp != ap or bm != am),
            "possible_gained": sorted(ap - bp), "possible_withdrawn": sorted(bp - ap),
            "mandatory_gained": sorted(am - bm), "mandatory_withdrawn": sorted(bm - am)}


def joint(before, after, bids, aids, objective, weighted):
    exact = "EXACT" if objective == "lambda" else "EXACT_FIXED_GAP_COUNT_PROFILE"
    if before["status"] != exact or after["status"] != exact:
        return {"status": "UNAVAILABLE_CONSTITUENT_PROFILE", "before_status": before["status"], "after_status": after["status"]}
    points, _ = weighted["pair_points"](lines(before, objective), lines(after, objective))
    cells = []
    for left, right, probe in weighted["samples"](points):
        b, a = at(before, objective, probe, bids), at(after, objective, probe, aids)
        delta = change(b, a, set(bids))
        if delta["same_cost"]:
            assert b["active_counts"] == a["active_counts"]
        cells.append({"kind": "open_interval", "left": q(left), "right": q(right), "probe": q(probe),
                      "before": b, "after": a, **delta})
        if right is not None:
            b, a = at(before, objective, right, bids), at(after, objective, right, aids)
            cells.append({"kind": "point", "ratio": q(right), "before": b, "after": a, **change(b, a, set(bids))})
    classic_ratio, default_ratio = (Fraction(1), Fraction(1)) if objective == "lambda" else (Fraction(0), Fraction(2))
    endpoints = {}
    for name, value in (("classic", classic_ratio), ("default", default_ratio)):
        b, a = at(before, objective, value, bids), at(after, objective, value, aids)
        endpoints[name] = {"ratio": q(value), "before": b, "after": a, **change(b, a, set(bids))}
    open_effect = any(cell["same_cost_old_summary_revision"] for cell in cells if cell["kind"] == "open_interval")
    point_effect = any(cell["same_cost_old_summary_revision"] for cell in cells if cell["kind"] == "point")
    categories = {"any_positive_revision": open_effect or point_effect,
        "all_positive_revision": all(cell["same_cost_old_summary_revision"] for cell in cells),
        "open_interval_revision": open_effect, "point_revision": point_effect,
        "isolated_only_revision": point_effect and not open_effect,
        "classic_revision": endpoints["classic"]["same_cost_old_summary_revision"],
        "default_revision": endpoints["default"]["same_cost_old_summary_revision"]}
    return {"status": "EXACT_ALL_POSITIVE_PARAMETER_CELLS", "parameter": objective,
            "critical_points": [q(point) for point in points], "cells": cells, **endpoints, "categories": categories}


def make_plan(cases, original_ids):
    variants, indices, snapshots, pairs = [], {}, [], []
    def snapshot(case, events, kind, position):
        word = tuple(e["concept"] for e in events)
        if word not in indices:
            indices[word] = len(variants)
            variants.append({"variant_id": len(variants), "word": list(word), "event_count": len(word)})
        result = {"snapshot_id": len(snapshots), "case": case["id"], "kind": kind,
            "delayed_position": position, "variant_id": indices[word], "event_ids": [e["id"] for e in events],
            "original_event_count": len(case["events"]),
            "source_subset": "original_128" if case["id"] in original_ids else "complementary_1383"}
        snapshots.append(result)
        return result
    for case in cases:
        events = sorted(case["events"], key=lambda e: (e["timestamp_us"], e["xml_index"]))
        after = snapshot(case, events, "after", None)
        for position, event in enumerate(events):
            before = snapshot(case, events[:position] + events[position + 1:], "before", position)
            pairs.append({"pair_id": len(pairs), "case": case["id"], "delayed_position": position,
                "delayed_record_id": event["id"], "normal_last_record_control": position == len(events) - 1,
                "original_event_count": len(events), "source_subset": after["source_subset"],
                "before_snapshot_id": before["snapshot_id"], "after_snapshot_id": after["snapshot_id"]})
    return {"status": "FULL_POPULATION_PLANNED_BEFORE_SOLVING", "marking_cap": MODEL_LIMIT,
        "weighted_product_cap": PRODUCT_LIMIT, "affine_anchor_cap": PRODUCT_LIMIT,
        "independent_explicit_product_cap": PRODUCT_LIMIT, "cases": 1511, "events": 8735,
        "variants": variants, "snapshots": snapshots, "pairs": pairs, "D0_D1_pruning_used": False}


def verify_manifest(path):
    manifest = load(path)
    entries = manifest.get("files", []) + manifest.get("dependencies", [])
    assert entries, str(path)
    for entry in entries:
        assert bind(entry["path"]) == {key: entry[key] for key in ("path", "sha256", "bytes")}, entry["path"]
    return {"path": str(Path(path).resolve()), "sha256": sha(path), "entries_checked": len(entries)}


def calibrate(weighted, forbidden, affine, prefix):
    doc = {"places": ["p0", "p1"], "initial": [1, 0], "transitions": [
        {"id": "a", "label": "A", "pre": [1, 0], "post": [0, 1]},
        {"id": "x0", "label": "X", "pre": [1, 0], "post": [1, 0]},
        {"id": "x1", "label": "X", "pre": [0, 1], "post": [0, 1]}]}
    transitions, graph = weighted["own_graph"](doc)
    checks = []
    for word, expected in (([], [0]), (["A"], [0, 0]), (["B"], [None, 0]), (["A", "A"], [None, 0, 0])):
        product = fixed_count_product(transitions, graph, word)
        assert product["status"].startswith("COMPLETE")
        minima = weighted["layered_minimum_models"](transitions, graph,
            [{"id": str(i), "concept": label} for i, label in enumerate(word)], Counter())
        assert minima == expected
        distance = affine["zero_one"](product["edges"], [0])
        assert [min((distance[u] for u in target), default=None) for target in product["endpoints"]] == minima
        oracle = forbidden["weighted_oracle"](transitions, graph,
            [{"id": str(i), "concept": label} for i, label in enumerate(word)], [(1 << i) - 1 for i in range(len(word))], 1, 1)
        assert oracle["cost"] == min(j + m for j, m in enumerate(minima) if m is not None)
        checks.append({"word": word, "fixed_j_minima": minima, "unit_cost": oracle["cost"], "status": "PASS"})
    assert fixed_count_product(transitions, graph, ["A", "A"], cap=3)["status"] == "LIMIT_INDEPENDENT_WEIGHTED_COUNT_PRODUCT"
    graph_a = affine["original_graph"](doc)
    product = prefix["original_prefix_product"](graph_a, ["A"])
    entries, _ = affine["fixed_profile"](product, 1)
    assert [(entry["gap_count"], entry["minimum_total_deviations"]) for entry in entries] == [(0, 0), (1, 1), (2, 2)]
    assert entries[1]["possible_log_positions"] == entries[1]["possible_sync_positions"] == [0]
    assert entries[2]["possible_log_positions"] == [] and entries[2]["forced_sync_positions"] == [0]
    return {"status": "PASS", "weighted_empty_unmatched_repeated_visible_loop_fixtures": checks,
        "weighted_explicit_cap_negative_control": "PASS", "affine_visible_loop_fixed_K_all_roles": entries}


def producer_aggregate(pair, result, aggregate, category_pairs, category_cases):
    for subset in ("full_1511", pair["source_subset"]):
        key = result.get("parameter", pair["current_objective"]) + "__" + subset
        aggregate[key]["pairs"] += 1
        aggregate[key][result["status"]] += 1
        if pair["normal_last_record_control"]:
            aggregate[key]["normal_last_controls"] += 1
        classic = pair["classic_deviation_stratum"]
        if classic is not None:
            aggregate[key]["classic_stratum_" + classic["stratum"]] += 1
        if result["status"] == "EXACT_ALL_POSITIVE_PARAMETER_CELLS":
            for category, present in result["categories"].items():
                if present:
                    label = key + "__" + category
                    aggregate[key][category] += 1
                    category_pairs[label].append(pair["pair_id"])
                    category_cases[label].add(pair["case"])
            if pair["normal_last_record_control"]:
                aggregate[key]["normal_last_any_positive_revision"] += result["categories"]["any_positive_revision"]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--producer-complete-confirmed", action="store_true")
    args = parser.parse_args()
    assert args.producer_complete_confirmed, "Wait for root terminal-producer confirmation before execution"
    summary = load(STAGE / "alignment_summary.json")
    assert summary["status"] == "PRODUCER_COMPLETE_FULL_ORIGINAL_HOLDOUT_PENDING_INDEPENDENT_ALIGNMENT_AUDIT"
    outputs = ["alignment_independent_preexecution.json", "alignment_independent_audit.json",
               "alignment_independent_readout.md", "alignment_independent_words.jsonl"]
    assert all(not (STAGE / name).exists() for name in outputs), "Exclusive audit output exists; preserve prior execution"
    started = perf_counter()
    sources = [STAGE / name for name in ("alignment_protocol.md", "run_alignments.py",
        "alignment_plan.json", "alignment_frozen_inputs.json", "alignment_variants.jsonl",
        "alignment_snapshots.jsonl", "alignment_pairs.jsonl", "alignment_summary.json",
        "native_cases.jsonl", "source_independent_audit.json", "source_artifact_manifest.json",
        "alignment_independent_protocol.md", "alignment_independent_audit.py")]
    sources += [ROOT / name for name in REUSED]
    sources += [ROOT / name for name in ("bpi2013_model_IMf02.json", "bpi2013_prepared_data.json",
        "bpi2013_position_delay_results.jsonl", "bpi2013_position_delay_audit.json",
        "bpi2013_position_delay_artifact_manifest.json", "affine_gap_delay_results.jsonl",
        "affine_gap_delay_independent_audit.json", "affine_gap_delay_artifact_manifest.json")]
    producer_frozen = load(STAGE / "alignment_frozen_inputs.json")
    for entry in producer_frozen["inputs"]:
        assert bind(entry["path"]) == entry, entry["path"]
        sources.append(Path(entry["path"]))
    unique = {str(path.resolve()): path.resolve() for path in sources}
    before = [bind(path) for path in unique.values()]
    predecessor_checks = [verify_manifest(path) for path in (STAGE / "source_artifact_manifest.json",
        ROOT / "bpi2013_position_delay_artifact_manifest.json", ROOT / "affine_gap_delay_artifact_manifest.json")]
    save(STAGE / outputs[0], {"status": "FROZEN_BEFORE_INDEPENDENT_COMPLETE_COHORT_SOLVERS",
        "bindings": before, "prior_manifest_checks": predecessor_checks, "reused_independent_source_sha256": REUSED,
        "marking_cap": MODEL_LIMIT, "weighted_count_product_cap": PRODUCT_LIMIT,
        "affine_original_product_cap": PRODUCT_LIMIT, "producer_terminal_confirmation": True})
    weighted, forbidden, affine, prefix = primitives()
    calibration = calibrate(weighted, forbidden, affine, prefix)
    assert load(STAGE / "source_independent_audit.json")["status"] == "PASS_COMPLETE_CANONICAL_SOURCE_FULL_HOLDOUT_PREPARATION"
    cases = rows(STAGE / "native_cases.jsonl")
    original = load(ROOT / "bpi2013_prepared_data.json")
    original_ids = {case["id"] for case in original["evaluation_cases"]}
    plan = make_plan(cases, original_ids)
    assert plan == load(STAGE / "alignment_plan.json"), "Complete source plan differs"
    assert len(plan["snapshots"]) == 10246 and len(plan["pairs"]) == 8735
    model = load(ROOT / "bpi2013_model_IMf02.json")
    transitions, graph = weighted["own_graph"](model["net_doc"])
    assert set(graph["markings"]) == set(map(tuple, model["graph"]["markings"]))
    original_transitions = model["net_doc"]["transitions"]
    assert weighted["edge_set"](transitions, graph) == weighted["edge_set"](original_transitions, model["graph"])
    graph_a = affine["original_graph"](model["net_doc"])
    assert graph_a["status"] == "COMPLETE_ORIGINAL_GRAPH" and len(graph_a["markings"]) == 145
    assert len(graph["markings"]) == 145 and sum(map(len, graph["edges"])) == 637
    counts, producer_counts = Counter(), Counter()
    variants = rows(STAGE / "alignment_variants.jsonl")
    assert len(variants) == len(plan["variants"])
    certificates, cache = [], {}
    word_stream = (STAGE / outputs[3]).open("x", encoding="utf-8", newline="\n")
    for index, row in enumerate(variants):
        assert {key: row[key] for key in plan["variants"][index]} == plan["variants"][index]
        word = row["word"]
        events = [{"id": "v%06d" % i, "concept": label} for i, label in enumerate(word)]
        wp, ap = row["weighted_profile"], row["affine_profile"]
        weighted_contract(wp, word)
        affine_contract(ap, word)
        producer_counts["weighted_" + wp["status"]] += 1
        producer_counts["affine_" + ap["status"]] += 1
        wc = fixed_count_product(transitions, graph, word)
        wcertificate = {"status": wc["status"], "declared_state_cap": PRODUCT_LIMIT,
            "original_product_states": len(wc.get("states", [])) or wc.get("reached_product_states")}
        if wc["status"].startswith("COMPLETE"):
            minima = weighted["layered_minimum_models"](transitions, graph, events, counts)
            distance = affine["zero_one"](wc["edges"], [0])
            direct = [min((distance[u] for u in targets), default=None) for targets in wc["endpoints"]]
            assert minima == direct
            wcertificate["fixed_j_minimum_model_counts"] = minima
            wcertificate["original_product_edges"] = sum(map(len, wc["edges"]))
            counts["weighted_original_product_states_total"] += len(wc["states"])
            counts["weighted_original_product_edges_total"] += sum(map(len, wc["edges"]))
            counts["maximum_weighted_original_product_states"] = max(counts["maximum_weighted_original_product_states"], len(wc["states"]))
            if wp["status"] == "EXACT":
                assert minima == [entry["model_count"] for entry in wp["entries"]]
                assert len(wc["states"]) == wp["product_states"]
                ratios = set(weighted["envelope_points"](lines(wp, "lambda"))) | {Fraction(1)}
                ratios.update(probe for _, _, probe in weighted["samples"](weighted["envelope_points"](lines(wp, "lambda"))))
                active_checks = []
                for value in sorted(ratios):
                    # For a total order the oracle mask has exactly n+1 possible prefixes.
                    assert (len(word) + 1) * len(graph["markings"]) <= PRODUCT_LIMIT
                    answer = forbidden["weighted_oracle"](transitions, graph, events,
                        [(1 << i) - 1 for i in range(len(word))], value.numerator, value.denominator)
                    assert answer["product_states"] <= PRODUCT_LIMIT
                    expected = at(wp, "lambda", value, [event["id"] for event in events])
                    assert q(Fraction(answer["cost"], value.denominator)) == expected["normalized_cost"]
                    assert all(answer[field] == expected[field] for field in FIELDS)
                    active_checks.append({"ratio": q(value), "result": expected,
                        "original_oracle_states": answer["product_states"], "restricted_solver_runs": answer["restricted_solver_runs"]})
                    counts["weighted_all_positive_cell_support_checks"] += 1
                    counts["weighted_forbidden_edge_solver_runs"] += answer["restricted_solver_runs"]
                wcertificate.update(status="CERTIFIED_ALL_FIXED_J_COSTS_AND_ALL_POSITIVE_ACTIVE_SUPPORTS",
                    active_support_certificates=active_checks, inactive_fixed_j_support_scope="contract only, not independently forbidden-edge checked")
                counts["weighted_fixed_j_rows_checked"] += len(minima)
        counts["weighted_independent_" + wcertificate["status"]] += 1
        del wc
        ac = prefix["original_prefix_product"](graph_a, word)
        acertificate = {"status": ac["status"], "declared_state_cap": PRODUCT_LIMIT,
            "original_product_states": len(ac.get("states", [])) or ac.get("reached_product_states")}
        if ac["status"].startswith("COMPLETE"):
            entries, checked_edges = affine["fixed_profile"](ac, len(word))
            acertificate["entries"] = entries
            acertificate["original_product_edges"] = sum(map(len, ac["edges"]))
            counts["affine_original_product_states_total"] += len(ac["states"])
            counts["affine_original_product_edges_total"] += sum(map(len, ac["edges"]))
            counts["maximum_affine_original_product_states"] = max(counts["maximum_affine_original_product_states"], len(ac["states"]))
            counts["affine_fixed_K_optimal_edge_checks"] += checked_edges
            if ap["status"] == "EXACT_FIXED_GAP_COUNT_PROFILE":
                assert entries == ap["entries"], (index, "ALL_FIXED_K_COST_SUPPORT_MISMATCH")
                acertificate["status"] = "CERTIFIED_ALL_FIXED_K_COSTS_AND_ROLES_INCLUDING_DOMINATED"
                counts["affine_all_fixed_K_rows_checked"] += len(entries)
        counts["affine_independent_" + acertificate["status"]] += 1
        del ac
        if wp["status"] == "EXACT" and ap["status"] == "EXACT_FIXED_GAP_COUNT_PROFILE":
            w = at(wp, "lambda", Fraction(1), [event["id"] for event in events])
            a = at(ap, "rho", Fraction(0), [event["id"] for event in events])
            assert w["normalized_cost"] == a["normalized_cost"] and all(w[field] == a[field] for field in FIELDS)
            producer_counts["classic_cross_objective_matches"] += 1
        cache[index] = {"weighted_status": wcertificate["status"], "affine_status": acertificate["status"]}
        certificate = {"variant_id": index, "word": word, "weighted": wcertificate, "affine": acertificate}
        certificates.append(certificate)
        word_stream.write(json.dumps(certificate, ensure_ascii=False, separators=(",", ":"), allow_nan=False) + "\n")
        word_stream.flush()
        if (index + 1) % 25 == 0 or index + 1 == len(variants):
            print(json.dumps({"stage": "independent_original_products", "variants_checked": index + 1,
                "variants_total": len(variants), "counts": {key: value for key, value in counts.items() if "independent_" in key},
                "elapsed_seconds": round(perf_counter() - started, 3)}), flush=True)
    word_stream.close()
    assert rows(STAGE / outputs[3]) == certificates
    saved_snapshots = rows(STAGE / "alignment_snapshots.jsonl")
    assert len(saved_snapshots) == len(plan["snapshots"])
    old_weighted, old_affine = {}, {}
    for path, destination in ((ROOT / "bpi2013_position_delay_results.jsonl", old_weighted),
                              (ROOT / "affine_gap_delay_results.jsonl", old_affine)):
        for row in rows(path):
            key = row["case"], None if row["type"] == "after_profile" else row["delayed_position"]
            assert key not in destination
            destination[key] = row["profile"] if row["type"] == "after_profile" else row["before_profile"]
    for expected, saved_snapshot in zip(plan["snapshots"], saved_snapshots):
        row = variants[expected["variant_id"]]
        statuses = {"lambda": row["weighted_profile"]["status"], "rho": row["affine_profile"]["status"]}
        assert saved_snapshot == {**expected, "constituent_statuses": statuses}
        producer_counts["logical_snapshots"] += 1
        counts["logical_snapshots_identity_maps_checked"] += 1
        if expected["source_subset"] == "original_128":
            key = expected["case"], expected["delayed_position"]
            if statuses["lambda"] == "EXACT":
                current = at(row["weighted_profile"], "lambda", Fraction(1), expected["event_ids"])
                old = weighted["profile_at_saved"](old_weighted[key], Fraction(1))
                assert current["normalized_cost"] == q(Fraction(old["cost"]))
                assert all(current[field] == old[field] for field in FIELDS)
                producer_counts["original_weighted_classic_snapshot_matches"] += 1
                if cache[expected["variant_id"]]["weighted_status"].startswith("CERTIFIED"):
                    counts["original_weighted_classic_snapshots_independently_certified"] += 1
            if statuses["rho"] == "EXACT_FIXED_GAP_COUNT_PROFILE":
                assert row["affine_profile"]["entries"] == old_affine[key]["entries"]
                producer_counts["original_affine_all_fixed_K_snapshot_matches"] += 1
                if cache[expected["variant_id"]]["affine_status"].startswith("CERTIFIED"):
                    counts["original_affine_all_fixed_K_snapshots_independently_certified"] += 1
    pair_rows = rows(STAGE / "alignment_pairs.jsonl")
    assert len(pair_rows) == len(plan["pairs"])
    aggregate, category_pairs, category_cases = defaultdict(Counter), defaultdict(list), defaultdict(set)
    independent_aggregate, independent_categories = defaultdict(Counter), defaultdict(set)
    coverage, coverage_cases, pair_certificates = defaultdict(Counter), defaultdict(lambda: defaultdict(set)), []
    old_weighted_pairs = {(row["case"], row["delayed_position"]): row
                         for row in rows(ROOT / "bpi2013_position_delay_results.jsonl") if row["type"] == "intervention"}
    old_affine_pairs = {(row["case"], row["delayed_position"]): row
                       for row in rows(ROOT / "affine_gap_delay_results.jsonl") if row["type"] == "intervention"}
    for expected, saved_pair in zip(plan["pairs"], pair_rows):
        assert {key: saved_pair[key] for key in expected} == expected
        bs, ass = plan["snapshots"][expected["before_snapshot_id"]], plan["snapshots"][expected["after_snapshot_id"]]
        bv, av = variants[bs["variant_id"]], variants[ass["variant_id"]]
        current = {objective: joint(bv[key], av[key], bs["event_ids"], ass["event_ids"], objective, weighted)
                   for objective, key in (("lambda", "weighted_profile"), ("rho", "affine_profile"))}
        classic = None
        if current["lambda"]["status"] == "EXACT_ALL_POSITIVE_PARAMETER_CELLS":
            unit = current["lambda"]["classic"]
            bd = Fraction(**unit["before"]["normalized_cost"])
            ad = Fraction(**unit["after"]["normalized_cost"])
            assert bd.denominator == ad.denominator == 1
            classic = {"before_D": int(bd), "after_D": int(ad),
                "stratum": "at_least_one_D0" if bd == 0 or ad == 0 else "both_D1" if bd == ad == 1 else "remaining_positive"}
        assert saved_pair["classic_deviation_stratum"] == classic
        pair_certificate = {**expected, "objectives": {}}
        for objective in ("lambda", "rho"):
            result = current[objective]
            assert result == saved_pair[objective + "_result"], (expected["pair_id"], objective, "JOINT_CELLS_MISMATCH")
            counts[objective + "_pairs_arithmetically_checked"] += 1
            counts[objective + "_positive_joint_cells_arithmetically_checked"] += len(result.get("cells", []))
            if expected["source_subset"] == "original_128" and result["status"] == "EXACT_ALL_POSITIVE_PARAMETER_CELLS":
                old_key = expected["case"], expected["delayed_position"]
                if objective == "lambda":
                    old_pair = old_weighted_pairs[old_key]
                    old_cells = old_pair["parameter_cells"]
                    old_open = any(cell["same_cost_old_summary_revision"] for cell in old_cells if cell["kind"] == "open_interval")
                    old_point = any(cell["same_cost_old_summary_revision"] for cell in old_cells if cell["kind"] == "point")
                    old_unit = next(policy for policy in old_pair["policies"] if policy["log_cost"] == policy["model_cost"] == 1)
                    old_categories = {"any_positive_revision": old_open or old_point,
                        "all_positive_revision": all(cell["same_cost_old_summary_revision"] for cell in old_cells),
                        "open_interval_revision": old_open, "point_revision": old_point,
                        "isolated_only_revision": old_point and not old_open,
                        "classic_revision": old_unit["same_cost_old_summary_revision"],
                        "default_revision": old_unit["same_cost_old_summary_revision"]}
                else:
                    old_flags = old_affine_pairs[old_key]["classification"]
                    old_categories = {category: old_flags[category] for category in CATEGORIES[:5]}
                    old_categories["classic_revision"] = old_flags["classic_boundary_revision"]
                    old_categories["default_revision"] = old_flags["default_affine_revision"]
                assert result["categories"] == old_categories, (old_key, objective, "OLD_COMPLETE_AXIS_CATEGORY_MISMATCH")
                counts[objective + "_original_subset_complete_axis_categories_match_old"] += 1
            producer_aggregate({**expected, "classic_deviation_stratum": classic, "current_objective": objective},
                               result, aggregate, category_pairs, category_cases)
            status_key = "weighted_status" if objective == "lambda" else "affine_status"
            before_status, after_status = cache[bs["variant_id"]][status_key], cache[ass["variant_id"]][status_key]
            certified = result["status"] == "EXACT_ALL_POSITIVE_PARAMETER_CELLS" and before_status.startswith("CERTIFIED") and after_status.startswith("CERTIFIED")
            pair_certificate["objectives"][objective] = {"status": "CERTIFIED_COMPLETE_PARAMETER_PAIR" if certified else "UNAVAILABLE_INDEPENDENT_CONSTITUENT",
                "producer_status": result["status"], "before_independent_status": before_status, "after_independent_status": after_status,
                "stored_arithmetic_checked": True, "categories": result.get("categories") if certified else None}
            for subset in ("full_1511", expected["source_subset"]):
                key = objective + "__" + subset
                independent_aggregate[key]["pairs_in_denominator"] += 1
                independent_aggregate[key]["certified_pairs" if certified else "unavailable_independent_pairs"] += 1
                group = key + "__length_" + str(expected["original_event_count"]) + "__" + ("normal_last" if expected["normal_last_record_control"] else "earlier_record")
                coverage[group]["pairs"] += 1
                coverage[group]["producer_exact" if result["status"].startswith("EXACT") else "producer_unavailable"] += 1
                coverage[group]["independent_certified" if certified else "independent_unavailable"] += 1
                coverage_cases[group]["all_source_cases"].add(expected["case"])
                coverage_cases[group]["producer_exact_cases" if result["status"].startswith("EXACT") else "producer_unavailable_cases"].add(expected["case"])
                coverage_cases[group]["independent_certified_cases" if certified else "independent_unavailable_cases"].add(expected["case"])
                if classic is not None:
                    coverage[group]["classic_stratum_" + classic["stratum"]] += 1
                    coverage_cases[group]["classic_stratum_" + classic["stratum"] + "_cases"].add(expected["case"])
                if certified:
                    for category, present in result["categories"].items():
                        if present:
                            independent_aggregate[key][category] += 1
                            independent_categories[key + "__" + category].add(expected["case"])
                            coverage[group][category] += 1
                            coverage_cases[group][category + "_cases"].add(expected["case"])
                    if expected["normal_last_record_control"]:
                        independent_aggregate[key]["normal_last_any_positive_revision"] += result["categories"]["any_positive_revision"]
            counts[objective + "_independently_certified_pairs"] += int(certified)
            counts[objective + "_unavailable_independent_pairs"] += int(not certified)
        pair_certificates.append(pair_certificate)
    assert summary["counts"] == dict(producer_counts), (summary["counts"], dict(producer_counts))
    assert summary["aggregate"] == {key: dict(value) for key, value in aggregate.items()}
    assert summary["category_pair_ids"] == dict(category_pairs)
    assert summary["category_case_ids"] == {key: sorted(value) for key, value in category_cases.items()}
    assert summary["category_case_counts"] == {key: len(value) for key, value in category_cases.items()}
    assert summary["distinct_words"] == len(variants)
    assert summary["maximum_weighted_product_states"] == max(row["weighted_profile"].get("product_states", 0) for row in variants)
    assert summary["maximum_affine_expanded_anchors"] == max(row["affine_profile"].get("expanded_anchor_states", 0) for row in variants)
    assert summary["intervention_simulated"] is True and summary["business_truth_claimed"] is False
    assert summary["paper_edited"] is False and summary["D0_D1_pruning_used"] is False
    after = [bind(path) for path in unique.values()]
    assert before == after
    assert not any(name in sys.modules for name in ("cost_profiles", "affine_gap_profiles", "affine_gap_delay", "petri_core", "pm4py"))
    complete = counts["lambda_unavailable_independent_pairs"] == counts["rho_unavailable_independent_pairs"] == 0
    report = {"status": "PASS_COMPLETE_COHORT_ORIGINAL_ARC_ALIGNMENT_AUDIT" if complete else "PASS_SCOPED_COHORT_AUDIT_WITH_INDEPENDENT_OR_PRODUCER_LIMITS",
        "client_date": "2026-10-04", "acceptance": "Any original marking after all observed records consumed; sink-free independent products",
        "scope": {"population": [1511, 8735, 10246], "sampling": False, "weighted_costs": "every fixed-j minimum when capped original count product completes",
            "weighted_ID_supports": "every positive lower-envelope cell plus lambda=1; inactive fixed-j rows contract only",
            "affine_costs_and_ID_supports": "every feasible fixed-K row including dominated whenever original explicit product completes",
            "unchecked_pair_effect": "unavailable, never zero or no effect", "arithmetic": "every producer pair and available stored cell even when independently uncertified"},
        "declared_caps": {"original_markings": MODEL_LIMIT, "weighted_count_product": PRODUCT_LIMIT, "affine_original_product": PRODUCT_LIMIT},
        "observed_maximum_states": {"weighted_original_count_product": counts["maximum_weighted_original_product_states"],
                                  "affine_original_product": counts["maximum_affine_original_product_states"]},
        "original_graph": {"markings": 145, "edges": 637, "original_transition_ID_edges_exact": True},
        "preexecution_bindings": before, "postexecution_bindings": after, "all_bound_inputs_unchanged": True,
        "prior_manifest_checks": predecessor_checks, "AST_reused_sources": REUSED, "calibration": calibration,
        "counts": dict(counts), "reconstructed_producer_counts": dict(producer_counts),
        "reconstructed_producer_aggregate": {key: dict(value) for key, value in aggregate.items()},
        "independent_aggregate": {key: dict(value) for key, value in independent_aggregate.items()},
        "independent_category_case_ids": {key: sorted(value) for key, value in independent_categories.items()},
        "independent_category_case_counts": {key: len(value) for key, value in independent_categories.items()},
        "coverage_by_subset_exact_length_and_control": {key: dict(value) for key, value in coverage.items()},
        "coverage_case_ids_by_subset_exact_length_and_control": {
            key: {field: sorted(identifiers) for field, identifiers in value.items()} for key, value in coverage_cases.items()},
        "coverage_case_counts_by_subset_exact_length_and_control": {
            key: {field: len(identifiers) for field, identifiers in value.items()} for key, value in coverage_cases.items()},
        "source_case_denominators": {"full_1511": 1511, "original_128": 128, "complementary_1383": 1383},
        "coverage_case_groups_can_overlap_between_certified_and_unavailable_pairs": True,
        "word_certificates": certificates, "pair_certificates": pair_certificates,
        "completed_word_checkpoint_binding": bind(STAGE / outputs[3]),
        "elapsed_seconds": perf_counter() - started, "imports_producer_or_Petri_class": False,
        "business_truth_claimed": False, "manuscript_edited": False}
    save(STAGE / outputs[1], report)
    text = f'''# Independent complete-cohort alignment audit

{report['status']}. Reconstructed all 1,511 original holdout cases, 8,735 simulated record interventions and 10,246 shared-after/before identity maps. All producer fixed-plan fields, saved available joint cells and aggregates match exact independent arithmetic. The fixed original Petri graph has 145 markings and 637 original transition edges.

Lambda: {counts['lambda_independently_certified_pairs']:,} intervention pairs independently certified; {counts['lambda_unavailable_independent_pairs']:,} retained as unavailable independent constituents. Rho: {counts['rho_independently_certified_pairs']:,} certified; {counts['rho_unavailable_independent_pairs']:,} unavailable. Unavailable observations remain in every source/length/control denominator and do not mean zero cost or no revision. Stored arithmetic is checked separately from original-product certification.

Weighted audit checks all fixed-j minimum costs on completed capped products and every positive lower-envelope active log-ID support by forbidden-edge searches. Inactive fixed-j supports have contract checks only. Affine audit checks every feasible fixed-K minimum and all log/sync role supports, including dominated lines, using original marking products without a synthetic acceptance sink. All 100,000-state per-word caps are unchanged; producer anchor and independent explicit-state sizes are distinct.

The observed maxima among completed products are weighted {counts['maximum_weighted_original_product_states']:,} and affine {counts['maximum_affine_original_product_states']:,}. LIMIT words retain their separately stored reached-state values in word certificates. The original 128-case snapshots retain all available certified old scalar/support and affine-row results. Full/complement/old subset evidence overlaps as declared. All {len(before)} bound files are unchanged before/after, with no production-helper module imports or manuscript edits. Results are conditional diagnosis behavior, not verified business-error accuracy.
'''
    with (STAGE / outputs[2]).open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(text)
    print(json.dumps({"status": report["status"], "counts": report["counts"], "independent_aggregate": report["independent_aggregate"],
                      "elapsed_seconds": report["elapsed_seconds"], "audit_sha256": sha(STAGE / outputs[1])}), flush=True)


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        target = STAGE / "alignment_independent_failed_run.json"
        if not target.exists():
            save(target, {"status": "STOPPED_PRESERVED_INDEPENDENT_AUDIT_ERROR", "error": repr(error),
                "traceback": traceback.format_exc(), "audit_source_binding": bind(__file__)})
        raise
