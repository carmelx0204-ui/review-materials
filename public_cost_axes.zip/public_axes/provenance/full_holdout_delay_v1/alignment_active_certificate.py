"""Separate D0/D1 active-affine proof supplement; preserve primary LIMITs."""
import argparse
import ast
from collections import Counter, defaultdict, deque
from datetime import datetime, timezone
from fractions import Fraction
import hashlib
import heapq
import json
from pathlib import Path
import sys
from time import perf_counter
import traceback

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parent
CAP = 100000
FIELDS = ("possible_log_ids", "mandatory_log_ids", "forced_sync_ids", "ambiguous_consumption_ids")
CATEGORIES = ("any_positive_revision", "all_positive_revision", "open_interval_revision",
              "point_revision", "isolated_only_revision", "classic_revision", "default_revision")
FROZEN = {
 "bpi2013_position_delay_audit.py": "9f26f649b7092d5fb16c89b2e2604b71d70bdc6048022f6852b4d37df53c517f",
 "weighted_independent_audit.py": "665adda422571b34a89a5bd815026dd56285d3124a7305f77a364f03aa8059b9",
 "monotone_gap_delay_certificate.py": "7cb9690881afeb7fccfacaedccb778198e2c47d7cb31995735833b6b3e059949",
 "monotone_gap_delay_certificate_review.py": "1c6ba6a0f17be34bdd628a7c99889051c619a5b4fd92343066fc19e671616375",
 "monotone_gap_delay_certificate_review.json": "5a159857f188987be177d31d5869119f3ff424465eb1c23e6f979e5cfb56db06",
 "monotone_gap_delay_artifact_manifest.json": "1c032b850077361fbda458087dd6d6eab867f54bb4f9455f171bed9661707440"}
PRIMARY_SOURCE_SHA = "2f82566a971e3d145dbb3dc450ecf6edebfeb68d7fc5400aaafde6bc62b72566"
PRIMARY_PROTOCOL_SHA = "be62173a76affca244365e3d7cfb030b16eeeb8df24cae9231588b8f840afc00"


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def binding(path):
    path = Path(path).resolve()
    return {"path": str(path), "bytes": path.stat().st_size, "sha256": sha(path)}


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def records(path):
    with Path(path).open(encoding="utf-8") as stream:
        return [json.loads(line) for line in stream if line.strip()]


def save(path, value):
    with Path(path).open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def rational(value):
    return {"numerator": value.numerator, "denominator": value.denominator}


def fraction(doc):
    return Fraction(doc["numerator"], doc["denominator"])


def isolated(name, functions, namespace):
    path = ROOT / name
    assert sha(path) == FROZEN[name], name
    nodes = {node.name: node for node in ast.parse(path.read_text(encoding="utf-8")).body if isinstance(node, ast.FunctionDef)}
    selected = [nodes[name] for name in functions]
    assert not any(isinstance(node, (ast.Import, ast.ImportFrom)) for function in selected for node in ast.walk(function))
    exec(compile(ast.Module(body=selected, type_ignores=[]), str(path), "exec"), namespace)
    return namespace


def scalar_saved(profile, value, ids):
    entries = profile["entries"]
    optimum = min(entry["minimum_total_deviations"] + value * entry["gap_count"] for entry in entries)
    active = [entry for entry in entries if entry["minimum_total_deviations"] + value * entry["gap_count"] == optimum]
    logged = set().union(*(set(entry["possible_log_positions"]) for entry in active))
    synced = set().union(*(set(entry["possible_sync_positions"]) for entry in active))
    universe = set(range(len(ids)))
    roles = {"possible_log_ids": logged, "mandatory_log_ids": universe - synced,
             "possible_sync_ids": synced, "forced_sync_ids": universe - logged,
             "ambiguous_consumption_ids": logged & synced}
    return {"normalized_cost": rational(optimum),
            "active_counts": [[entry["gap_count"], entry["minimum_total_deviations"]] for entry in active],
            **{field: sorted(ids[position] for position in positions) for field, positions in roles.items()}}


def weighted_unit_saved(profile):
    feasible = [entry for entry in profile["entries"] if entry["feasible"]]
    optimum = min(entry["log_count"] + entry["model_count"] for entry in feasible)
    active = [entry for entry in feasible if entry["log_count"] + entry["model_count"] == optimum]
    logged = set().union(*(set(entry["possible_log_ids"]) for entry in active))
    mandatory = set.intersection(*(set(entry["mandatory_log_ids"]) for entry in active))
    universe = set(profile["event_ids"])
    return {"cost": optimum, "possible_log_ids": sorted(logged), "mandatory_log_ids": sorted(mandatory),
            "forced_sync_ids": sorted(universe - logged), "ambiguous_consumption_ids": sorted(logged - mandatory)}


def proof_at(unit, value, ids):
    assert unit["cost"] in (0, 1) and value >= 0
    source_ids = ["v%06d" % i for i in range(len(ids))]
    mapping = dict(zip(source_ids, ids))
    roles = {field: sorted(mapping[event_id] for event_id in unit[field]) for field in FIELDS}
    roles["possible_sync_ids"] = sorted(set(ids) - set(roles["mandatory_log_ids"]))
    return {"normalized_cost": rational(Fraction(0) if unit["cost"] == 0 else value + 1),
            "active_counts": [[0, 0]] if unit["cost"] == 0 else [[1, 1]], **roles}


def revision(before, after, old_ids):
    bp, ap = set(before["possible_log_ids"]) & old_ids, set(after["possible_log_ids"]) & old_ids
    bm, am = set(before["mandatory_log_ids"]) & old_ids, set(after["mandatory_log_ids"]) & old_ids
    same = before["normalized_cost"] == after["normalized_cost"]
    return {"same_cost": same, "old_possible_changed": bp != ap, "old_mandatory_changed": bm != am,
            "same_cost_old_summary_revision": same and (bp != ap or bm != am),
            "possible_gained": sorted(ap - bp), "possible_withdrawn": sorted(bp - ap),
            "mandatory_gained": sorted(am - bm), "mandatory_withdrawn": sorted(bm - am)}


def primary_word_status(certificate, unit):
    status = certificate["affine"]["status"]
    if status == "CERTIFIED_ALL_FIXED_K_COSTS_AND_ROLES_INCLUDING_DOMINATED":
        return "PRIMARY_FULL_FIXED_K_CERTIFIED"
    if status == "LIMIT_INDEPENDENT_ORIGINAL_PRODUCT":
        if unit["cost"] == 0:
            return "PROOF_ACTIVE_D0_CERTIFIED_AFTER_PRIMARY_LIMIT"
        if unit["cost"] == 1:
            return "PROOF_ACTIVE_D1_CERTIFIED_AFTER_PRIMARY_LIMIT"
        return "UNKNOWN_AFFINE_ACTIVE_SCOPE_AFTER_PRIMARY_LIMIT"
    return "PRIMARY_OTHER_SCOPE_UNAVAILABLE"


def actor_active_certified(status):
    return status == "PRIMARY_FULL_FIXED_K_CERTIFIED" or status.startswith("PROOF_ACTIVE_")


def manifest_check(path):
    doc = load(path)
    entries = doc["files"] + doc.get("dependencies", [])
    for entry in entries:
        current = binding(entry["path"])
        assert all(current[key] == entry[key] for key in ("path", "bytes", "sha256")), entry["path"]
    return {"path": str(Path(path).resolve()), "sha256": sha(path), "checked_files": len(entries)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--primary-complete-confirmed", action="store_true")
    args = parser.parse_args()
    assert args.primary_complete_confirmed, "Wait for root confirmation of primary terminal audit"
    outputs = ["alignment_active_certificate_preexecution.json", "alignment_active_certificate_words.jsonl",
               "alignment_active_certificate.json", "alignment_active_certificate_readout.md"]
    assert all(not (STAGE / name).exists() for name in outputs), "Preserve previous supplement execution"
    primary = load(STAGE / "alignment_independent_audit.json")
    assert primary["status"] in ("PASS_COMPLETE_COHORT_ORIGINAL_ARC_ALIGNMENT_AUDIT", "PASS_SCOPED_COHORT_AUDIT_WITH_INDEPENDENT_OR_PRODUCER_LIMITS")
    assert primary["declared_caps"] == {"original_markings": 10000, "weighted_count_product": CAP, "affine_original_product": CAP}
    assert primary["preexecution_bindings"] == primary["postexecution_bindings"] and primary["all_bound_inputs_unchanged"] is True
    assert sha(STAGE / "alignment_independent_audit.py") == PRIMARY_SOURCE_SHA
    assert sha(STAGE / "alignment_independent_protocol.md") == PRIMARY_PROTOCOL_SHA
    assert binding(STAGE / "alignment_independent_words.jsonl") == primary["completed_word_checkpoint_binding"]
    assert records(STAGE / "alignment_independent_words.jsonl") == primary["word_certificates"]
    paths = [STAGE / name for name in ("alignment_active_certificate_protocol.md", "alignment_active_certificate.py",
        "alignment_independent_audit.py", "alignment_independent_protocol.md", "alignment_independent_preexecution.json",
        "alignment_independent_words.jsonl", "alignment_independent_audit.json", "alignment_independent_readout.md",
        "alignment_plan.json", "alignment_variants.jsonl", "alignment_snapshots.jsonl", "alignment_pairs.jsonl",
        "alignment_summary.json", "alignment_frozen_inputs.json", "native_cases.jsonl",
        "source_independent_audit.json", "source_artifact_manifest.json")]
    paths += [ROOT / name for name in FROZEN]
    paths += [ROOT / "monotone_gap_delay_certificate.json", ROOT / "bpi2013_model_IMf02.json"]
    for entry in primary["preexecution_bindings"]:
        assert binding(entry["path"]) == entry, entry["path"]
        paths.append(Path(entry["path"]))
    unique = {str(path.resolve()): path.resolve() for path in paths}
    before = [binding(path) for path in unique.values()]
    for name, expected in FROZEN.items():
        assert sha(ROOT / name) == expected, name
    proof_precedent = load(ROOT / "monotone_gap_delay_certificate.json")
    assert proof_precedent["status"] == "PASS_POSTHOC_D1_MONOTONE_GAP_FAMILY_CERTIFICATE"
    assert load(ROOT / "monotone_gap_delay_certificate_review.json")["status"] == "PASS_INDEPENDENT_ARITHMETIC_AND_PROOF_SCOPE_REVIEW"
    prior_manifests = [manifest_check(STAGE / "source_artifact_manifest.json"), manifest_check(ROOT / "monotone_gap_delay_artifact_manifest.json")]
    save(STAGE / outputs[0], {"status": "FROZEN_BEFORE_SEPARATE_ACTIVE_AFFINE_CERTIFICATE_SUPPLEMENT",
        "bindings": before, "primary_source_and_protocol_preserved": True, "prior_manifest_checks": prior_manifests,
        "all_planned_structural_words_in_scope": 3011, "all_original_interventions_in_scope": 8735,
        "primary_caps_unchanged": True, "unit_oracle_state_cap": CAP,
        "D0_D1_proof_family": "sum over nonempty gaps of rho+k, rho>=0", "dominated_fixed_K_scope_not_upgraded": True})
    started = perf_counter()
    graph_functions = isolated("bpi2013_position_delay_audit.py", ["own_graph", "edge_set", "active_interval", "envelope_points", "active_lines", "samples"],
        {"deque": deque, "Fraction": Fraction})
    oracle_functions = isolated("weighted_independent_audit.py", ["positive_integer", "build_product", "dijkstra", "weighted_oracle"],
        {"deque": deque, "heapq": heapq, "INF": float("inf")})
    model = load(ROOT / "bpi2013_model_IMf02.json")
    transitions, graph = graph_functions["own_graph"](model["net_doc"])
    assert len(graph["markings"]) == 145 and sum(map(len, graph["edges"])) == 637
    assert graph_functions["edge_set"](transitions, graph) == graph_functions["edge_set"](model["net_doc"]["transitions"], model["graph"])
    plan = load(STAGE / "alignment_plan.json")
    variants = records(STAGE / "alignment_variants.jsonl")
    assert len(variants) == len(plan["variants"]) == len(primary["word_certificates"]) == 3011
    primary_words = {certificate["variant_id"]: certificate for certificate in primary["word_certificates"]}
    counts, word_certificates, units, statuses = Counter(), [], {}, {}
    stream = (STAGE / outputs[1]).open("x", encoding="utf-8", newline="\n")
    for index, row in enumerate(variants):
        assert {key: row[key] for key in plan["variants"][index]} == plan["variants"][index]
        assert primary_words[index]["word"] == row["word"] and row["variant_id"] == index
        events = [{"id": "v%06d" % i, "concept": label} for i, label in enumerate(row["word"])]
        structural_bound = (len(events) + 1) * len(graph["markings"])
        assert structural_bound <= CAP, (index, "UNIT_TOTAL_ORDER_PRODUCT_BOUND_EXCEEDS_CAP")
        answer = oracle_functions["weighted_oracle"](transitions, graph, events,
            [(1 << i) - 1 for i in range(len(events))], 1, 1)
        assert answer["product_states"] <= structural_bound <= CAP
        unit = {field: answer[field] for field in ("cost",) + FIELDS}
        units[index] = unit
        counts["distinct_words_unit_D" + str(unit["cost"])] += 1
        counts["fresh_unit_oracle_runs"] += 1
        counts["fresh_forbidden_edge_runs"] += answer["restricted_solver_runs"]
        counts["maximum_unit_original_product_states"] = max(counts["maximum_unit_original_product_states"], answer["product_states"])
        counts["maximum_rigorous_unit_total_order_product_bound"] = max(counts["maximum_rigorous_unit_total_order_product_bound"], structural_bound)
        if row["weighted_profile"]["status"] == "EXACT":
            assert unit == weighted_unit_saved(row["weighted_profile"]), (index, "FRESH_UNIT_ORACLE_MISMATCH")
            counts["saved_weighted_unit_summaries_matched"] += 1
        classification = primary_word_status(primary_words[index], unit)
        statuses[index] = classification
        certificate = {"variant_id": index, "word": row["word"], "unit": unit,
            "unit_oracle_product_states": answer["product_states"], "rigorous_unit_product_state_bound": structural_bound,
            "primary_affine_status": primary_words[index]["affine"]["status"],
            "active_scope_status": classification,
            "unit_independence_source": "fresh original-arc frozen forbidden-edge oracle at lambda=1",
            "affine_D0_D1_proof_applicable": unit["cost"] <= 1,
            "dominated_fixed_K_scope": "primary audit only; not upgraded by active proof"}
        profile = row["affine_profile"]
        if unit["cost"] <= 1:
            ids = [event["id"] for event in events]
            if unit["cost"] == 0:
                assert unit["possible_log_ids"] == unit["mandatory_log_ids"] == unit["ambiguous_consumption_ids"] == []
                assert unit["forced_sync_ids"] == sorted(ids)
            certificate["proof"] = {"axis": "all rho>=0", "unique_active_K_D": [0, 0] if unit["cost"] == 0 else [1, 1],
                "normalized_cost": "0" if unit["cost"] == 0 else "rho+1", "all_optimal_record_roles_inherited_from_unit": True,
                "complete_optimal_alignment_set_equals_unit_set": True, "does_not_apply_to_nonuniform_lambda": True}
            if profile["status"] == "EXACT_FIXED_GAP_COUNT_PROFILE":
                cost_lines = [(entry["gap_count"], entry["minimum_total_deviations"]) for entry in profile["entries"]]
                points = graph_functions["envelope_points"](cost_lines)
                probes = {Fraction(0), Fraction(2)} | set(points)
                probes.update(probe for _, _, probe in graph_functions["samples"](points))
                checks = []
                for value in sorted(probes):
                    expected = proof_at(unit, value, ids)
                    assert scalar_saved(profile, value, ids) == expected, (index, str(value), "AFFINE_ACTIVE_PROOF_MISMATCH")
                    checks.append({"rho": rational(value), "proof_result": expected})
                    counts["saved_individual_affine_active_proof_checks"] += 1
                assert points == [], (index, "D0_D1_CANNOT_HAVE_AFFINE_POSITIVE_ACTIVE_BREAKPOINT")
                certificate["all_individual_saved_active_cells_checked"] = checks
            else:
                certificate["saved_active_cells_status"] = "UNAVAILABLE_PRODUCER_PROFILE"
        else:
            certificate["proof"] = {"unit_positive_excludes_affine_zero_cost": True,
                "general_affine_active_roles_certified": False, "D_ge_2_fallback_status": "UNKNOWN"}
        word_certificates.append(certificate)
        stream.write(json.dumps(certificate, ensure_ascii=False, separators=(",", ":"), allow_nan=False) + "\n")
        stream.flush()
        counts["word_scope_" + classification] += 1
        if (index + 1) % 100 == 0 or index + 1 == len(variants):
            print(json.dumps({"stage": "separate_active_affine_unit_certificates", "words_checked": index + 1,
                "words_total": len(variants), "scope_counts": {key: value for key, value in counts.items() if key.startswith("word_scope_")},
                "elapsed_seconds": round(perf_counter() - started, 3)}), flush=True)
    stream.close()
    assert records(STAGE / outputs[1]) == word_certificates
    saved_pairs = records(STAGE / "alignment_pairs.jsonl")
    assert len(saved_pairs) == len(plan["pairs"]) == len(primary["pair_certificates"]) == 8735
    primary_pairs = {pair["pair_id"]: pair for pair in primary["pair_certificates"]}
    pair_certificates, aggregate, coverage, case_sets = [], defaultdict(Counter), defaultdict(Counter), defaultdict(set)
    for expected, pair in zip(plan["pairs"], saved_pairs):
        assert {key: pair[key] for key in expected} == expected
        bs, ass = plan["snapshots"][pair["before_snapshot_id"]], plan["snapshots"][pair["after_snapshot_id"]]
        bi, ai = bs["variant_id"], ass["variant_id"]
        bunit, aunit = units[bi], units[ai]
        bstatus, astatus = statuses[bi], statuses[ai]
        result = pair["rho_result"]
        saved_exact = result["status"] == "EXACT_ALL_POSITIVE_PARAMETER_CELLS"
        primary_full = primary_pairs[pair["pair_id"]]["objectives"]["rho"]["status"] == "CERTIFIED_COMPLETE_PARAMETER_PAIR"
        assert primary_full == (bstatus == astatus == "PRIMARY_FULL_FIXED_K_CERTIFIED" and saved_exact)
        active_full = actor_active_certified(bstatus) and actor_active_certified(astatus) and saved_exact
        if primary_full:
            scope = "PRIMARY_FULL_FIXED_K_PAIR_CERTIFIED"
        elif active_full:
            scope = "ACTIVE_PARAMETER_PAIR_CERTIFIED_WITH_D0_D1_PROOF_FALLBACK"
        elif (bunit["cost"] == 0) != (aunit["cost"] == 0):
            scope = "NO_EQUAL_COST_REVISION_D0_VS_POSITIVE_ONLY"
        else:
            scope = "UNKNOWN_REMAINING_AFFINE_ROLE_DIAGNOSIS"
        certificate = {**expected, "scope_status": scope, "primary_pair_status": primary_pairs[pair["pair_id"]]["objectives"]["rho"]["status"],
            "before_active_scope": bstatus, "after_active_scope": astatus,
            "before_unit_D": bunit["cost"], "after_unit_D": aunit["cost"],
            "all_active_pair_role_sets_certified": active_full,
            "dominated_fixed_K_rows_newly_certified": False,
            "categories": result.get("categories") if active_full else None}
        if saved_exact:
            positions = [(cell, fraction(cell["probe"] if cell["kind"] == "open_interval" else cell["ratio"])) for cell in result["cells"]]
            positions.extend((result[key], fraction(result[key]["ratio"])) for key in ("classic", "default"))
            for cell, value in positions:
                for side, unit, snapshot in (("before", bunit, bs), ("after", aunit, ass)):
                    if unit["cost"] <= 1:
                        assert cell[side] == proof_at(unit, value, snapshot["event_ids"]), (pair["pair_id"], side, str(value), "PAIR_ACTIVE_PROOF_MISMATCH")
                        counts["saved_pair_constituent_active_proof_checks"] += 1
                if bunit["cost"] <= 1 and aunit["cost"] <= 1:
                    delta = revision(proof_at(bunit, value, bs["event_ids"]), proof_at(aunit, value, ass["event_ids"]), set(bs["event_ids"]))
                    assert all(cell[key] == val for key, val in delta.items()), (pair["pair_id"], "PAIR_ROLE_REVISION_PROOF_MISMATCH")
                    counts["both_D0_D1_pair_full_revision_cell_checks"] += 1
                if scope == "NO_EQUAL_COST_REVISION_D0_VS_POSITIVE_ONLY":
                    assert cell["same_cost"] is False and cell["same_cost_old_summary_revision"] is False
            if scope == "NO_EQUAL_COST_REVISION_D0_VS_POSITIVE_ONLY":
                assert all(result["categories"][key] is False for key in CATEGORIES)
        if scope == "NO_EQUAL_COST_REVISION_D0_VS_POSITIVE_ONLY":
            certificate["cost_inequality_proof"] = {"axis": "all rho>=0", "zero_side_cost": "0",
                "positive_side_cost": ">0; unit positive excludes D0 and affine nonempty gap costs are positive",
                "equal_cost_old_ID_revision_impossible": True, "other_affine_role_sets_certified": False,
                "role_sets_unchanged_claimed": False}
        for subset in ("full_1511", pair["source_subset"]):
            aggregate[subset]["pairs_in_denominator"] += 1
            aggregate[subset][scope] += 1
            aggregate[subset]["normal_last_controls"] += int(pair["normal_last_record_control"])
            case_sets[subset + "__all_cases"].add(pair["case"])
            case_sets[subset + "__" + scope].add(pair["case"])
            control = "normal_last" if pair["normal_last_record_control"] else "earlier_record"
            group = subset + "__length_" + str(pair["original_event_count"]) + "__" + control
            coverage[group]["pairs_in_denominator"] += 1
            coverage[group][scope] += 1
            case_sets[group + "__all_cases"].add(pair["case"])
            case_sets[group + "__" + scope].add(pair["case"])
            if active_full:
                for category, present in result["categories"].items():
                    if present:
                        aggregate[subset]["fully_active_certified_" + category] += 1
                        case_sets[subset + "__fully_active_certified_" + category].add(pair["case"])
                        coverage[group]["fully_active_certified_" + category] += 1
        pair_certificates.append(certificate)
    assert len(case_sets["full_1511__all_cases"]) == 1511
    assert len(case_sets["original_128__all_cases"]) == 128 and len(case_sets["complementary_1383__all_cases"]) == 1383
    after = [binding(path) for path in unique.values()]
    assert before == after, "A bound source/producer/primary/proof artifact changed"
    assert not any(name in sys.modules for name in ("cost_profiles", "affine_gap_profiles", "affine_gap_delay", "petri_core", "pm4py"))
    output = {"status": "PASS_SEPARATE_D0_D1_ACTIVE_AFFINE_CERTIFICATES_WITH_SCOPE_LIMITS",
        "client_date": "2026-10-05", "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "population": {"distinct_words": 3011, "cases": 1511, "pairs": 8735},
        "axis": "all rho>=0; sum of rho+k over nonempty gaps",
        "proof_precedents": {"D1_source": "../monotone_gap_delay_certificate.py",
            "independent_review": "../monotone_gap_delay_certificate_review.json", "proof_is_not_new_algorithm_or_general_D_ge_2_claim": True},
        "original_graph": {"markings": 145, "edges": 637}, "unit_oracle_state_cap": CAP,
        "preexecution_bindings": before, "postexecution_bindings": after, "all_bound_inputs_unchanged": True,
        "primary_source_protocol_caps_and_LIMITs_unchanged": True,
        "dominated_fixed_K_scope_not_upgraded": True,
        "D0_vs_positive_no_equal_revision_does_not_certify_other_roles": True,
        "counts": dict(counts), "aggregate": {key: dict(value) for key, value in aggregate.items()},
        "coverage_by_subset_exact_length_and_control": {key: dict(value) for key, value in coverage.items()},
        "case_ids": {key: sorted(value) for key, value in case_sets.items()},
        "case_counts": {key: len(value) for key, value in case_sets.items()},
        "word_certificates": word_certificates, "pair_certificates": pair_certificates,
        "complete_word_checkpoint_binding": binding(STAGE / outputs[1]), "elapsed_seconds": perf_counter() - started,
        "imports_producer_or_Petri_class": False, "manuscript_or_guides_edited": False, "business_truth_claimed": False}
    save(STAGE / outputs[2], output)
    full = aggregate["full_1511"]
    text = f'''# Separate active-affine D0/D1 certificate supplement

PASS with explicit scope limits. Fresh independent unit-cost forbidden-edge searches cover all 3,011 structural words. The full original population remains 1,511 cases and 8,735 simulated withheld-record pairs. Unit D0/D1 proofs certify the entire affine active axis, including rho=0, while preserving the primary explicit-product cap and every original LIMIT.

Full-cohort pairs: {full['PRIMARY_FULL_FIXED_K_PAIR_CERTIFIED']:,} primary full-fixed-K certificates; {full['ACTIVE_PARAMETER_PAIR_CERTIFIED_WITH_D0_D1_PROOF_FALLBACK']:,} additional complete active-parameter certificates; {full['NO_EQUAL_COST_REVISION_D0_VS_POSITIVE_ONLY']:,} cost-inequality-only certificates; {full['UNKNOWN_REMAINING_AFFINE_ROLE_DIAGNOSIS']:,} remaining UNKNOWN role diagnoses. All remain in their full/source/length/control denominators. Pair counts and case counts are saved separately; cases may belong to more than one pair-scope group.

D0 gives cost 0, K=D=0, and all-sync roles. D1 gives cost rho+1, K=D=1, and exactly the complete unit-optimal log/sync role sets. Every saved D0/D1 constituent active cell and classic/default endpoint matches the proof-derived cost, active counts and identities. The inequality-only D0-versus-positive result says the equal-cost revision event cannot occur; it does not say the other role sets are certified or unchanged.

The supplement certifies active behavior only where the proof applies. It never upgrades dominated fixed-K rows or unresolved D>=2 affine roles. The primary audit source/protocol and all bound artifacts retain exact bytes and hashes. This is a separate proof supplement, not a replacement primary audit, a budget increase, new algorithm, natural-delay rate or verified error-accuracy result. No manuscript or guide was edited.
'''
    with (STAGE / outputs[3]).open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(text)
    print(json.dumps({"status": output["status"], "counts": output["counts"], "aggregate": output["aggregate"],
        "elapsed_seconds": output["elapsed_seconds"], "sha256": sha(STAGE / outputs[2])}), flush=True)


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        path = STAGE / "alignment_active_certificate_failed_run.json"
        if not path.exists():
            save(path, {"status": "STOPPED_PRESERVED_ACTIVE_CERTIFICATE_ERROR", "error": repr(error),
                "traceback": traceback.format_exc(), "source_binding": binding(__file__)})
        raise
