"""Prepare/run the entire frozen unknown active-affine scope, no paper edits."""
import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path
from time import perf_counter
import traceback

import original_active_oracle_v2 as oracle

HERE = Path(__file__).resolve().parent
STUDY = HERE.parent
OLD = STUDY / 'full_holdout_delay_v1'
ROLE_FIELDS = ('possible_log_ids', 'mandatory_log_ids', 'possible_sync_ids', 'forced_sync_ids', 'ambiguous_consumption_ids')
POSITION_FIELDS = ('possible_log_positions', 'mandatory_log_positions', 'possible_sync_positions', 'forced_sync_positions', 'ambiguous_positions')
CATEGORIES = ('any_positive_revision', 'all_positive_revision', 'open_interval_revision',
    'point_revision', 'isolated_only_revision', 'classic_revision', 'default_revision')
UNKNOWN_WORD = 'UNKNOWN_AFFINE_ACTIVE_SCOPE_AFTER_PRIMARY_LIMIT'
UNKNOWN_PAIR = 'UNKNOWN_REMAINING_AFFINE_ROLE_DIAGNOSIS'
REVIEW_STATUS = 'PASS_INDEPENDENT_PREEXECUTION_SMALL_ORIGINAL_ACTIVE_AXIS_REVIEW_V3'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def rows(path):
    return [json.loads(line) for line in Path(path).read_text(encoding='utf-8').splitlines() if line]


def bind(path):
    path = Path(path).resolve()
    h = sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            h.update(block)
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': h.hexdigest()}


def verify(records):
    unique = {}
    for expected in records:
        assert bind(expected['path']) == expected, expected['path']
        assert unique.setdefault(expected['path'], expected) == expected
    return sorted(unique.values(), key=lambda r: r['path'])


def save(name, doc):
    with (HERE / name).open('x', encoding='utf-8', newline='\n') as handle:
        json.dump(doc, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write('\n')


def emit(handle, row):
    handle.write(json.dumps(row, ensure_ascii=False, separators=(',', ':'), allow_nan=False) + '\n')


def q(value):
    value = Fraction(value)
    return {'numerator': value.numerator, 'denominator': value.denominator}


def f(doc):
    return Fraction(doc['numerator'], doc['denominator'])


def active(entries, rho):
    price = min(row['gap_count'] * rho + row['minimum_total_deviations'] for row in entries)
    return price, [row for row in entries if row['gap_count'] * rho + row['minimum_total_deviations'] == price]


def critical_points(entries):
    points = set()
    for before in entries:
        for after in entries:
            if before['gap_count'] == after['gap_count']:
                continue
            rho = Fraction(after['minimum_total_deviations'] - before['minimum_total_deviations'], before['gap_count'] - after['gap_count'])
            if rho > 0 and len(active(entries, rho)[1]) > 1:
                points.add(rho)
    return sorted(points)


def candidate_cells(entries):
    points = critical_points(entries)
    cells = []
    for left, right in zip([Fraction(0)] + points, points + [None]):
        probe = left + 1 if right is None else (left + right) / 2
        _, selected = active(entries, probe)
        assert len(selected) == 1
        line = [selected[0]['gap_count'], selected[0]['minimum_total_deviations']]
        cells.append({'kind': 'open_interval', 'left': q(left), 'right': q(right) if right is not None else None,
            'probe': q(probe), 'candidate_line_K_D': line})
        if right is not None:
            cells.append({'kind': 'point', 'ratio': q(right)})
    return cells


def expected_profile_answer(entries, rho, length):
    price, selected = active(entries, rho)
    logged, synced = set(), set()
    for row in selected:
        logged.update(row['possible_log_positions'])
        synced.update(row['possible_sync_positions'])
    universe = set(range(length))
    assert logged | synced == universe and logged | synced <= universe
    return {'normalized_cost': q(price), 'possible_log_positions': sorted(logged), 'possible_sync_positions': sorted(synced),
        'mandatory_log_positions': sorted(universe - synced), 'forced_sync_positions': sorted(universe - logged),
        'ambiguous_positions': sorted(logged & synced)}


def original_edge_set(transitions, graph):
    return {(tuple(graph['markings'][u]), transitions[ti]['id'], tuple(graph['markings'][v]))
        for u, outgoing in enumerate(graph['edges']) for ti, v in outgoing}


def predecessor_gate():
    manifest = read(OLD / 'alignment_artifact_manifest.json')
    assert manifest['status'] == 'COMPLETE_FULL_COHORT_ALIGNMENT_STAGE_WITH_SCOPED_PRIMARY_AND_ACTIVE_PROOF_SUPPLEMENT_FROZEN'
    checked = verify(manifest['files'] + manifest['dependency_bindings'])
    checked += [bind(OLD / 'alignment_artifact_manifest.json')]
    primary, supplement = read(OLD / 'alignment_independent_audit.json'), read(OLD / 'alignment_active_certificate.json')
    assert primary['status'] == 'PASS_SCOPED_COHORT_AUDIT_WITH_INDEPENDENT_OR_PRODUCER_LIMITS'
    assert primary['declared_caps'] == {'original_markings': 10000, 'weighted_count_product': 100000, 'affine_original_product': 100000}
    assert supplement['status'] == 'PASS_SEPARATE_D0_D1_ACTIVE_AFFINE_CERTIFICATES_WITH_SCOPE_LIMITS'
    assert supplement['primary_source_protocol_caps_and_LIMITs_unchanged'] and supplement['dominated_fixed_K_scope_not_upgraded']
    assert primary['preexecution_bindings'] == primary['postexecution_bindings']
    assert supplement['preexecution_bindings'] == supplement['postexecution_bindings']
    calibration = read(HERE / 'calibration_v2.json')
    assert calibration['status'] == 'PASS_SAME_AUTHOR_RAW_MOVE_SCALAR_ROLE_LEX_INTERVAL_TAIL_AND_ZERO_CYCLE_CALIBRATION'
    assert calibration['inputs_before'] == calibration['inputs_after']
    verify(calibration['inputs_before'])
    return verify(checked), primary, supplement


def construct_plan(supplement):
    old_plan = read(OLD / 'alignment_plan.json')
    variants = rows(OLD / 'alignment_variants.jsonl')
    assert len(variants) == len(old_plan['variants']) == 3011
    unknown_words = [row for row in supplement['word_certificates'] if row['active_scope_status'] == UNKNOWN_WORD]
    unknown_pairs = [row for row in supplement['pair_certificates'] if row['scope_status'] == UNKNOWN_PAIR]
    selected_ids = {r['variant_id'] for r in unknown_words}
    expected_pairs = []
    for pair in old_plan['pairs']:
        before, after = old_plan['snapshots'][pair['before_snapshot_id']], old_plan['snapshots'][pair['after_snapshot_id']]
        if before['variant_id'] in selected_ids or after['variant_id'] in selected_ids:
            expected_pairs.append(pair)
    assert [{k: r[k] for k in expected} for r, expected in zip(unknown_pairs, expected_pairs)] == expected_pairs
    assert len(unknown_pairs) == len(expected_pairs)
    participating_unknown_ids = {old_plan['snapshots'][pair[side + '_snapshot_id']]['variant_id']
        for pair in expected_pairs for side in ('before', 'after')} & selected_ids
    assert participating_unknown_ids == selected_ids
    planned_words = []
    for row in unknown_words:
        variant = variants[row['variant_id']]
        assert variant['word'] == row['word'] and variant['affine_profile']['status'] == 'EXACT_FIXED_GAP_COUNT_PROFILE'
        assert row['primary_affine_status'] == 'LIMIT_INDEPENDENT_ORIGINAL_PRODUCT'
        entries = variant['affine_profile']['entries']
        assert all(isinstance(e['gap_count'], int) and e['gap_count'] >= 0 and isinstance(e['minimum_total_deviations'], int) and e['minimum_total_deviations'] >= e['gap_count'] for e in entries)
        planned_words.append({'variant_id': variant['variant_id'], 'word': variant['word'],
            'prior_active_scope': UNKNOWN_WORD, 'primary_affine_status': row['primary_affine_status'],
            'candidate_cells': candidate_cells(entries), 'critical_points': [q(r) for r in critical_points(entries)],
            'rigorous_small_product_state_bound': 2 * (len(variant['word']) + 1) * 145,
            'rho_zero_and_default_two_roles_are_separate_direct_checks': True})
    return {'status': 'COMPLETE_FROZEN_UNKNOWN_SCOPE_PLAN_BEFORE_ANY_COHORT_ACTIVE_SOLVE',
        'selection_rule': 'all supplement active-UNKNOWN words and every affected original pair, independent of outcome',
        'words': planned_words, 'affected_pairs': expected_pairs,
        'prior_full_population': {'words': 3011, 'snapshots': 10246, 'pairs': 8735, 'cases': 1511},
        'planned_word_count': len(planned_words), 'planned_pair_count': len(expected_pairs),
        'planned_case_ids': sorted({r['case'] for r in expected_pairs}), 'original_marking_cap': 10000,
        'small_original_state_cap': 100000, 'primary_fixed_K_LIMITs_and_dominated_scope_preserved': True}


def output_schema():
    return {'status': 'PREPARED_SCHEMA_NOT_RESULTS', 'scope': 'active affine scalar/record roles only',
        'word_certificates_v3.jsonl': {'selection': 'every planned unknown word',
            'fields': ['variant_id', 'word', 'status', 'direct_rho_zero', 'direct_default_two', 'cells', 'resource_counts'],
            'costs': 'exact Fraction numerator/denominator', 'active_count_table_claimed': False,
            'cells': 'points have ratio+direct_answer; opens have finite endpoint/witness/concavity or tail lex certificates'},
        'affected_pair_certificates_v3.jsonl': {'selection': 'every planned original affected pair',
            'fields': ['original pair fields', 'status', 'recomputed_result', 'before_scope', 'after_scope']},
        'full_pair_scope_v3.jsonl': {'row_count': 8735,
            'fields': ['original pair fields', 'status', 'active_only', 'categories', 'small_product_supplement_used']},
        'summary_v3.json': {'terminal_status': 'PASS_SEPARATE_SMALL_ORIGINAL_PRODUCT_ACTIVE_AXIS_WITH_PRIOR_FIXED_K_LIMITS_PRESERVED',
            'full_denominators': [1511, 8735, 10246, 3011], 'inactive_and_dominated_fixed_K_scope_upgraded': False,
            'complete_positive_axis_plus_rho_zero': 'all planned word certificates and all 8735 full pair active certificates succeed; remaining UNKNOWN is zero'},
        'review_contract': {'status': REVIEW_STATUS, 'binding_fields': ['runner_binding', 'oracle_binding', 'plan_binding', 'prepared_input_binding', 'schema_binding'],
            'all_prepared_stage_bindings_reviewed': True}}


def prepare():
    names = ('plan_v3.json', 'output_schema_v3.json', 'prepared_inputs_v3.json', 'preparation_summary_v3.json')
    assert all(not (HERE / name).exists() for name in names)
    dependencies, _, supplement = predecessor_gate()
    repair = read(HERE / 'versioned_repair_v3.json')
    verify(repair['preserved_V1_V2_preparation_bindings'])
    dependencies = verify(dependencies + repair['preserved_V1_V2_preparation_bindings'])
    plan = construct_plan(supplement)
    model = read(STUDY / 'bpi2013_model_IMf02.json')
    graph = oracle.original_graph(model['net_doc'], cap=10000)
    assert graph['status'] == 'EXACT_ORIGINAL_GRAPH' and len(graph['markings']) == 145 and sum(map(len, graph['edges'])) == 637
    assert original_edge_set(graph['transitions'], graph) == original_edge_set(model['net_doc']['transitions'], model['graph'])
    assert all(row['rigorous_small_product_state_bound'] <= 100000 for row in plan['words'])
    save('plan_v3.json', plan)
    save('output_schema_v3.json', output_schema())
    stage_names = ('protocol.md', 'original_active_oracle_v2.py', 'calibrate_original_active_oracle_v2.py', 'calibration_v2.json',
        'run_active_axis_v3.py', 'plan_v3.json', 'output_schema_v3.json',
        'protocol_addendum_v3.md', 'prepare_runner_v3.py', 'versioned_repair_v3.json')
    save('prepared_inputs_v3.json', {'status': 'PREPARED_AND_BOUND_BEFORE_ANY_COHORT_ACTIVE_SOLVE',
        'stage_bindings': [bind(HERE / name) for name in stage_names], 'dependency_bindings': dependencies,
        'original_model_binding': bind(STUDY / 'bpi2013_model_IMf02.json'),
        'small_product_probe_or_oracle_cohort_runs': 0, 'original_graph_reconstruction': {'markings': 145, 'edges': 637}})
    save('preparation_summary_v3.json', {'status': 'PREPARED_UNKNOWN_SCOPE_UNRUN_PENDING_ROOT_AND_EXTERNAL_REVIEW',
        'planned_words': plan['planned_word_count'], 'planned_pairs': plan['planned_pair_count'],
        'planned_cases': plan['planned_case_ids'], 'maximum_rigorous_small_product_bound': max(r['rigorous_small_product_state_bound'] for r in plan['words']),
        'all_old_LIMITs_and_fixed_K_scope_preserved': True, 'formal_cohort_solve_started': False,
        'calibration_status': read(HERE / 'calibration_v2.json')['status'], 'paper_or_guides_edited': False})
    print(json.dumps({'status': 'PREPARED_UNKNOWN_SCOPE_UNRUN_PENDING_ROOT_AND_EXTERNAL_REVIEW',
        'words': plan['planned_word_count'], 'pairs': plan['planned_pair_count'],
        'cases': plan['planned_case_ids']}), flush=True)


def expected_and_compare(answer, profile, rho, length):
    expected = expected_profile_answer(profile['entries'], rho, length)
    assert {k: answer[k] for k in ('normalized_cost',) + POSITION_FIELDS} == expected


def certify_word(planned, variant, graph):
    product = oracle.build_product(graph, planned['word'], final=None, cap=100000)
    if product['status'] != 'EXACT_SMALL_ORIGINAL_PRODUCT':
        return {'variant_id': planned['variant_id'], 'word': planned['word'],
            'status': 'UNAVAILABLE_SMALL_ORIGINAL_PRODUCT', 'constituent_status': product['status']}
    profile = variant['affine_profile']
    length, certificates = len(planned['word']), []
    zero, default = oracle.scalar_and_roles(product, 0), oracle.scalar_and_roles(product, 2)
    expected_and_compare(zero, profile, Fraction(0), length)
    expected_and_compare(default, profile, Fraction(2), length)
    for cell in planned['candidate_cells']:
        if cell['kind'] == 'point':
            rho = f(cell['ratio'])
            direct = oracle.scalar_and_roles(product, rho)
            expected_and_compare(direct, profile, rho, length)
            certificates.append({**cell, 'direct_answer': direct})
        else:
            left, right = f(cell['left']), f(cell['right']) if cell['right'] is not None else None
            K, D = cell['candidate_line_K_D']
            proof = oracle.certify_unbounded_tail(product, left, K, D) if right is None else oracle.certify_finite_interval(product, left, right, K, D)
            expected_and_compare(proof['interior_direct_answer'], profile, f(cell['probe']), length)
            certificates.append({**cell, 'whole_interval_certificate': proof})
    return {'variant_id': planned['variant_id'], 'word': planned['word'], 'status': 'CERTIFIED_ENTIRE_NONNEGATIVE_AFFINE_ACTIVE_COST_AND_RECORD_ROLES',
        'direct_rho_zero': zero, 'direct_default_two': default, 'cells': certificates,
        'resource_counts': {'product_states': len(product['states']), 'product_edges': sum(map(len, product['outgoing'])),
            'rigorous_product_state_bound': product['rigorous_bound'], 'state_cap': 100000},
        'primary_fixed_K_LIMITs_and_dominated_scope_upgraded': False, 'all_active_count_sets_at_ties_claimed': False}


def positions_at(certificate, rho):
    rho = Fraction(rho)
    assert rho >= 0 and certificate['status'] == 'CERTIFIED_ENTIRE_NONNEGATIVE_AFFINE_ACTIVE_COST_AND_RECORD_ROLES'
    if rho == 0:
        result = certificate['direct_rho_zero']
    else:
        result = None
        for cell in certificate['cells']:
            if cell['kind'] == 'point' and rho == f(cell['ratio']):
                result = cell['direct_answer']
                break
            if cell['kind'] == 'open_interval' and rho > f(cell['left']) and (cell['right'] is None or rho < f(cell['right'])):
                proof = cell['whole_interval_certificate']
                K, D = proof['line_K_D']
                result = {**proof['interior_direct_answer'], 'normalized_cost': q(K * rho + D)}
                break
        assert result is not None
    return {k: result[k] for k in ('normalized_cost',) + POSITION_FIELDS}


def mapped_at(profile, certificate, rho, ids):
    result = positions_at(certificate, rho) if certificate is not None else expected_profile_answer(profile['entries'], rho, len(ids))
    return {'normalized_cost': result['normalized_cost'],
        **{field: sorted(ids[p] for p in result[pos]) for field, pos in zip(ROLE_FIELDS, POSITION_FIELDS)}}


def revision(before, after, common):
    bp, ap = set(before['possible_log_ids']) & common, set(after['possible_log_ids']) & common
    bm, am = set(before['mandatory_log_ids']) & common, set(after['mandatory_log_ids']) & common
    same = before['normalized_cost'] == after['normalized_cost']
    return {'same_cost': same, 'old_possible_changed': bp != ap, 'old_mandatory_changed': bm != am,
        'same_cost_old_summary_revision': same and (bp != ap or bm != am),
        'possible_gained': sorted(ap - bp), 'possible_withdrawn': sorted(bp - ap),
        'mandatory_gained': sorted(am - bm), 'mandatory_withdrawn': sorted(bm - am)}


def joint_points(before_entries, after_entries):
    points = set(critical_points(before_entries) + critical_points(after_entries))
    for before in before_entries:
        for after in after_entries:
            if before['gap_count'] == after['gap_count']:
                continue
            rho = Fraction(after['minimum_total_deviations'] - before['minimum_total_deviations'], before['gap_count'] - after['gap_count'])
            if rho > 0 and active(before_entries, rho)[0] == active(after_entries, rho)[0]:
                if before['gap_count'] * rho + before['minimum_total_deviations'] == active(before_entries, rho)[0]:
                    points.add(rho)
    return sorted(points)


def pair_result(before_profile, after_profile, before_certificate, after_certificate, before_ids, after_ids):
    points = joint_points(before_profile['entries'], after_profile['entries'])
    def at(rho):
        before = mapped_at(before_profile, before_certificate, rho, before_ids)
        after = mapped_at(after_profile, after_certificate, rho, after_ids)
        return {'ratio': q(rho), 'before': before, 'after': after, **revision(before, after, set(before_ids))}
    cells = []
    for left, right in zip([Fraction(0)] + points, points + [None]):
        probe = left + 1 if right is None else (left + right) / 2
        cells.append({'kind': 'open_interval', 'left': q(left), 'right': q(right) if right is not None else None,
            'probe': q(probe), **{k: v for k, v in at(probe).items() if k != 'ratio'}})
        if right is not None:
            cells.append({'kind': 'point', **at(right)})
    boundary, default = at(Fraction(0)), at(Fraction(2))
    open_revision = any(c['same_cost_old_summary_revision'] for c in cells if c['kind'] == 'open_interval')
    point_revision = any(c['same_cost_old_summary_revision'] for c in cells if c['kind'] == 'point')
    return {'status': 'EXACT_ALL_POSITIVE_PARAMETER_CELLS', 'parameter': 'rho', 'cells': cells,
        'classic': boundary, 'default': default, 'categories': {'any_positive_revision': open_revision or point_revision,
            'all_positive_revision': all(c['same_cost_old_summary_revision'] for c in cells),
            'open_interval_revision': open_revision, 'point_revision': point_revision,
            'isolated_only_revision': point_revision and not open_revision,
            'classic_revision': boundary['same_cost_old_summary_revision'], 'default_revision': default['same_cost_old_summary_revision']}}


def compare_saved_pair(reconstructed, saved):
    assert reconstructed['status'] == saved['status'] and reconstructed['categories'] == saved['categories']
    assert len(reconstructed['cells']) == len(saved['cells'])
    for expected, actual in zip(reconstructed['cells'] + [reconstructed['classic'], reconstructed['default']],
                                saved['cells'] + [saved['classic'], saved['default']]):
        for field, value in expected.items():
            if field in ('before', 'after'):
                assert all(actual[field][k] == v for k, v in value.items())
            else:
                assert actual[field] == value, field


def run(review_path):
    output_names = ('run_inputs_v3.json', 'word_certificates_v3.jsonl', 'affected_pair_certificates_v3.jsonl', 'full_pair_scope_v3.jsonl', 'summary_v3.json', 'readout_v3.md')
    assert all(not (HERE / n).exists() for n in output_names)
    prepared, plan = read(HERE / 'prepared_inputs_v3.json'), read(HERE / 'plan_v3.json')
    verify(prepared['stage_bindings'] + prepared['dependency_bindings'])
    _, primary, supplement = predecessor_gate()
    assert plan == construct_plan(supplement)
    review = read(review_path)
    assert review['status'] == REVIEW_STATUS
    for field, name in (('runner_binding', 'run_active_axis_v3.py'), ('oracle_binding', 'original_active_oracle_v2.py'),
        ('plan_binding', 'plan_v3.json'), ('prepared_input_binding', 'prepared_inputs_v3.json'), ('schema_binding', 'output_schema_v3.json')):
        assert review[field] == bind(HERE / name), field
    assert {r['path']: r for r in review['reviewed_stage_bindings']} == {r['path']: r for r in prepared['stage_bindings']}
    verify(review['reviewed_stage_bindings'])
    before = verify(prepared['stage_bindings'] + prepared['dependency_bindings'] + [bind(HERE / 'prepared_inputs_v3.json'), bind(review_path)])
    save('run_inputs_v3.json', {'status': 'BOUND_BEFORE_ALL_UNKNOWN_SCOPE_ACTIVE_SOLVES', 'bindings': before})
    started = perf_counter()
    model = read(STUDY / 'bpi2013_model_IMf02.json')
    graph = oracle.original_graph(model['net_doc'], cap=10000)
    assert len(graph['markings']) == 145 and sum(map(len, graph['edges'])) == 637
    assert original_edge_set(graph['transitions'], graph) == original_edge_set(model['net_doc']['transitions'], model['graph'])
    variants, old_plan = rows(OLD / 'alignment_variants.jsonl'), read(OLD / 'alignment_plan.json')
    certificates, counts = {}, Counter()
    with (HERE / 'word_certificates_v3.jsonl').open('x', encoding='utf-8', newline='\n') as handle:
        for planned in plan['words']:
            certificate = certify_word(planned, variants[planned['variant_id']], graph)
            certificates[planned['variant_id']] = certificate
            counts['word_' + certificate['status']] += 1
            emit(handle, certificate)
            handle.flush()
            print(json.dumps({'words_completed': len(certificates), 'words_planned': len(plan['words']),
                'variant_id': planned['variant_id'], 'status': certificate['status'], 'elapsed_seconds': perf_counter() - started}), flush=True)
    saved_pairs = rows(OLD / 'alignment_pairs.jsonl')
    old_scope = {r['pair_id']: r for r in supplement['pair_certificates']}
    planned_pair_ids = {r['pair_id'] for r in plan['affected_pairs']}
    aggregates, case_sets, coverage, all_case_sets = defaultdict(Counter), defaultdict(set), defaultdict(Counter), defaultdict(set)
    with (HERE / 'affected_pair_certificates_v3.jsonl').open('x', encoding='utf-8', newline='\n') as affected_handle, (HERE / 'full_pair_scope_v3.jsonl').open('x', encoding='utf-8', newline='\n') as full_handle:
        for expected, saved in zip(old_plan['pairs'], saved_pairs):
            assert {k: saved[k] for k in expected} == expected
            before_snapshot, after_snapshot = old_plan['snapshots'][expected['before_snapshot_id']], old_plan['snapshots'][expected['after_snapshot_id']]
            bi, ai = before_snapshot['variant_id'], after_snapshot['variant_id']
            affected = expected['pair_id'] in planned_pair_ids
            newly_unavailable = any(certificates[vi]['status'] != 'CERTIFIED_ENTIRE_NONNEGATIVE_AFFINE_ACTIVE_COST_AND_RECORD_ROLES'
                for vi in (bi, ai) if vi in certificates)
            certified = not newly_unavailable if affected else old_scope[expected['pair_id']]['all_active_pair_role_sets_certified']
            if certified:
                result = pair_result(variants[bi]['affine_profile'], variants[ai]['affine_profile'],
                    certificates.get(bi), certificates.get(ai), before_snapshot['event_ids'], after_snapshot['event_ids'])
                compare_saved_pair(result, saved['rho_result'])
                status = 'CERTIFIED_FULL_ACTIVE_PAIR_WITH_SMALL_ORIGINAL_PRODUCT_SUPPLEMENT' if affected else 'CERTIFIED_EXISTING_PRIMARY_OR_D0_D1_ACTIVE_PAIR'
                categories = result['categories']
            else:
                result, categories, status = None, None, 'UNKNOWN_ACTIVE_PAIR_RETAINED'
            row = {**expected, 'status': status, 'active_only': True, 'categories': categories,
                'small_product_supplement_used': affected, 'dominated_fixed_K_scope_upgraded': False}
            emit(full_handle, row)
            if affected:
                emit(affected_handle, {**row, 'recomputed_result': result,
                    'before_scope': certificates[bi]['status'] if bi in certificates else old_scope[expected['pair_id']]['before_active_scope'],
                    'after_scope': certificates[ai]['status'] if ai in certificates else old_scope[expected['pair_id']]['after_active_scope']})
            for subset in ('full_1511', expected['source_subset']):
                aggregate = aggregates[subset]
                aggregate['pairs_in_denominator'] += 1
                aggregate['fully_active_certified_pairs' if certified else 'UNKNOWN_active_pairs'] += 1
                aggregate['small_product_affected_pairs'] += affected
                aggregate['normal_last_controls'] += expected['normal_last_record_control']
                all_case_sets[subset].add(expected['case'])
                key = subset + '__length_' + str(expected['original_event_count']) + '__' + ('normal_last' if expected['normal_last_record_control'] else 'earlier_record')
                coverage[key]['pairs_in_denominator'] += 1
                coverage[key]['fully_active_certified_pairs' if certified else 'UNKNOWN_active_pairs'] += 1
                if certified:
                    for category, flag in categories.items():
                        aggregate[category] += flag
                        coverage[key][category] += flag
                        if flag:
                            case_sets[subset + '__' + category].add(expected['case'])
    assert len(saved_pairs) == len(old_plan['pairs']) == 8735
    assert sum(1 for r in rows(HERE / 'affected_pair_certificates_v3.jsonl')) == len(plan['affected_pairs'])
    assert all(aggregates[s]['pairs_in_denominator'] == n for s, n in (('full_1511', 8735), ('original_128', 786), ('complementary_1383', 7949)))
    assert all(len(all_case_sets[s]) == n for s, n in (('full_1511', 1511), ('original_128', 128), ('complementary_1383', 1383)))
    after = verify(before)
    assert before == after
    full = aggregates['full_1511']
    report = {'status': 'PASS_SEPARATE_SMALL_ORIGINAL_PRODUCT_ACTIVE_AXIS_WITH_PRIOR_FIXED_K_LIMITS_PRESERVED',
        'created_at_utc': datetime.now(timezone.utc).isoformat(), 'planned_words': len(plan['words']), 'planned_pairs': len(plan['affected_pairs']),
        'counts': dict(counts), 'aggregate': {k: dict(v) for k, v in aggregates.items()},
        'category_case_ids': {k: sorted(v) for k, v in case_sets.items()}, 'category_case_counts': {k: len(v) for k, v in case_sets.items()},
        'coverage_by_subset_exact_length_and_control': {k: dict(v) for k, v in coverage.items()},
        'source_cases': {k: len(v) for k, v in all_case_sets.items()}, 'complete_positive_axis_plus_rho_zero': (
            len(certificates) == len(plan['words'])
            and all(row['status'] == 'CERTIFIED_ENTIRE_NONNEGATIVE_AFFINE_ACTIVE_COST_AND_RECORD_ROLES'
                for row in certificates.values())
            and full['fully_active_certified_pairs'] == full['pairs_in_denominator'] == 8735
            and full['UNKNOWN_active_pairs'] == 0),
        'full_active_pair_coverage_complete': full['fully_active_certified_pairs'] == 8735,
        'maximum_new_product_states': max((r.get('resource_counts', {}).get('product_states', 0) for r in certificates.values()), default=0),
        'maximum_rigorous_new_product_bound': max(r['rigorous_small_product_state_bound'] for r in plan['words']),
        'caps': {'original_markings': 10000, 'small_original_product': 100000},
        'prior_primary_68_LIMITs_and_37_active_unknown_word_histories_unchanged': True,
        'primary_dominated_fixed_K_cost_or_support_scope_upgraded': False,
        'all_active_count_sets_at_ties_claimed': False, 'preexecution_bindings': before, 'postexecution_bindings': after,
        'previous_certified_lambda_axis_unchanged': True, 'elapsed_seconds': perf_counter() - started,
        'business_truth_or_natural_rate_or_novelty_claimed': False, 'paper_or_guides_edited': False}
    save('summary_v3.json', report)
    text = '# Separate original small-product active-affine audit\n\n'
    text += f"Processed the complete prior-UNKNOWN selected scope: {len(plan['words'])} structural words and {len(plan['affected_pairs'])} affected original pairs. Full active pair coverage is {full['fully_active_certified_pairs']}/8735, with {full['UNKNOWN_active_pairs']} remaining UNKNOWN. All source and length/control denominators are retained.\n\n"
    text += 'Every certified finite interval has exact endpoint costs and an independently replayed feasible line; its whole open interval follows from concavity. Every certified infinite tail uses a separate lexicographic globally minimum K/D path certificate. Certified critical points and rho=0 have direct optimal-edge record-role unions. No finite parameter sample is promoted without these certificates.\n\n'
    text += f"Any positive-parameter same-cost revision: {full['any_positive_revision']} pairs; default rho=2: {full['default_revision']}. These are defined identity-summary changes, not natural error accuracy. The new representation has at most {report['maximum_new_product_states']} reachable states and rigorous bound {report['maximum_rigorous_new_product_bound']}, under unchanged100000 cap.\n\n"
    text += 'The original 68 explicit fixed-K LIMITs, prior UNKNOWN histories and all dominated fixed-K scope remain immutable. This supplement certifies active costs and record roles only; it does not certify all active count sets at ties. All old bindings match before/after. No manuscript or guide was edited.\n'
    with (HERE / 'readout_v3.md').open('x', encoding='utf-8', newline='\n') as handle:
        handle.write(text)
    print(json.dumps({'status': report['status'], 'counts': report['counts'], 'aggregate': report['aggregate'],
        'summary': bind(HERE / 'summary_v3.json'), 'elapsed_seconds': report['elapsed_seconds']}), flush=True)


def main():
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--prepare', action='store_true')
    group.add_argument('--run', action='store_true')
    parser.add_argument('--review', type=Path)
    args = parser.parse_args()
    if args.prepare:
        assert args.review is None
        prepare()
    else:
        assert args.review is not None and args.review.is_absolute() and args.review.is_file()
        run(args.review)


if __name__ == '__main__':
    try:
        main()
    except BaseException as exc:
        if not (HERE / 'failed_preparation_or_run_v3.json').exists():
            save('failed_preparation_or_run_v3.json', {'status': 'FAILED_PRESERVED_SMALL_PRODUCT_ACTIVE_STAGE',
                'type': type(exc).__name__, 'message': str(exc), 'traceback': traceback.format_exc()})
        raise
