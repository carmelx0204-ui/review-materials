"""Same-author raw-original-move calibration; no full-cohort solves."""
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path
import traceback

import original_active_oracle_v2 as target

HERE = Path(__file__).resolve().parent
FIELDS = ('possible_log_positions', 'possible_sync_positions', 'mandatory_log_positions',
          'forced_sync_positions', 'ambiguous_positions')


def serial(labels, silent_before=False, duplicate=False, zero_self=False):
    steps = ([None] if silent_before else []) + list(labels)
    places = ['p' + str(i) for i in range(len(steps) + 1)]
    transitions = []
    for i, label in enumerate(steps):
        pre, post = [0] * len(places), [0] * len(places)
        pre[i], post[i + 1] = 1, 1
        transitions.append({'id': 't%02d' % i, 'label': label, 'pre': pre, 'post': post})
    if duplicate:
        original = transitions[-1]
        transitions.append({**original, 'id': 'duplicate_' + original['id']})
    if zero_self:
        pre = [1] + [0] * (len(places) - 1)
        transitions.append({'id': 'tau_self', 'label': None, 'pre': pre, 'post': list(pre)})
    return {'name': 'calibration', 'places': places, 'initial': [1] + [0] * len(steps),
        'transitions': transitions}, [0] * len(steps) + [1]


def raw_paths(doc, word, final):
    """Finite DAG enumeration without product, shortest-path or target helpers."""
    accepted = []
    def explore(marking, pos, closed_gaps, opened_length, logged, synced, depth):
        assert depth <= len(word) + len(doc['transitions'])
        if pos == len(word) and (final is None or marking == tuple(final)):
            gaps = closed_gaps + ((opened_length,) if opened_length else ())
            accepted.append((tuple(sorted(gaps)), set(logged), set(synced)))
            assert len(accepted) <= 2000000
            # Keep enumerating original legal model/tau tails too.
        if pos < len(word):
            explore(marking, pos + 1, closed_gaps, opened_length + 1, logged + (pos,), synced, depth + 1)
        for transition in doc['transitions']:
            if any(a < b for a, b in zip(marking, transition['pre'])):
                continue
            successor = tuple(a - b + c for a, b, c in zip(marking, transition['pre'], transition['post']))
            if transition['label'] is None:
                explore(successor, pos, closed_gaps, opened_length, logged, synced, depth + 1)
            else:
                explore(successor, pos, closed_gaps, opened_length + 1, logged, synced, depth + 1)
                if pos < len(word) and transition['label'] == word[pos]:
                    gaps = closed_gaps + ((opened_length,) if opened_length else ())
                    explore(successor, pos + 1, gaps, 0, logged, synced + (pos,), depth + 1)
    explore(tuple(doc['initial']), 0, (), 0, (), (), 0)
    assert accepted
    return accepted


def raw_at(paths, rho, length):
    prices = [rho * len(gaps) + sum(gaps) for gaps, _, _ in paths]
    optimum = min(prices)
    winning = [p for p, price in zip(paths, prices) if price == optimum]
    logged, synced = set(), set()
    for _, l, s in winning:
        logged.update(l)
        synced.update(s)
    universe = set(range(length))
    return {'normalized_cost': {'numerator': optimum.numerator, 'denominator': optimum.denominator},
        'possible_log_positions': sorted(logged), 'possible_sync_positions': sorted(synced),
        'mandatory_log_positions': sorted(universe - synced), 'forced_sync_positions': sorted(universe - logged),
        'ambiguous_positions': sorted(logged & synced)}, sorted({(len(g), sum(g)) for g, _, _ in winning})


def binding(path):
    path = Path(path).resolve()
    b = path.read_bytes()
    return {'path': str(path), 'bytes': len(b), 'sha256': sha256(b).hexdigest()}


def save(name, doc):
    with (HERE / name).open('x', encoding='utf-8', newline='\n') as handle:
        json.dump(doc, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write('\n')


def main():
    assert not (HERE / 'calibration_v2.json').exists()
    inputs = [binding(HERE / name) for name in ('protocol.md', 'protocol_addendum_v3.md', 'prepare_runner_v3.py', 'versioned_repair_v3.json', 'original_active_oracle_v2.py', 'calibrate_original_active_oracle_v2.py')]
    fixtures = []
    for number, (labels, word, completed, silent, duplicate) in enumerate((
        (('A', 'B'), ('A', 'B'), False, False, False),
        (('A', 'B'), ('A', 'B'), True, False, False),
        (('A', 'B'), ('A',), False, False, False),
        (('A', 'B'), ('A',), True, False, False),
        (('A', 'B'), ('Z', 'A', 'B'), True, False, False),
        (('A', 'A'), ('A', 'A', 'A'), True, False, False),
        (('A', 'A'), ('A',), True, True, False),
        (('A', 'B'), ('Z', 'Z'), True, True, True),
        (('A', 'B'), (), False, False, False),
        (('A', 'B'), (), True, True, False),
        (('S', 'A', 'B', 'E'), ('S', 'A', 'A', 'E'), True, False, False),
        (('A', 'B', 'C'), ('A', 'X', 'C', 'Y'), True, False, False),
    )):
        doc, final = serial(labels, silent, duplicate)
        accepting = final if completed else None
        graph = target.original_graph(doc)
        product = target.build_product(graph, word, accepting)
        paths = raw_paths(doc, tuple(word), accepting)
        probes, reports = (Fraction(0), Fraction(1, 3), Fraction(1), Fraction(2), Fraction(3), Fraction(10)), []
        for rho in probes:
            expected, active_counts = raw_at(paths, rho, len(word))
            actual = target.scalar_and_roles(product, rho)
            assert {k: actual[k] for k in ('normalized_cost',) + FIELDS} == expected
            path = actual['independently_replayed_feasible_path']
            assert (path['K'], path['D']) in active_counts
            assert actual['product_states'] <= product['rigorous_bound'] <= 100000
            reports.append({'rho': [rho.numerator, rho.denominator], 'expected': expected,
                'raw_optimal_K_D_counts': [list(v) for v in active_counts], 'actual': actual})
        lexical = target.lexicographic_K_D(product)
        expected_lex = min((len(gaps), sum(gaps)) for gaps, _, _ in paths)
        assert (lexical['globally_minimum_K'], lexical['minimum_D_at_minimum_K']) == expected_lex
        fixtures.append({'fixture': number, 'doc': doc, 'word': list(word), 'final': accepting,
            'raw_accepted_paths': len(paths), 'checks': reports, 'lexicographic': lexical})
    doc, final = serial(('A', 'B', 'C'))
    breakpoint_product = target.build_product(target.original_graph(doc), ('A', 'X', 'C', 'Y'), final)
    finite = target.certify_finite_interval(breakpoint_product, 0, 2, 2, 3)
    tail = target.certify_unbounded_tail(breakpoint_product, 2, 1, 5)
    assert finite['interior_direct_answer']['mandatory_log_positions'] == [1, 3]
    assert tail['interior_direct_answer']['mandatory_log_positions'] == [1, 2, 3]
    assert target.scalar_and_roles(breakpoint_product, 2)['ambiguous_positions'] == [2]
    rejects = []
    for name, fn in (
        ('wrong_finite_envelope_across_real_breakpoint', lambda: target.certify_finite_interval(breakpoint_product, 0, 4, 2, 3)),
        ('infeasible_line_counts', lambda: target.certify_finite_interval(breakpoint_product, 0, 1, 1, 3)),
        ('unbounded_tail_wrong_minimum_K', lambda: target.certify_unbounded_tail(breakpoint_product, 0, 2, 3)),
        ('negative_rho', lambda: target.scalar_and_roles(breakpoint_product, -1)),
        ('empty_or_reversed_interval', lambda: target.certify_finite_interval(breakpoint_product, 2, 2, 1, 5)),
    ):
        try:
            fn()
        except AssertionError:
            rejects.append(name)
        else:
            raise AssertionError(('False proof accepted', name))
    cyclic_doc, cyclic_final = serial(('A', 'B'), zero_self=True)
    plain_doc, plain_final = serial(('A', 'B'))
    cyclic = target.build_product(target.original_graph(cyclic_doc), ('A', 'Z', 'B'), cyclic_final)
    plain = target.build_product(target.original_graph(plain_doc), ('A', 'Z', 'B'), plain_final)
    cycle_checks = []
    for rho in (Fraction(0), Fraction(1, 2), Fraction(2), Fraction(9)):
        with_loop = target.scalar_and_roles(cyclic, rho)
        no_loop = target.scalar_and_roles(plain, rho)
        assert {k: with_loop[k] for k in ('normalized_cost',) + FIELDS} == {k: no_loop[k] for k in ('normalized_cost',) + FIELDS}
        cycle_checks.append({'rho': [rho.numerator, rho.denominator], 'loop_answer': with_loop})
    cap_check = target.build_product(target.original_graph(plain_doc), ('A', 'Z', 'B'), plain_final, cap=23)
    assert cap_check['status'] == 'LIMIT_RIGOROUS_FULL_PRODUCT_BOUND' and cap_check['rigorous_bound'] == 24
    after = [binding(r['path']) for r in inputs]
    assert inputs == after
    result = {'status': 'PASS_SAME_AUTHOR_RAW_MOVE_SCALAR_ROLE_LEX_INTERVAL_TAIL_AND_ZERO_CYCLE_CALIBRATION',
        'fixtures': fixtures, 'raw_DAG_fixtures': len(fixtures), 'raw_scalar_role_checks': sum(len(f['checks']) for f in fixtures),
        'raw_lexicographic_checks': len(fixtures), 'raw_accepted_paths': sum(f['raw_accepted_paths'] for f in fixtures),
        'real_positive_breakpoint': {'rho': [2, 1], 'finite': finite, 'tail': tail},
        'zero_silent_cycle_checks': cycle_checks, 'invalid_proofs_rejected': rejects, 'cap_guard': cap_check,
        'inputs_before': inputs, 'inputs_after': after, 'formal_cohort_solve_started': False,
        'external_independent_review_claimed': False, 'paper_or_guides_edited': False}
    save('calibration_v2.json', result)
    print(json.dumps({'status': result['status'], 'raw_DAG_fixtures': len(fixtures),
        'raw_scalar_role_checks': result['raw_scalar_role_checks'], 'raw_accepted_paths': result['raw_accepted_paths'],
        'invalid_proofs_rejected': len(rejects), 'calibration': binding(HERE / 'calibration_v2.json')}), flush=True)


if __name__ == '__main__':
    try:
        main()
    except BaseException as exc:
        if not (HERE / 'calibration_failure_v2.json').exists():
            save('calibration_failure_v2.json', {'status': 'FAILED_PRESERVED_PREEXECUTION_CALIBRATION',
                'type': type(exc).__name__, 'message': str(exc), 'traceback': traceback.format_exc()})
        raise
