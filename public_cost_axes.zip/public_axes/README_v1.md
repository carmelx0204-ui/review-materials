# Full public parameter-axis reconstruction

Use Python 3.11 or later and its standard library only. Each output directory must be new.

```
python -B -X utf8 rebuild_axes_v1.py --prepare --output fresh_prepare
python -B -X utf8 rebuild_axes_v1.py --pilot --output fresh_pilot
python -B -X utf8 rebuild_axes_v1.py --run --output fresh_full_run
```

The formal entrypoint reconstructs the full public population: 1511 cases, 8735 records, 3011 distinct words, 10246 occurrence-ID snapshots and 8735 restoration pairs, including 1511 normal-last controls. The original learned integer-arc reference is rebuilt with all 145 reachable markings and 637 original firings; PREFIX accepts any original marking after all observations are consumed. Silent original transitions cost zero and preserve the current gap.

For weighted costs, the exact independent original count-product and layered dynamic program rebuild every fixed LOG-count minimum MODEL cost. Original-arc forbidden-edge searches independently recover complete record-role support at every positive-envelope critical point/open interval and lambda=1. The complete integer line family then proves the whole lambda=LOG/MODEL>0 axis. This does not claim independent recovery of inactive fixed-count role fields.

For affine costs D+rho*K, fresh weighted lambda=1 unit cost and complete support provide the already frozen D0/D1 proof: D0 has K=D=0; D1 paths have K=D=1 and every other path has D>=2,K>=1. Their complete optimum sets and per-record roles therefore remain the unit optimum sets for every rho>=0. Every D>=2 word receives a fresh original small-product scalar/role solve, endpoint/chord proof for each finite interval and a lexicographic proof for its unbounded tail. All 3011 words are covered; no historical certificate exempts a difficult word. Complete cell/point/zero/default costs, per-ID roles, gains/withdrawals and categories are rebuilt for all 8735 pairs and compared with frozen evidence. Historical 68 fixed-K LIMITs remain historical; dominated rows and all active count tuples at ties are not upgraded by this entrypoint.

The allowlist manifest distinguishes exact source-byte copies, JSON path-key/value anonymization with collision rejection, and new portable adapters. Each mathematical function is checked against the shipped frozen source using exact bytes and AST; fresh headers/dispatch/guards receive separate hashes. Archival embedded bindings are source records and are never followed to installed dependencies. No native core, optimizer, third-party package, network service or external workspace is opened.

Platform contract: original marking cap10000 and product cap100000 are preserved. Before every total-order weighted scalar solve, the full (n+1)*markings bound is checked. New elapsed-wall guards run after atomic per-word weighted or affine calls (200 seconds) and after each call against the combined full run clock (7200 seconds). These are post-call checks, not process preemption. There is no sampled or hard OS memory guard and no historical-platform resource-equivalence claim. Actual terminals and actual measured timings alone establish execution on a named platform. The pilot selects first variants by lengths0,6,13,26,40, independently of measured positive outcomes; pilot success is not full-scope completion.

Failures preserve partial exclusive journals and failure evidence. Append a new version for source repairs; choose a fresh output directory for a new invocation. Public unit/gap-function proofs, actual author execution and finite COMPLETED matrices have separate entrypoints and scope.
