from collections import Counter, defaultdict, deque
from fractions import Fraction
import heapq
MODEL_LIMIT=10000
PRODUCT_LIMIT=100000
FIELDS=("possible_log_ids","mandatory_log_ids","forced_sync_ids","ambiguous_consumption_ids")


def q(value):
    return None if value is None else {"numerator": value.numerator, "denominator": value.denominator}


def fixed_count_product(transitions, graph, word, cap=PRODUCT_LIMIT):
    """Cap the complete original (i, marking, j) state set before layered DP."""
    states = [(0, 0, 0)]
    indices = {states[0]: 0}
    pending = deque([0])
    edges, reverse = [], [[]]
    while pending:
        u = pending.popleft()
        position, marking, logs = states[u]
        moves = []
        if position < len(word):
            moves.append(((position + 1, marking, logs + 1), 0))
        for ti, target in graph["edges"][marking]:
            label = transitions[ti]["label"]
            moves.append(((position, target, logs), int(label is not None)))
            if position < len(word) and label is not None and label == word[position]:
                moves.append(((position + 1, target, logs), 0))
        outgoing = []
        for successor, weight in moves:
            if successor not in indices:
                if len(states) >= cap:
                    return {"status": "LIMIT_INDEPENDENT_WEIGHTED_COUNT_PRODUCT", "reached_product_states": len(states), "state_cap": cap}
                indices[successor] = len(states)
                states.append(successor)
                pending.append(indices[successor])
                reverse.append([])
            v = indices[successor]
            outgoing.append((v, weight))
            reverse[v].append((u, weight))
        edges.append(outgoing)
    endpoints = [[] for _ in range(len(word) + 1)]
    for u, (position, marking, logs) in enumerate(states):
        if position == len(word):
            endpoints[logs].append(u)
    return {"status": "COMPLETE_ORIGINAL_WEIGHTED_COUNT_PRODUCT", "states": states,
            "edges": edges, "endpoints": endpoints}


def weighted_contract(profile, word):
    assert profile["state_limit"] == PRODUCT_LIMIT
    assert profile["event_count"] == len(word)
    ids = ["v%06d" % i for i in range(len(word))]
    assert profile["event_ids"] == ids and len(set(ids)) == len(ids)
    assert profile["acceptance"] == "prefix_any_marking" and profile["final"] is None
    assert profile["product_states"] <= PRODUCT_LIMIT
    if profile["status"] != "EXACT":
        assert profile["status"] == "LIMIT" and "entries" not in profile
        return
    assert len(profile["entries"]) == len(word) + 1
    feasible = []
    for j, entry in enumerate(profile["entries"]):
        assert entry["log_count"] == j
        if not entry["feasible"]:
            assert entry["model_count"] is None and all(entry[field] is None for field in FIELDS)
            continue
        feasible.append(j)
        assert type(entry["model_count"]) is int and entry["model_count"] >= 0
        sets = {field: set(entry[field]) for field in FIELDS}
        assert all(entry[field] == sorted(sets[field]) for field in FIELDS)
        possible, mandatory = sets["possible_log_ids"], sets["mandatory_log_ids"]
        assert mandatory <= possible <= set(ids)
        assert sets["forced_sync_ids"] == set(ids) - possible
        assert sets["ambiguous_consumption_ids"] == possible - mandatory
        assert len(mandatory) <= j <= len(possible)
    assert feasible == profile["feasible_log_counts"] and feasible


def lines(profile, objective):
    if objective == "lambda":
        return [(entry["log_count"], entry["model_count"]) for entry in profile["entries"] if entry["feasible"]]
    return [(entry["gap_count"], entry["minimum_total_deviations"]) for entry in profile["entries"]]


def at(profile, objective, value, ids):
    if objective == "lambda":
        feasible = [entry for entry in profile["entries"] if entry["feasible"]]
        optimum = min(value * entry["log_count"] + entry["model_count"] for entry in feasible)
        active = [entry for entry in feasible if value * entry["log_count"] + entry["model_count"] == optimum]
        structural = {"v%06d" % i: event_id for i, event_id in enumerate(ids)}
        possible = set().union(*(set(entry["possible_log_ids"]) for entry in active))
        mandatory = set.intersection(*(set(entry["mandatory_log_ids"]) for entry in active))
        all_ids = set(structural)
        roles = {"possible_log_ids": possible, "mandatory_log_ids": mandatory,
                 "forced_sync_ids": all_ids - possible, "ambiguous_consumption_ids": possible - mandatory}
        return {"normalized_cost": q(optimum),
                "active_counts": [[entry["log_count"], entry["model_count"]] for entry in active],
                **{field: sorted(structural[event_id] for event_id in answer) for field, answer in roles.items()}}
    optimum = min(value * entry["gap_count"] + entry["minimum_total_deviations"] for entry in profile["entries"])
    active = [entry for entry in profile["entries"] if value * entry["gap_count"] + entry["minimum_total_deviations"] == optimum]
    possible = set().union(*(set(entry["possible_log_positions"]) for entry in active))
    synced = set().union(*(set(entry["possible_sync_positions"]) for entry in active))
    universe = set(range(len(ids)))
    roles = {"possible_log_ids": possible, "mandatory_log_ids": universe - synced,
             "possible_sync_ids": synced, "forced_sync_ids": universe - possible,
             "ambiguous_consumption_ids": possible & synced}
    return {"normalized_cost": q(optimum),
            "active_counts": [[entry["gap_count"], entry["minimum_total_deviations"]] for entry in active],
            **{field: sorted(ids[i] for i in answer) for field, answer in roles.items()}}


def change(before, after, common):
    bp, ap = set(before["possible_log_ids"]) & common, set(after["possible_log_ids"]) & common
    bm, am = set(before["mandatory_log_ids"]) & common, set(after["mandatory_log_ids"]) & common
    same = before["normalized_cost"] == after["normalized_cost"]
    return {"same_cost": same, "old_possible_changed": bp != ap, "old_mandatory_changed": bm != am,
            "same_cost_old_summary_revision": same and (bp != ap or bm != am),
            "possible_gained": sorted(ap - bp), "possible_withdrawn": sorted(bp - ap),
            "mandatory_gained": sorted(am - bm), "mandatory_withdrawn": sorted(bm - am)}


def joint(before, after, bids, aids, objective, weighted):
    exact = "EXACT" if objective == "lambda" else "EXACT_FIXED_GAP_COUNT_PROFILE"
    if before["status"] != exact or after["status"] != exact:
        return {"status": "UNAVAILABLE_CONSTITUENT_PROFILE", "before_status": before["status"], "after_status": after["status"]}
    points, _ = weighted["pair_points"](lines(before, objective), lines(after, objective))
    cells = []
    for left, right, probe in weighted["samples"](points):
        b, a = at(before, objective, probe, bids), at(after, objective, probe, aids)
        delta = change(b, a, set(bids))
        if delta["same_cost"]:
            assert b["active_counts"] == a["active_counts"]
        cells.append({"kind": "open_interval", "left": q(left), "right": q(right), "probe": q(probe),
                      "before": b, "after": a, **delta})
        if right is not None:
            b, a = at(before, objective, right, bids), at(after, objective, right, aids)
            cells.append({"kind": "point", "ratio": q(right), "before": b, "after": a, **change(b, a, set(bids))})
    classic_ratio, default_ratio = (Fraction(1), Fraction(1)) if objective == "lambda" else (Fraction(0), Fraction(2))
    endpoints = {}
    for name, value in (("classic", classic_ratio), ("default", default_ratio)):
        b, a = at(before, objective, value, bids), at(after, objective, value, aids)
        endpoints[name] = {"ratio": q(value), "before": b, "after": a, **change(b, a, set(bids))}
    open_effect = any(cell["same_cost_old_summary_revision"] for cell in cells if cell["kind"] == "open_interval")
    point_effect = any(cell["same_cost_old_summary_revision"] for cell in cells if cell["kind"] == "point")
    categories = {"any_positive_revision": open_effect or point_effect,
        "all_positive_revision": all(cell["same_cost_old_summary_revision"] for cell in cells),
        "open_interval_revision": open_effect, "point_revision": point_effect,
        "isolated_only_revision": point_effect and not open_effect,
        "classic_revision": endpoints["classic"]["same_cost_old_summary_revision"],
        "default_revision": endpoints["default"]["same_cost_old_summary_revision"]}
    return {"status": "EXACT_ALL_POSITIVE_PARAMETER_CELLS", "parameter": objective,
            "critical_points": [q(point) for point in points], "cells": cells, **endpoints, "categories": categories}


def make_plan(cases, original_ids):
    variants, indices, snapshots, pairs = [], {}, [], []
    def snapshot(case, events, kind, position):
        word = tuple(e["concept"] for e in events)
        if word not in indices:
            indices[word] = len(variants)
            variants.append({"variant_id": len(variants), "word": list(word), "event_count": len(word)})
        result = {"snapshot_id": len(snapshots), "case": case["id"], "kind": kind,
            "delayed_position": position, "variant_id": indices[word], "event_ids": [e["id"] for e in events],
            "original_event_count": len(case["events"]),
            "source_subset": "original_128" if case["id"] in original_ids else "complementary_1383"}
        snapshots.append(result)
        return result
    for case in cases:
        events = sorted(case["events"], key=lambda e: (e["timestamp_us"], e["xml_index"]))
        after = snapshot(case, events, "after", None)
        for position, event in enumerate(events):
            before = snapshot(case, events[:position] + events[position + 1:], "before", position)
            pairs.append({"pair_id": len(pairs), "case": case["id"], "delayed_position": position,
                "delayed_record_id": event["id"], "normal_last_record_control": position == len(events) - 1,
                "original_event_count": len(events), "source_subset": after["source_subset"],
                "before_snapshot_id": before["snapshot_id"], "after_snapshot_id": after["snapshot_id"]})
    return {"status": "FULL_POPULATION_PLANNED_BEFORE_SOLVING", "marking_cap": MODEL_LIMIT,
        "weighted_product_cap": PRODUCT_LIMIT, "affine_anchor_cap": PRODUCT_LIMIT,
        "independent_explicit_product_cap": PRODUCT_LIMIT, "cases": 1511, "events": 8735,
        "variants": variants, "snapshots": snapshots, "pairs": pairs, "D0_D1_pruning_used": False}

