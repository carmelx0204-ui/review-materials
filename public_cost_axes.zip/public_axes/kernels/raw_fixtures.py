from collections import Counter, defaultdict, deque
from fractions import Fraction
import heapq
FIELDS=("possible_log_positions","possible_sync_positions","mandatory_log_positions","forced_sync_positions","ambiguous_positions")


def serial(labels, silent_before=False, duplicate=False, zero_self=False):
    steps = ([None] if silent_before else []) + list(labels)
    places = ['p' + str(i) for i in range(len(steps) + 1)]
    transitions = []
    for i, label in enumerate(steps):
        pre, post = [0] * len(places), [0] * len(places)
        pre[i], post[i + 1] = 1, 1
        transitions.append({'id': 't%02d' % i, 'label': label, 'pre': pre, 'post': post})
    if duplicate:
        original = transitions[-1]
        transitions.append({**original, 'id': 'duplicate_' + original['id']})
    if zero_self:
        pre = [1] + [0] * (len(places) - 1)
        transitions.append({'id': 'tau_self', 'label': None, 'pre': pre, 'post': list(pre)})
    return {'name': 'calibration', 'places': places, 'initial': [1] + [0] * len(steps),
        'transitions': transitions}, [0] * len(steps) + [1]


def raw_paths(doc, word, final):
    """Finite DAG enumeration without product, shortest-path or target helpers."""
    accepted = []
    def explore(marking, pos, closed_gaps, opened_length, logged, synced, depth):
        assert depth <= len(word) + len(doc['transitions'])
        if pos == len(word) and (final is None or marking == tuple(final)):
            gaps = closed_gaps + ((opened_length,) if opened_length else ())
            accepted.append((tuple(sorted(gaps)), set(logged), set(synced)))
            assert len(accepted) <= 2000000
            # Keep enumerating original legal model/tau tails too.
        if pos < len(word):
            explore(marking, pos + 1, closed_gaps, opened_length + 1, logged + (pos,), synced, depth + 1)
        for transition in doc['transitions']:
            if any(a < b for a, b in zip(marking, transition['pre'])):
                continue
            successor = tuple(a - b + c for a, b, c in zip(marking, transition['pre'], transition['post']))
            if transition['label'] is None:
                explore(successor, pos, closed_gaps, opened_length, logged, synced, depth + 1)
            else:
                explore(successor, pos, closed_gaps, opened_length + 1, logged, synced, depth + 1)
                if pos < len(word) and transition['label'] == word[pos]:
                    gaps = closed_gaps + ((opened_length,) if opened_length else ())
                    explore(successor, pos + 1, gaps, 0, logged, synced + (pos,), depth + 1)
    explore(tuple(doc['initial']), 0, (), 0, (), (), 0)
    assert accepted
    return accepted


def raw_at(paths, rho, length):
    prices = [rho * len(gaps) + sum(gaps) for gaps, _, _ in paths]
    optimum = min(prices)
    winning = [p for p, price in zip(paths, prices) if price == optimum]
    logged, synced = set(), set()
    for _, l, s in winning:
        logged.update(l)
        synced.update(s)
    universe = set(range(length))
    return {'normalized_cost': {'numerator': optimum.numerator, 'denominator': optimum.denominator},
        'possible_log_positions': sorted(logged), 'possible_sync_positions': sorted(synced),
        'mandatory_log_positions': sorted(universe - synced), 'forced_sync_positions': sorted(universe - logged),
        'ambiguous_positions': sorted(logged & synced)}, sorted({(len(g), sum(g)) for g, _, _ in winning})

