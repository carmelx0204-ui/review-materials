from collections import Counter, defaultdict, deque
from fractions import Fraction
import heapq


def own_graph(doc):
    """Rebuild original marking graph directly from input/output arc vectors."""
    transitions = sorted(doc['transitions'], key=lambda t: t['id'])
    initial = tuple(doc['initial'])
    markings = [initial]
    index = {initial: 0}
    pending = deque([0])
    edges = []
    while pending:
        source = pending.popleft()
        marking = markings[source]
        outgoing = []
        for ti, transition in enumerate(transitions):
            if not all(a >= b for a, b in zip(marking, transition['pre'])):
                continue
            target = tuple(a - b + c for a, b, c in
                           zip(marking, transition['pre'], transition['post']))
            if target not in index:
                assert len(markings) < 10000
                index[target] = len(markings)
                markings.append(target)
                pending.append(index[target])
            outgoing.append((ti, index[target]))
        edges.append(outgoing)
    return transitions, {'markings': markings, 'edges': edges}


def edge_set(transitions, graph):
    return {(tuple(graph['markings'][u]), transitions[ti]['id'],
             tuple(graph['markings'][v]))
            for u, outgoing in enumerate(graph['edges']) for ti, v in outgoing}


def closure(seeds, model_edges, counts):
    """Independent within-layer closure; no event-consuming edges here."""
    distance = list(seeds)
    queue = [(cost, marking) for marking, cost in enumerate(distance) if cost is not None]
    heapq.heapify(queue)
    while queue:
        cost, source = heapq.heappop(queue)
        if distance[source] != cost:
            continue
        counts['layer_closure_settled_markings'] += 1
        for target, weight in model_edges[source]:
            candidate = cost + weight
            if distance[target] is None or candidate < distance[target]:
                distance[target] = candidate
                heapq.heappush(queue, (candidate, target))
    return distance


def layered_minimum_models(transitions, graph, events, counts):
    """DP(i,j,marking), accepting any marking after the final event."""
    width = len(graph['markings'])
    model_edges = [[(target, int(transitions[ti]['label'] is not None))
                    for ti, target in outgoing] for outgoing in graph['edges']]
    sync_by_label = defaultdict(lambda: [[] for _ in range(width)])
    for source, outgoing in enumerate(graph['edges']):
        for ti, target in outgoing:
            label = transitions[ti]['label']
            if label is not None:
                sync_by_label[label][source].append(target)
    layers = [[None] * width]
    layers[0][0] = 0
    for i in range(len(events) + 1):
        closed = [closure(seeds, model_edges, counts) for seeds in layers]
        counts['layer_closure_jobs'] += len(closed)
        if i == len(events):
            minima = [min((v for v in row if v is not None), default=None) for row in closed]
            counts['layered_profile_jobs'] += 1
            return minima
        following = [[None] * width for _ in range(i + 2)]
        sync_edges = sync_by_label[events[i]['concept']]
        for j, distance in enumerate(closed):
            for marking, cost in enumerate(distance):
                if cost is None:
                    continue
                previous = following[j + 1][marking]
                if previous is None or cost < previous:
                    following[j + 1][marking] = cost
                for target in sync_edges[marking]:
                    previous = following[j][target]
                    if previous is None or cost < previous:
                        following[j][target] = cost
        layers = following
    raise AssertionError('Unreachable DP end')


def active_interval(line, lines):
    """Intersection of affine half-planes for this line to be minimal."""
    j, m = line
    left, right = Fraction(0), None
    for other_j, other_m in lines:
        delta = j - other_j
        if delta == 0:
            if m > other_m:
                return None
            continue
        boundary = Fraction(other_m - m, delta)
        if delta > 0:
            right = boundary if right is None else min(right, boundary)
        else:
            left = max(left, boundary)
    if right is not None and (right <= 0 or right < left):
        return None
    return left, right


def envelope_points(lines):
    points = set()
    for line in lines:
        interval = active_interval(line, lines)
        if interval is None:
            continue
        left, right = interval
        if left > 0:
            points.add(left)
        if right is not None and right > 0:
            points.add(right)
    return sorted(points)


def active_lines(lines, ratio):
    minimum = min(j * ratio + m for j, m in lines)
    return sorted([(j, m) for j, m in lines if j * ratio + m == minimum])


def samples(points):
    bounds = [Fraction(0)] + sorted(points) + [None]
    return [(left, right, (left + right) / 2 if right is not None else left + 1)
            for left, right in zip(bounds, bounds[1:])]


def pair_points(before_lines, after_lines):
    """First partition individual envelopes, then solve equality per cell."""
    individual = sorted(set(envelope_points(before_lines)) | set(envelope_points(after_lines)))
    additions = set()
    for left, right, sample in samples(individual):
        a = active_lines(before_lines, sample)
        b = active_lines(after_lines, sample)
        assert len(a) == len(b) == 1
        ja, ma = a[0]
        jb, mb = b[0]
        if ja != jb:
            equality = Fraction(mb - ma, ja - jb)
            if equality > left and (right is None or equality < right):
                assert equality > 0
                additions.add(equality)
    return sorted(set(individual) | additions), sorted(additions)


def profile_at_saved(profile, ratio):
    feasible = [e for e in profile['entries'] if e['feasible']]
    lcost, mcost = ratio.numerator, ratio.denominator
    optimum = min(lcost * e['log_count'] + mcost * e['model_count'] for e in feasible)
    best = [e for e in feasible if lcost * e['log_count'] + mcost * e['model_count'] == optimum]
    possible = set().union(*(set(e['possible_log_ids']) for e in best))
    mandatory = set(best[0]['mandatory_log_ids'])
    for e in best[1:]:
        mandatory &= set(e['mandatory_log_ids'])
    return {'cost': optimum, 'possible_log_ids': sorted(possible),
            'mandatory_log_ids': sorted(mandatory),
            'forced_sync_ids': sorted(set(profile['event_ids']) - possible),
            'ambiguous_consumption_ids': sorted(possible - mandatory)}

