from collections import Counter, defaultdict, deque
from fractions import Fraction
import heapq
FIELDS=("possible_log_ids","mandatory_log_ids","forced_sync_ids","ambiguous_consumption_ids")


def rational(value):
    return {"numerator": value.numerator, "denominator": value.denominator}


def proof_at(unit, value, ids):
    assert unit["cost"] in (0, 1) and value >= 0
    source_ids = ["v%06d" % i for i in range(len(ids))]
    mapping = dict(zip(source_ids, ids))
    roles = {field: sorted(mapping[event_id] for event_id in unit[field]) for field in FIELDS}
    roles["possible_sync_ids"] = sorted(set(ids) - set(roles["mandatory_log_ids"]))
    return {"normalized_cost": rational(Fraction(0) if unit["cost"] == 0 else value + 1),
            "active_counts": [[0, 0]] if unit["cost"] == 0 else [[1, 1]], **roles}

