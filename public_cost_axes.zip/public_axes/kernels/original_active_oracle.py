from collections import Counter, defaultdict, deque
from fractions import Fraction
import heapq


def integer(value):
    assert isinstance(value, int) and not isinstance(value, bool) and value >= 0
    return value


def original_graph(doc, cap=10000):
    transitions = sorted(doc['transitions'], key=lambda t: t['id'])
    width = len(doc['places'])
    assert len({t['id'] for t in transitions}) == len(transitions)
    assert len(doc['initial']) == width and all(integer(v) == v for v in doc['initial'])
    for t in transitions:
        assert len(t['pre']) == len(t['post']) == width
        assert all(integer(v) == v for v in t['pre'] + t['post'])
        assert t['label'] is None or isinstance(t['label'], str)
    markings, lookup, pending, edges = [tuple(doc['initial'])], {tuple(doc['initial']): 0}, deque([0]), []
    while pending:
        u = pending.popleft()
        outgoing = []
        for ti, t in enumerate(transitions):
            if any(markings[u][i] < t['pre'][i] for i in range(width)):
                continue
            target = tuple(markings[u][i] - t['pre'][i] + t['post'][i] for i in range(width))
            if target not in lookup:
                if len(markings) == cap:
                    return {'status': 'LIMIT_ORIGINAL_MARKINGS', 'markings_reached': len(markings), 'cap': cap}
                lookup[target] = len(markings)
                markings.append(target)
                pending.append(lookup[target])
            outgoing.append((ti, lookup[target]))
        edges.append(outgoing)
    return {'status': 'EXACT_ORIGINAL_GRAPH', 'transitions': transitions, 'markings': markings,
        'lookup': lookup, 'edges': edges}


def build_product(graph, word, final=None, cap=100000):
    assert graph['status'] == 'EXACT_ORIGINAL_GRAPH'
    word = tuple(word)
    assert all(isinstance(label, str) for label in word)
    rigorous_bound = 2 * (len(word) + 1) * len(graph['markings'])
    if rigorous_bound > cap:
        return {'status': 'LIMIT_RIGOROUS_FULL_PRODUCT_BOUND', 'rigorous_bound': rigorous_bound, 'cap': cap}
    if final is not None and tuple(final) not in graph['lookup']:
        return {'status': 'UNREACHABLE_ORIGINAL_FINAL', 'rigorous_bound': rigorous_bound, 'cap': cap}
    end_mi = None if final is None else graph['lookup'][tuple(final)]
    states, lookup, pending, outgoing = [(0, 0, False)], {(0, 0, False): 0}, deque([0]), []
    while pending:
        u = pending.popleft()
        i, mi, opened = states[u]
        candidates = []
        if i < len(word):
            candidates.append(((i + 1, mi, True), {'kind': 'log', 'event_position': i,
                'transition_id': None, 'deltaK': int(not opened), 'deltaD': 1}))
        for ti, target_mi in graph['edges'][mi]:
            t = graph['transitions'][ti]
            if t['label'] is None:
                candidates.append(((i, target_mi, opened), {'kind': 'silent', 'event_position': None,
                    'transition_id': t['id'], 'deltaK': 0, 'deltaD': 0}))
            else:
                candidates.append(((i, target_mi, True), {'kind': 'model', 'event_position': None,
                    'transition_id': t['id'], 'deltaK': int(not opened), 'deltaD': 1}))
                if i < len(word) and t['label'] == word[i]:
                    candidates.append(((i + 1, target_mi, False), {'kind': 'sync', 'event_position': i,
                        'transition_id': t['id'], 'deltaK': 0, 'deltaD': 0}))
        edges = []
        for target, edge in candidates:
            if target not in lookup:
                if len(states) == cap:
                    return {'status': 'LIMIT_REACHABLE_ORIGINAL_PRODUCT', 'states_reached': len(states),
                        'rigorous_bound': rigorous_bound, 'cap': cap}
                lookup[target] = len(states)
                states.append(target)
                pending.append(lookup[target])
            edges.append((lookup[target], edge))
        outgoing.append(edges)
    incoming = [[] for _ in states]
    for u, edges in enumerate(outgoing):
        for v, edge in edges:
            incoming[v].append((u, edge))
    ends = {index for index, (i, mi, _) in enumerate(states)
        if i == len(word) and (end_mi is None or mi == end_mi)}
    return {'status': 'EXACT_SMALL_ORIGINAL_PRODUCT', 'word': word, 'states': states, 'outgoing': outgoing,
        'incoming': incoming, 'ends': ends, 'final': tuple(final) if final is not None else None,
        'rigorous_bound': rigorous_bound, 'cap': cap, 'original_graph': graph}


def shortest(adjacency, sources, rho=None, lexicographic=False):
    if lexicographic:
        zero = (0, 0)
    else:
        rho = Fraction(rho)
        assert rho >= 0
        zero = Fraction(0)
    distances, parents = [None] * len(adjacency), {}
    heap = []
    for source in sorted(sources):
        distances[source] = zero
        heapq.heappush(heap, (zero, source))
    while heap:
        distance, u = heapq.heappop(heap)
        if distance != distances[u]:
            continue
        for edge_index, (v, edge) in enumerate(adjacency[u]):
            candidate = (distance[0] + edge['deltaK'], distance[1] + edge['deltaD']) if lexicographic else distance + edge['deltaD'] + rho * edge['deltaK']
            if distances[v] is None or candidate < distances[v]:
                distances[v] = candidate
                parents[v] = (u, edge_index)
                heapq.heappush(heap, (candidate, v))
    return distances, parents


def witness(product, parents, terminal):
    cursor, chain, visited = terminal, [], set()
    while cursor != 0:
        assert cursor not in visited and cursor in parents
        visited.add(cursor)
        source, edge_index = parents[cursor]
        target, edge = product['outgoing'][source][edge_index]
        assert target == cursor
        chain.append({'source_state': source, 'target_state': cursor, **edge})
        cursor = source
    chain.reverse()
    replayed = replay(product, chain)
    return {'moves': chain, **replayed}


def replay(product, moves):
    graph, word = product['original_graph'], product['word']
    transitions = {t['id']: t for t in graph['transitions']}
    marking, i, opened = tuple(graph['markings'][0]), 0, False
    K = D = length = 0
    histogram, logged, synced = [], [], []
    cursor = 0
    for move in moves:
        assert move['source_state'] == cursor
        state = product['states'][cursor]
        assert state == (i, graph['lookup'][marking], opened)
        kind = move['kind']
        assert kind in ('log', 'sync', 'model', 'silent')
        expected_k, expected_d = 0, 0
        if kind in ('log', 'sync'):
            assert i < len(word) and move['event_position'] == i
        else:
            assert move['event_position'] is None
        if kind == 'log':
            assert move['transition_id'] is None
            expected_k, expected_d = int(not opened), 1
            logged.append(i)
            i += 1
            length += 1
            opened = True
        else:
            t = transitions[move['transition_id']]
            assert all(marking[p] >= t['pre'][p] for p in range(len(marking)))
            if kind == 'sync':
                assert t['label'] is not None and t['label'] == word[i]
                if length:
                    histogram.append(length)
                length, opened = 0, False
                synced.append(i)
                i += 1
            elif kind == 'model':
                assert t['label'] is not None
                expected_k, expected_d = int(not opened), 1
                length += 1
                opened = True
            else:
                assert t['label'] is None
            marking = tuple(marking[p] - t['pre'][p] + t['post'][p] for p in range(len(marking)))
        assert (move['deltaK'], move['deltaD']) == (expected_k, expected_d)
        assert any(target == move['target_state'] and edge == {key: move[key] for key in edge}
                   for target, edge in product['outgoing'][cursor])
        K, D = K + expected_k, D + expected_d
        cursor = move['target_state']
        assert product['states'][cursor] == (i, graph['lookup'][marking], opened)
    if length:
        histogram.append(length)
    assert i == len(word) and cursor in product['ends']
    assert K == len(histogram) and D == sum(histogram)
    assert sorted(logged + synced) == list(range(len(word)))
    return {'K': K, 'D': D, 'gap_histogram': histogram, 'logged_positions': logged,
        'synced_positions': synced, 'terminal_original_marking': list(marking), 'terminal_gap_open': opened}


def scalar_and_roles(product, rho):
    if product['status'] != 'EXACT_SMALL_ORIGINAL_PRODUCT':
        return {**product, 'active_cost_or_roles_certified': False}
    rho = Fraction(rho)
    assert rho >= 0
    forward, parents = shortest(product['outgoing'], {0}, rho)
    viable = [terminal for terminal in product['ends'] if forward[terminal] is not None]
    if not viable:
        return {'status': 'UNREACHABLE_ALIGNMENT', 'active_cost_or_roles_certified': False}
    terminal = min(viable, key=lambda s: (forward[s], s))
    optimum = forward[terminal]
    reverse, _ = shortest(product['incoming'], product['ends'], rho)
    logged, synced, optimal_edges = set(), set(), 0
    for u, edges in enumerate(product['outgoing']):
        if forward[u] is None:
            continue
        for v, edge in edges:
            if reverse[v] is None or forward[u] + edge['deltaD'] + rho * edge['deltaK'] + reverse[v] != optimum:
                continue
            optimal_edges += 1
            if edge['kind'] == 'log':
                logged.add(edge['event_position'])
            elif edge['kind'] == 'sync':
                synced.add(edge['event_position'])
    universe = set(range(len(product['word'])))
    assert logged | synced == universe
    path = witness(product, parents, terminal)
    assert rho * path['K'] + path['D'] == optimum
    return {'status': 'EXACT_ORIGINAL_AFFINE_SCALAR_AND_RECORD_ROLES', 'active_cost_or_roles_certified': True,
        'rho': {'numerator': rho.numerator, 'denominator': rho.denominator},
        'normalized_cost': {'numerator': optimum.numerator, 'denominator': optimum.denominator},
        'possible_log_positions': sorted(logged), 'possible_sync_positions': sorted(synced),
        'mandatory_log_positions': sorted(universe - synced), 'forced_sync_positions': sorted(universe - logged),
        'ambiguous_positions': sorted(logged & synced), 'independently_replayed_feasible_path': path,
        'product_states': len(product['states']), 'product_edges': sum(map(len, product['outgoing'])),
        'optimal_edges': optimal_edges, 'rigorous_product_state_bound': product['rigorous_bound']}


def lexicographic_K_D(product):
    if product['status'] != 'EXACT_SMALL_ORIGINAL_PRODUCT':
        return {**product, 'minimum_K_D_claimed': False}
    distances, parents = shortest(product['outgoing'], {0}, lexicographic=True)
    viable = [terminal for terminal in product['ends'] if distances[terminal] is not None]
    if not viable:
        return {'status': 'UNREACHABLE_ALIGNMENT', 'minimum_K_D_claimed': False}
    terminal = min(viable, key=lambda s: (distances[s], s))
    path = witness(product, parents, terminal)
    assert (path['K'], path['D']) == distances[terminal]
    return {'status': 'EXACT_ORIGINAL_LEXICOGRAPHIC_MINIMUM_K_D', 'minimum_K_D_claimed': True,
        'globally_minimum_K': path['K'], 'minimum_D_at_minimum_K': path['D'],
        'independently_replayed_feasible_path': path, 'product_states': len(product['states'])}


def exact_cost(answer):
    q = answer['normalized_cost']
    return Fraction(q['numerator'], q['denominator'])


def certify_finite_interval(product, left, right, K, D):
    left, right = Fraction(left), Fraction(right)
    assert 0 <= left < right and isinstance(K, int) and isinstance(D, int) and 0 <= K <= D
    probe = (left + right) / 2
    endpoint_left = scalar_and_roles(product, left)
    endpoint_right = scalar_and_roles(product, right)
    interior = scalar_and_roles(product, probe)
    assert all(a['active_cost_or_roles_certified'] for a in (endpoint_left, endpoint_right, interior))
    assert exact_cost(endpoint_left) == K * left + D and exact_cost(endpoint_right) == K * right + D
    path = interior['independently_replayed_feasible_path']
    assert (path['K'], path['D']) == (K, D)
    assert exact_cost(interior) == K * probe + D
    return {'status': 'CERTIFIED_FINITE_OPEN_INTERVAL_COST_AND_RECORD_ROLES',
        'left': {'numerator': left.numerator, 'denominator': left.denominator},
        'right': {'numerator': right.numerator, 'denominator': right.denominator},
        'probe': {'numerator': probe.numerator, 'denominator': probe.denominator},
        'line_K_D': [K, D], 'left_direct_answer': endpoint_left, 'right_direct_answer': endpoint_right,
        'interior_direct_answer': interior,
        'proof': 'True optimum concave >= endpoint chord; optimum <= independently replayed feasible line; each optimal interior path line equals chord throughout interval',
        'inactive_or_dominated_fixed_K_scope_certified': False}


def certify_unbounded_tail(product, left, K, D):
    left = Fraction(left)
    assert left >= 0 and isinstance(K, int) and isinstance(D, int) and 0 <= K <= D
    lexical = lexicographic_K_D(product)
    assert lexical['minimum_K_D_claimed'] and (lexical['globally_minimum_K'], lexical['minimum_D_at_minimum_K']) == (K, D)
    endpoint, interior = scalar_and_roles(product, left), scalar_and_roles(product, left + 1)
    assert endpoint['active_cost_or_roles_certified'] and interior['active_cost_or_roles_certified']
    assert exact_cost(endpoint) == K * left + D and exact_cost(interior) == K * (left + 1) + D
    assert (interior['independently_replayed_feasible_path']['K'], interior['independently_replayed_feasible_path']['D']) == (K, D)
    return {'status': 'CERTIFIED_UNBOUNDED_OPEN_TAIL_COST_AND_RECORD_ROLES',
        'left': {'numerator': left.numerator, 'denominator': left.denominator}, 'line_K_D': [K, D],
        'lexicographic_certificate': lexical, 'left_direct_answer': endpoint, 'interior_direct_answer': interior,
        'proof': 'Every feasible path has K>=global minimum; costs at endpoint no lower than feasible lexical line; larger slopes cannot later undercut; interior optimal paths share that line',
        'inactive_or_dominated_fixed_K_scope_certified': False}

