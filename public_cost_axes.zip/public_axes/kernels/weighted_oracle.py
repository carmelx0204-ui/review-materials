from collections import Counter, defaultdict, deque
from fractions import Fraction
import heapq
from kernels.weighted_layers import own_graph
INF=float("inf")


def positive_integer(value,name):
    if type(value) is not int or value<=0:raise ValueError(name+' must be a positive integer')
    return value


def build_product(transitions,graph,events,pred,log_cost,model_cost):
    if len(pred)!=len(events):raise ValueError('Predecessor count mismatch')
    states=[(0,0)];index={(0,0):0};work=deque([0]);adj=[]
    while work:
        u=work.popleft();mask,mi=states[u];moves=[]
        for i,e in enumerate(events):
            if mask>>i&1 or pred[i]&mask!=pred[i]:continue
            moves.append(((mask|1<<i,mi),log_cost,'log',e['id']))
            for ti,v in graph['edges'][mi]:
                if transitions[ti]['label'] is not None and transitions[ti]['label']==e['concept']:
                    moves.append(((mask|1<<i,v),0,'sync',e['id']))
        for ti,v in graph['edges'][mi]:
            label=transitions[ti]['label'];moves.append(((mask,v),model_cost if label is not None else 0,
                                                      'model' if label is not None else 'silent',None))
        edges=[]
        for state,weight,kind,eid in moves:
            if state not in index:index[state]=len(states);states.append(state);work.append(index[state])
            edges.append((index[state],weight,kind,eid))
        adj.append(edges)
    return states,adj


def dijkstra(adj,seeds,forbidden=None):
    distance=[INF]*len(adj);queue=[]
    for u in seeds:distance[u]=0;heapq.heappush(queue,(0,u))
    while queue:
        cost,u=heapq.heappop(queue)
        if distance[u]!=cost:continue
        for v,w,kind,eid in adj[u]:
            if forbidden is not None and (kind,eid)==forbidden:continue
            candidate=cost+w
            if candidate<distance[v]:distance[v]=candidate;heapq.heappush(queue,(candidate,v))
    return distance


def weighted_oracle(transitions,graph,events,pred,log_cost,model_cost,final=None,all_markings=False):
    log_cost=positive_integer(log_cost,'log_cost');model_cost=positive_integer(model_cost,'model_cost')
    if len({e['id'] for e in events})!=len(events):raise ValueError('Duplicate identity')
    states,adj=build_product(transitions,graph,events,pred,log_cost,model_cost)
    full=(1<<len(events))-1
    targets=[u for u,(mask,mi) in enumerate(states) if mask==full and
             (final is None or tuple(graph['markings'][mi])==tuple(final))]
    if not targets:raise ValueError('No accepting product state')
    forward=dijkstra(adj,[0]);optimum=min(forward[u] for u in targets)
    if optimum==INF:raise ValueError('No finite accepted alignment')
    possible=set();mandatory=set();restricted={}
    for e in events:
        eid=e['id'];force_log=dijkstra(adj,[0],('sync',eid));force_sync=dijkstra(adj,[0],('log',eid))
        log_best=min(force_log[u] for u in targets);sync_best=min(force_sync[u] for u in targets)
        if log_best==optimum:possible.add(eid)
        if sync_best>optimum:mandatory.add(eid)
        restricted[eid]=(force_log,force_sync)
    reverse=[[] for _ in states]
    for u,edges in enumerate(adj):
        for v,w,kind,eid in edges:reverse[v].append((u,w,kind,eid))
    backward=dijkstra(reverse,targets)
    all_ids={e['id'] for e in events}
    answer={'cost':optimum,'possible_log_ids':sorted(possible),'mandatory_log_ids':sorted(mandatory),
            'forced_sync_ids':sorted(all_ids-possible),'ambiguous_consumption_ids':sorted(possible-mandatory),
            'product_states':len(states),'optimal_edges':sum(forward[u]+w+backward[v]==optimum
                for u,edges in enumerate(adj) for v,w,kind,eid in edges),
            'restricted_solver_runs':2*len(events)}
    if all_markings:
        rows=[]
        for mi in range(len(graph['markings'])):
            u=next(u for u,(mask,m) in enumerate(states) if mask==full and m==mi)
            rows.append({'cost':forward[u],
                         'possible_log_ids':sorted(eid for eid,(dl,ds) in restricted.items() if dl[u]==forward[u]),
                         'mandatory_log_ids':sorted(eid for eid,(dl,ds) in restricted.items() if ds[u]>forward[u])})
        answer['marking_frontier']=rows
    return answer


def serial_doc(k):
    size=k+2;transitions=[]
    for i in range(k+1):
        pre=[0]*size;post=[0]*size;pre[i]=1;post[i+1]=1
        transitions.append({'id':'t'+str(i),'label':'A'+str(i+1) if i<k else 'B','pre':pre,'post':post})
    return {'name':'analytical_k'+str(k),'places':['p'+str(i) for i in range(size)],
            'initial':[1]+[0]*(size-1),'transitions':transitions},[0]*(size-1)+[1]


def threshold_expected(k,l,m,eid):
    return {'prefix_cost':min(l,k*m),'prefix_possible_log_ids':[eid] if l<=k*m else [],
            'prefix_mandatory_log_ids':[eid] if l<k*m else [],'completed_cost':k*m}


def self_test():
    count=0
    for k in range(1,9):
        doc,final=serial_doc(k);transitions,graph=own_graph(doc)
        events=[{'id':'b','concept':'B','occurrence_seconds':10,'availability_seconds':10}]
        for l in range(1,11):
            for m in [1,2]:
                want=threshold_expected(k,l,m,'b')
                prefix=weighted_oracle(transitions,graph,events,[0],l,m)
                complete=weighted_oracle(transitions,graph,events,[0],l,m,final)
                assert prefix['cost']==want['prefix_cost'] and prefix['possible_log_ids']==want['prefix_possible_log_ids']
                assert prefix['mandatory_log_ids']==want['prefix_mandatory_log_ids']
                assert complete['cost']==want['completed_cost'] and not complete['possible_log_ids'];count+=2
    for invalid in [0,-1,True,1.5]:
        try:positive_integer(invalid,'invalid')
        except ValueError:pass
        else:raise AssertionError('Invalid cost accepted')
    return {'status':'SELF_TEST_PASS','analytical_threshold_results':count,'invalid_cost_rejections':4,
            'production_outputs_audited':False}

