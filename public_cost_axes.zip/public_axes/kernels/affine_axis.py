from collections import Counter, defaultdict, deque
from fractions import Fraction
import heapq
from kernels import original_active_oracle as oracle
ROLE_FIELDS=('possible_log_ids','mandatory_log_ids','possible_sync_ids','forced_sync_ids','ambiguous_consumption_ids')
POSITION_FIELDS=('possible_log_positions','mandatory_log_positions','possible_sync_positions','forced_sync_positions','ambiguous_positions')


def q(value):
    value = Fraction(value)
    return {'numerator': value.numerator, 'denominator': value.denominator}


def f(doc):
    return Fraction(doc['numerator'], doc['denominator'])


def active(entries, rho):
    price = min(row['gap_count'] * rho + row['minimum_total_deviations'] for row in entries)
    return price, [row for row in entries if row['gap_count'] * rho + row['minimum_total_deviations'] == price]


def critical_points(entries):
    points = set()
    for before in entries:
        for after in entries:
            if before['gap_count'] == after['gap_count']:
                continue
            rho = Fraction(after['minimum_total_deviations'] - before['minimum_total_deviations'], before['gap_count'] - after['gap_count'])
            if rho > 0 and len(active(entries, rho)[1]) > 1:
                points.add(rho)
    return sorted(points)


def candidate_cells(entries):
    points = critical_points(entries)
    cells = []
    for left, right in zip([Fraction(0)] + points, points + [None]):
        probe = left + 1 if right is None else (left + right) / 2
        _, selected = active(entries, probe)
        assert len(selected) == 1
        line = [selected[0]['gap_count'], selected[0]['minimum_total_deviations']]
        cells.append({'kind': 'open_interval', 'left': q(left), 'right': q(right) if right is not None else None,
            'probe': q(probe), 'candidate_line_K_D': line})
        if right is not None:
            cells.append({'kind': 'point', 'ratio': q(right)})
    return cells


def expected_profile_answer(entries, rho, length):
    price, selected = active(entries, rho)
    logged, synced = set(), set()
    for row in selected:
        logged.update(row['possible_log_positions'])
        synced.update(row['possible_sync_positions'])
    universe = set(range(length))
    assert logged | synced == universe and logged | synced <= universe
    return {'normalized_cost': q(price), 'possible_log_positions': sorted(logged), 'possible_sync_positions': sorted(synced),
        'mandatory_log_positions': sorted(universe - synced), 'forced_sync_positions': sorted(universe - logged),
        'ambiguous_positions': sorted(logged & synced)}


def expected_and_compare(answer, profile, rho, length):
    expected = expected_profile_answer(profile['entries'], rho, length)
    assert {k: answer[k] for k in ('normalized_cost',) + POSITION_FIELDS} == expected


def certify_word(planned, variant, graph):
    product = oracle.build_product(graph, planned['word'], final=None, cap=100000)
    if product['status'] != 'EXACT_SMALL_ORIGINAL_PRODUCT':
        return {'variant_id': planned['variant_id'], 'word': planned['word'],
            'status': 'UNAVAILABLE_SMALL_ORIGINAL_PRODUCT', 'constituent_status': product['status']}
    profile = variant['affine_profile']
    length, certificates = len(planned['word']), []
    zero, default = oracle.scalar_and_roles(product, 0), oracle.scalar_and_roles(product, 2)
    expected_and_compare(zero, profile, Fraction(0), length)
    expected_and_compare(default, profile, Fraction(2), length)
    for cell in planned['candidate_cells']:
        if cell['kind'] == 'point':
            rho = f(cell['ratio'])
            direct = oracle.scalar_and_roles(product, rho)
            expected_and_compare(direct, profile, rho, length)
            certificates.append({**cell, 'direct_answer': direct})
        else:
            left, right = f(cell['left']), f(cell['right']) if cell['right'] is not None else None
            K, D = cell['candidate_line_K_D']
            proof = oracle.certify_unbounded_tail(product, left, K, D) if right is None else oracle.certify_finite_interval(product, left, right, K, D)
            expected_and_compare(proof['interior_direct_answer'], profile, f(cell['probe']), length)
            certificates.append({**cell, 'whole_interval_certificate': proof})
    return {'variant_id': planned['variant_id'], 'word': planned['word'], 'status': 'CERTIFIED_ENTIRE_NONNEGATIVE_AFFINE_ACTIVE_COST_AND_RECORD_ROLES',
        'direct_rho_zero': zero, 'direct_default_two': default, 'cells': certificates,
        'resource_counts': {'product_states': len(product['states']), 'product_edges': sum(map(len, product['outgoing'])),
            'rigorous_product_state_bound': product['rigorous_bound'], 'state_cap': 100000},
        'primary_fixed_K_LIMITs_and_dominated_scope_upgraded': False, 'all_active_count_sets_at_ties_claimed': False}


def positions_at(certificate, rho):
    rho = Fraction(rho)
    assert rho >= 0 and certificate['status'] == 'CERTIFIED_ENTIRE_NONNEGATIVE_AFFINE_ACTIVE_COST_AND_RECORD_ROLES'
    if rho == 0:
        result = certificate['direct_rho_zero']
    else:
        result = None
        for cell in certificate['cells']:
            if cell['kind'] == 'point' and rho == f(cell['ratio']):
                result = cell['direct_answer']
                break
            if cell['kind'] == 'open_interval' and rho > f(cell['left']) and (cell['right'] is None or rho < f(cell['right'])):
                proof = cell['whole_interval_certificate']
                K, D = proof['line_K_D']
                result = {**proof['interior_direct_answer'], 'normalized_cost': q(K * rho + D)}
                break
        assert result is not None
    return {k: result[k] for k in ('normalized_cost',) + POSITION_FIELDS}


def mapped_at(profile, certificate, rho, ids):
    result = positions_at(certificate, rho) if certificate is not None else expected_profile_answer(profile['entries'], rho, len(ids))
    return {'normalized_cost': result['normalized_cost'],
        **{field: sorted(ids[p] for p in result[pos]) for field, pos in zip(ROLE_FIELDS, POSITION_FIELDS)}}


def revision(before, after, common):
    bp, ap = set(before['possible_log_ids']) & common, set(after['possible_log_ids']) & common
    bm, am = set(before['mandatory_log_ids']) & common, set(after['mandatory_log_ids']) & common
    same = before['normalized_cost'] == after['normalized_cost']
    return {'same_cost': same, 'old_possible_changed': bp != ap, 'old_mandatory_changed': bm != am,
        'same_cost_old_summary_revision': same and (bp != ap or bm != am),
        'possible_gained': sorted(ap - bp), 'possible_withdrawn': sorted(bp - ap),
        'mandatory_gained': sorted(am - bm), 'mandatory_withdrawn': sorted(bm - am)}


def joint_points(before_entries, after_entries):
    points = set(critical_points(before_entries) + critical_points(after_entries))
    for before in before_entries:
        for after in after_entries:
            if before['gap_count'] == after['gap_count']:
                continue
            rho = Fraction(after['minimum_total_deviations'] - before['minimum_total_deviations'], before['gap_count'] - after['gap_count'])
            if rho > 0 and active(before_entries, rho)[0] == active(after_entries, rho)[0]:
                if before['gap_count'] * rho + before['minimum_total_deviations'] == active(before_entries, rho)[0]:
                    points.add(rho)
    return sorted(points)


def pair_result(before_profile, after_profile, before_certificate, after_certificate, before_ids, after_ids):
    points = joint_points(before_profile['entries'], after_profile['entries'])
    def at(rho):
        before = mapped_at(before_profile, before_certificate, rho, before_ids)
        after = mapped_at(after_profile, after_certificate, rho, after_ids)
        return {'ratio': q(rho), 'before': before, 'after': after, **revision(before, after, set(before_ids))}
    cells = []
    for left, right in zip([Fraction(0)] + points, points + [None]):
        probe = left + 1 if right is None else (left + right) / 2
        cells.append({'kind': 'open_interval', 'left': q(left), 'right': q(right) if right is not None else None,
            'probe': q(probe), **{k: v for k, v in at(probe).items() if k != 'ratio'}})
        if right is not None:
            cells.append({'kind': 'point', **at(right)})
    boundary, default = at(Fraction(0)), at(Fraction(2))
    open_revision = any(c['same_cost_old_summary_revision'] for c in cells if c['kind'] == 'open_interval')
    point_revision = any(c['same_cost_old_summary_revision'] for c in cells if c['kind'] == 'point')
    return {'status': 'EXACT_ALL_POSITIVE_PARAMETER_CELLS', 'parameter': 'rho', 'cells': cells,
        'classic': boundary, 'default': default, 'categories': {'any_positive_revision': open_revision or point_revision,
            'all_positive_revision': all(c['same_cost_old_summary_revision'] for c in cells),
            'open_interval_revision': open_revision, 'point_revision': point_revision,
            'isolated_only_revision': point_revision and not open_revision,
            'classic_revision': boundary['same_cost_old_summary_revision'], 'default_revision': default['same_cost_old_summary_revision']}}


def compare_saved_pair(reconstructed, saved):
    assert reconstructed['status'] == saved['status'] and reconstructed['categories'] == saved['categories']
    assert len(reconstructed['cells']) == len(saved['cells'])
    for expected, actual in zip(reconstructed['cells'] + [reconstructed['classic'], reconstructed['default']],
                                saved['cells'] + [saved['classic'], saved['default']]):
        for field, value in expected.items():
            if field in ('before', 'after'):
                assert all(actual[field][k] == v for k, v in value.items())
            else:
                assert actual[field] == value, field

