from collections import Counter, defaultdict, deque
from fractions import Fraction
import heapq


def zero_one(adjacency, roots):
    distance = [None] * len(adjacency)
    queue = deque()
    for root in roots:
        distance[root] = 0
        queue.append(root)
    while queue:
        u = queue.popleft()
        cost = distance[u]
        for edge in adjacency[u]:
            v, weight = edge[:2]
            candidate = cost + weight
            if distance[v] is None or candidate < distance[v]:
                distance[v] = candidate
                if weight:
                    queue.append(v)
                else:
                    queue.appendleft(v)
    return distance

