# Public cost-axis reproduction

Complete weighted and affine cost-domain inputs, saved final certificates, and standard-library reconstruction code for all 3,011 BPI2013 structural words and 8,735 restoration comparisons.

See public_axes/README_v1.md for commands, guard contract and scope. Component files are byte-identical copies from the previously anonymized core review package. The two top-level metadata files do not alter component scientific bytes.
