"""Rebuild case/stratum arithmetic from complete saved word roles and IDs."""
from collections import Counter,defaultdict
from pathlib import Path
import argparse
import hashlib
import json
import math

HERE=Path(__file__).resolve().parent
MODELS=('bpi2013_IMf01','bpi2013_IMf02','bpi2013_IMf03','traffic_IM0','traffic_IMf02')
FIELDS=('possible_log_ids','mandatory_log_ids','forced_sync_ids','ambiguous_consumption_ids')
DOMAINS={'length_bin':['1-3','4-6','7-12','13+'],'any_repeated_activity':[False,True],
 'seen_training_word':[False,True],'restored_activity_repeated_in_retained':[False,True],
 'after_cost_bin':['0','1','2','3+'],'normal_last':[False,True]}


def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ratio(n,d):return None if not d else n/d
def close(a,b):
    if a is None or b is None:assert a is b
    else:assert math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-15),(a,b)
def check_manifest(base):
    rows=read(base/'manifest.json')['files'];paths=[r['path'] for r in rows]
    assert len(paths)==len(set(paths)) and 'manifest.json' not in paths
    assert {p.relative_to(base).as_posix() for p in base.rglob('*') if p.is_file()}==set(paths)|{'manifest.json'}
    for r in rows:
        source=base/r['path'];assert not source.is_symlink()
        p=source.resolve()
        assert p.is_relative_to(base.resolve()) and p.stat().st_size==r['bytes']
        assert sha(p)==r['sha256'],r['path']
def valid(w):
    assert w['status'].startswith('EXACT') and type(w['cost']) is int and w['cost']>=0
    P,M,S,A=[set(w[k]) for k in FIELDS];U=set(range(len(w['word'])))
    assert M<=P<=U and S==U-P and A==P-M
    assert all(len(w[k])==len(set(w[k])) for k in FIELDS)
def role(w,i):
    return 2 if i in w['mandatory_log_ids'] else 1 if i in w['possible_log_ids'] else 0


def run(ext,out):
    ext=ext.resolve();out=out.resolve()
    assert not out.exists() and not out.is_relative_to(HERE.resolve()) and not out.is_relative_to(ext)
    check_manifest(HERE);check_manifest(ext)
    result=read(HERE/'result.json');savedcases=read(HERE/'case_level_counts.json')
    strata=read(HERE/'strata.json');checks=[]
    assert set(result['models'])==set(savedcases)==set(MODELS)
    assert {r['model'] for r in strata}==set(MODELS)
    skeys=[(r['model'],r['field'],r['stratum']) for r in strata]
    assert len(skeys)==len(set(skeys))==len(MODELS)*sum(map(len,DOMAINS.values()))
    for name in MODELS:
        cohort='bpi2013' if name.startswith('bpi2013') else 'traffic'
        plan=read(ext/'inputs'/('plan_'+cohort+'.json'))
        assert plan['acceptance']=='PREFIX_ANY_REACHABLE_MARKING'
        words=read(ext/'inputs'/('words_'+name+'.json'))
        assert [w['variant_id'] for w in words]==list(range(len(words)))
        assert len(words)==len(plan['variants'])
        for w,v in zip(words,plan['variants']):assert w['word']==v['word'];valid(w)
        cases={c['id']:c for c in plan['cases']};assert len(cases)==len(plan['cases'])
        cc={cid:Counter() for cid in cases};total=Counter();seen=set()
        groups={f:{str(v):{'counts':Counter(),'cases':set(),'affected':set()} for v in vs} for f,vs in DOMAINS.items()}
        for p in plan['pairs']:
            c=cases[p['case']];ev=c['events'];pos=p['position'];ids=[e['id'] for e in ev];concepts=[e['concept'] for e in ev];n=len(ev)
            assert len(set(ids))==n and 0<=pos<n and ids[pos]==p['delayed_record_id']
            key=(c['id'],pos);assert key not in seen;seen.add(key)
            b,a=words[p['before_variant']],words[p['after_variant']]
            assert a['word']==concepts and b['word']==concepts[:pos]+concepts[pos+1:]
            beforeids=ids[:pos]+ids[pos+1:]
            B={eid:role(b,i) for i,eid in enumerate(beforeids)}
            A={eid:role(a,i) for i,eid in enumerate(ids)}
            changed=any(B[eid]!=A[eid] for eid in beforeids)
            same=b['cost']==a['cost'];target=same and changed;d1=b['cost']==a['cost']==1;last=pos==n-1
            assert p['normal_last_record_control']==last
            flags={'pairs':1,'cost_preserving':int(same),'target':int(target),'all_role_changed':int(changed),
             'D1':int(d1),'D1_target':int(d1 and changed),'last_pairs':int(last),'last_target':int(last and target),
             'nonlast_pairs':int(not last),'nonlast_target':int(not last and target)}
            total.update(flags);cc[c['id']].update(flags)
            properties={'length_bin':'1-3' if n<=3 else '4-6' if n<=6 else '7-12' if n<=12 else '13+',
             'any_repeated_activity':len(set(concepts))<n,'seen_training_word':c['after_word_seen_in_training'],
             'restored_activity_repeated_in_retained':concepts[pos] in concepts[:pos]+concepts[pos+1:],
             'after_cost_bin':str(a['cost']) if a['cost']<3 else '3+','normal_last':last}
            for f,v in properties.items():
                g=groups[f][str(v)];g['counts'].update(flags);g['cases'].add(c['id'])
                if target:g['affected'].add(c['id'])
        assert seen=={(cid,i) for cid,c in cases.items() for i in range(len(c['events']))}
        report=result['models'][name];assert report['counts']==dict(total)
        saved={r['case']:r for r in savedcases[name]}
        assert len(saved)==len(savedcases[name])==len(cases) and set(saved)==set(cases)
        for cid,k in cc.items():
            for f,v in k.items():assert saved[cid][f]==v
            c=cases[cid];concepts=[e['concept'] for e in c['events']]
            assert saved[cid]['model']==name and saved[cid]['any_repeated_activity']==(len(set(concepts))<len(concepts))
            assert saved[cid]['seen_training_word']==c['after_word_seen_in_training']
            assert saved[cid]['length']==len(cases[cid]['events']) and saved[cid]['affected']==int(k['target']>0)
            close(saved[cid]['case_equal_all_position_fraction'],ratio(k['target'],k['pairs']))
            close(saved[cid]['case_equal_cost_preserving_fraction'],ratio(k['target'],k['cost_preserving']))
            close(saved[cid]['nonlast_case_fraction'],ratio(k['nonlast_target'],k['nonlast_pairs']))
        eligible=[k for k in cc.values() if k['cost_preserving']];nonlast=[k for k in cc.values() if k['nonlast_pairs']]
        affected=sum(k['target']>0 for k in cc.values());count=len(cc)
        estimates={'position_weighted_all_position_rate':total['target']/total['pairs'],
         'position_weighted_cost_preserving_rate':total['target']/total['cost_preserving'],
         'affected_case_rate':affected/count,'case_equal_all_position_rate':sum(k['target']/k['pairs'] for k in cc.values())/count,
         'case_equal_cost_preserving_rate_eligible_cases_only':sum(k['target']/k['cost_preserving'] for k in eligible)/len(eligible),
         'nonlast_case_equal_target_rate':sum(k['nonlast_target']/k['nonlast_pairs'] for k in nonlast)/len(nonlast),
         'last_case_equal_target_rate':total['last_target']/count}
        estimates['nonlast_minus_last_case_equal_descriptive_contrast']=estimates['nonlast_case_equal_target_rate']-estimates['last_case_equal_target_rate']
        assert set(report['point_estimates'])==set(report['case_cluster_resampling_intervals'])==set(estimates)
        for f,v in estimates.items():close(report['point_estimates'][f],v)
        assert report['cases']==count and report['affected_cases']==affected
        assert report['zero_cost_preserving_opportunity_cases']==count-len(eligible)
        assert report['no_nonlast_opportunity_cases']==count-len(nonlast)
        expected={(r['field'],r['stratum']):r for r in strata if r['model']==name}
        assert set(expected)=={(f,v) for f,vs in groups.items() for v in vs}
        for f,vs in groups.items():
            for v,g in vs.items():
                r=expected[f,v];k=g['counts'];assert r['counts']==dict(k),(name,f,v)
                assert r['cases_with_positions']==len(g['cases']) and r['affected_cases']==len(g['affected'])
                close(r['position_weighted_all_rate'],ratio(k['target'],k['pairs']))
                close(r['position_weighted_cost_preserving_rate'],ratio(k['target'],k['cost_preserving']))
        checks.append({'model':name,'comparisons':len(seen),'cases':count,'target':total['target'],
         'same_cost_opportunities':total['cost_preserving'],'eligible_cases':len(eligible),'all_point_estimates_and_strata_match':True})
    assert sum(r['comparisons'] for r in checks)==29817
    for name,r in result['models'].items():
        for ci in r['case_cluster_resampling_intervals'].values():assert 0<=ci['lo']<=ci['hi']<=1 and ci['finite_draws']==10000
    check_manifest(HERE);check_manifest(ext);out.mkdir()
    receipt={'status':'PASS_COMPLETE_PORTABLE_CASE_AND_STRATUM_REAGGREGATION','models':checks,
     'all_comparisons':29817,'fresh_alignment_optimization':False,'bootstrap_distribution_resimulated':False,
     'statistics_manifest_sha256':sha(HERE/'manifest.json'),'extension_manifest_sha256':sha(ext/'manifest.json')}
    (out/'report.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(receipt))


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--extension',type=Path,required=True);ap.add_argument('--out',type=Path,required=True)
    args=ap.parse_args();run(args.extension,args.out)
