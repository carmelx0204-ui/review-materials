# Complete descriptive cohort tables

Unzip alongside `unit_extension`. From this directory run:

```
python -B verify_saved_statistics.py --extension ../unit_extension --out ../new-statistics-check
```

The standard-library consumer rebuilds every one of the 29,817 conditional
comparison flags from complete saved word roles and original record identities,
then checks every case count, point estimate and length/repetition/seen/cost/
last-position stratum against the exported tables. It checks the sibling input
manifest, every exported byte, and complete denominators. This is saved-answer
reaggregation rather than fresh alignment optimization.

The result table also preserves 10,000-case-cluster PCG64 resampling summaries
from the original analysis. This consumer checks their bytes and range; it does
not resimulate the bootstrap distributions. Those intervals describe sensitivity
of the fixed cohorts and reference models. The point estimates have distinct
all-position, equal-cost-opportunity and case-equal denominators. Empty strata
are null and the no-opportunity case is explicitly outside the conditional mean.

The five reference rows share two cohorts (2,023 cases). They are model conditions,
rather than five independent populations. The original source dataset DOI and
rights are supplied on the common review landing page.
